# Command Output

## Analytics before connector run
{"connector_runs":39,"condition_snapshots":54,"discourse_items":3,"actors":3,"claims":3}

## social.seed connector run
{"connector_key":"social.seed","status":"success","message":"Social validation data seeded","stats":{"items":3}}

## Analytics after connector run
{"connector_runs":40,"condition_snapshots":54,"discourse_items":3,"actors":3,"claims":3}
