# Dashboard Verification Notes

- GET /api/health returned ok on 2026-03-16.
- GET /api/dashboard/overview returned active_incidents=11, out_of_control=0, being_held=0, under_control=11, evacuation_orders=0, evacuation_alerts=1, area_restrictions=1.
- Desktop build passed with cmd /c npm.cmd --workspace apps/desktop run build.
- Dashboard DOM capture showed the same totals and pinned incidents as /api/dashboard/overview.
- Dashboard no longer renders discourse posture, fire-centre outlooks, or connector-runs as main dashboard metrics.
- Dashboard no longer depends on a static fire-centre list or hardcoded Prince George count logic.
