# Dashboard Source Mapping Next Step

Dashboard-only next pass: keep dashboard totals, stage-of-control counts, evacuation counts, area restrictions, pinned incidents, and fire-centre summary only if they are re-sourced from live BCWS incident, evacuation, and restriction ingestion with citations. Keep the provincial map as a neutral container only. Move connector and live-posture sidebars off the operator dashboard. Omit resources, news, and official-channel sections until real source-backed ingestion exists.
