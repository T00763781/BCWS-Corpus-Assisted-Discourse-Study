# Dashboard Command Output

## /api/dashboard/overview
{"active_incidents":11,"out_of_control":0,"being_held":0,"under_control":11,"evacuation_orders":0,"evacuation_alerts":1,"area_restrictions":1,"fire_centres":[{"fire_centre":"Prince George Fire Centre","incident_count":11,"out_of_control":0,"being_held":0,"under_control":11}],"pinned_incidents":[{"fire_number":"G70422","wildfire_name":"Kiskatinaw River","stage_of_control":"Under Control","fire_centre":"Prince George Fire Centre","size_hectares":26195.3,"updated_at":"2026-03-07T23:40:00+00:00"}]}
