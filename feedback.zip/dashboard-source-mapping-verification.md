# Dashboard Source Mapping Verification Notes

- Inspected the current dashboard sections in apps/desktop/src/App.tsx.
- Inspected the backend dashboard query in services/api/open_fireside_api/services/queries.py and router in services/api/open_fireside_api/routers/dashboard.py.
- Inspected connector provenance in services/api/open_fireside_api/connectors/bcws.py, cwfis.py, geomet.py, and seed_data.py.
- Confirmed the dashboard API contract is real, but most dashboard-driving records remain seeded underneath.
- Confirmed open_fireside_endpoints.csv is recon/reference only and not a runtime input.
- Extracted relevant Dashboard endpoint families from the recon CSV: BCWS incident/list/detail routes, perimeter layer family, evacuation layer family, restrictions layer family, BCWS official content/blog family, and youtube.jsp.
