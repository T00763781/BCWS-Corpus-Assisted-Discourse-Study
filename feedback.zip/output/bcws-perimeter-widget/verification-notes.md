# BCWS Perimeter Widget Verification

- Configure route rendered the `BCWS Fire Perimeters PublicView` widget.
- Widget fetch state rendered `success`.
- Metadata, count, and specimen HTTP states rendered `200`.
- Visible specimen fields rendered from the ArcGIS response:
  - `FIRE_NUMBER`
  - `FIRE_STATUS`
  - `FIRE_SIZE_HECTARES`
  - `FIRE_URL`
- Raw specimen block rendered in the DOM under `Raw specimen`.
- Dashboard route rendered `blank-workspace`.
- Screenshots:
  - `configure.png`
  - `dashboard.png`
