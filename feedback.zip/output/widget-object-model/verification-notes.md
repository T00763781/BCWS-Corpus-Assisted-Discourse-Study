# Widget Object Model Verification

- Configure tabs rendered:
  - Sources
  - Widgets
  - Dashboard
  - Incidents
  - Discourse
  - Environment
  - Maps
- `Configure > Widgets` rendered the live widget object and candidate-only rows.
- `Dashboard`, `Incidents`, `Discourse`, `Environment`, and `Maps` each rendered:
  - `Edit off`
  - `Add column`
  - `Add widget`
- After toggling edit mode and using the builder controls on each page:
  - one empty column rendered
  - one empty widget slot rendered
- No page route rendered the BCWS perimeter widget.
