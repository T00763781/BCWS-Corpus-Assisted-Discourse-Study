# Next Steps

1. Replace dashboard and maps placeholder geography panels with real perimeter, evacuation, and restriction map layers.
2. Curate environment records so operators see incident-relevant overlays instead of raw endpoint-candidate rows.
3. Expand discourse ingestion and linking by fire number and fire-centre scope without making discourse the primary domain.
4. Add interaction tests for incident list filtering, incident detail tabs, and maps/environment route rendering.
