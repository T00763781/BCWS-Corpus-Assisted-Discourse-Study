# Next Steps

1. Wire live dashboard map layers into the existing map container using dashboard-approved wildfire, evacuation, and restriction overlays.
2. Add a backend-supported dashboard update timestamp if operators need explicit recency on the overview surface.
3. Add a dashboard-specific frontend verification that asserts rendered totals match /api/dashboard/overview.
