
# Reference Layer Policy

## Scope locking rule
The Phase A reference layer is fixed at package creation time. A builder must not add or remove reference populations during bootstrap.

## BC fire centres
The canonical fire-centre reference population is the six BC Wildfire Service regional fire centres.

## BC municipalities/localities
The canonical BC municipality/locality reference population for Phase A is **all 161 incorporated British Columbia municipalities** from the Government of British Columbia legal-name list. No additional B.C. unincorporated locality is part of the Phase A structural reference universe.

This rule is deliberate:
- it makes the structural reference population finite and auditable from day one
- it prevents the builder from inventing locality scope
- it preserves the separate concept of evidence coverage, which can include unincorporated places in discourse and incident context without changing the structural reference universe.

## External communities
The canonical external-community layer is a fixed, curated list of border-adjacent or corridor-relevant communities outside B.C. These communities are included only for cross-border operational, evacuation, logistics, travel-corridor, and media-context analysis.

External communities are **not** BC municipalities/localities and do not count toward BC structural locality completeness.

### Inclusion categories
Allowed inclusion_basis values for external communities are fixed to the following deterministic classes:
- OPERATIONAL_LOGISTICS_GATEWAY
- HIGHWAY_CORRIDOR_GATEWAY
- EVACUATION_AND_CORRIDOR_CONTEXT
- NORTHERN_BORDER_GATEWAY
- NORTHERN_LOGISTICS_AND_MEDIA_HUB
- BORDER_SETTLEMENT_CONTEXT
- SOUTHWEST_BORDER_GATEWAY
- SOUTHEAST_LOGISTICS_AND_MEDIA_HUB
- SOUTHEAST_BORDER_GATEWAY

### Future additions
A new external community may be added only by editing the canonical CSV and this policy together. A community is eligible only if it is outside B.C. and clearly serves one of the fixed inclusion categories above. No runtime or analyst-driven additions are allowed.

## Fire-centre linkage rule
For fire centres, fire_centre_linkage is self-referential. For BC municipalities in the reference layer, fire-centre linkage is resolved by geospatial overlay after boundary ingest and is therefore blank in the CSV seed. This is intentional and fixed. The builder must not replace this with manual ad hoc assignment during bootstrap.
