
# Phase A Target Matrix

The following rules are canonical for Phase A historical readiness covering **2025-04-01 through 2026-03-31**.

| Requirement | Target basis | Minimum required count or coverage rule | Coverage mode | Required before Phase A sign-off | Validation method | Failure condition |
|---|---|---|---|---|---|---|
| fire_centres | CANONICAL_REFERENCE_FILE | ALL_ROWS_IN_REFERENCE/bc_fire_centres.csv | EXHAUSTIVE | YES | csv_count_and_required_column_validation | missing fire centre row, duplicate canonical_id, or count != 6 |
| municipalities_localities | CANONICAL_REFERENCE_FILE | ALL_ROWS_IN_REFERENCE/bc_municipalities_or_localities.csv | EXHAUSTIVE | YES | csv_count_and_required_column_validation | missing municipality row, duplicate canonical_id, missing required classification field, or count != 161 |
| external_communities | CANONICAL_REFERENCE_FILE | ALL_ROWS_IN_REFERENCE/external_communities.csv | EXHAUSTIVE | YES | csv_count_and_required_column_validation | missing external community row, duplicate canonical_id, missing required classification field, or count != 13 |
| incidents | PRIMARY_SEASON_SOURCE | ALL_DISTINCT_INCIDENTS_EMITTED_BY_CANONICAL_INCIDENT_INGESTOR_FOR_2025_04_01_TO_2026_03_31 | EXHAUSTIVE | YES | source_snapshot_count_vs_ingested_distinct_incident_count | any primary-source incident in season window missing from incidents table |
| event_clusters | CURATED_CLUSTER_LAYER | ALL_ROWS_IN_reference/event_clusters.csv | EXHAUSTIVE | YES | csv_count_vs_ingested_count | missing curated event cluster row or broken incident_event_cluster_links path |
| public_actors | STRUCTURAL_MINIMUM | MINIMUM_5_PUBLIC_ACTORS_WITH_AT_LEAST_ONE_EACH_OF_AGENCY_ORGANIZATION_MEDIA_PROGRAM_PUBLIC_ROLE_PERSON | THRESHOLD | YES | actor_type_distribution_query | actor count < 5 or any required actor_type absent |
| actor_accounts | STRUCTURAL_MINIMUM | MINIMUM_5_ACTOR_ACCOUNTS_WITH_ONE_ACCOUNT_FOR_EACH_PHASE_A_MINIMUM_PUBLIC_ACTOR | THRESHOLD | YES | actor_account_distribution_query | actor_account count < 5 or any minimum public actor lacks an account |
| protected_private_continuity_entities | PRIVACY_PATH_MINIMUM | MINIMUM_1_PROTECTED_ENTITY_FIXTURE_AND_INGEST_PATH | THRESHOLD | YES | fixture_and_schema_validation | no protected entity row or privacy-classification boundary broken |
| protected_private_accounts | PRIVACY_PATH_MINIMUM | MINIMUM_1_PROTECTED_ACCOUNT_FIXTURE_AND_INGEST_PATH | THRESHOLD | YES | fixture_and_schema_validation | no protected account row or protected account linked to public actor tables |
| discourse_evidence_objects | EVIDENCE_PATH_MINIMUM | MINIMUM_1_DISCOURSE_THREAD_AND_1_DISCOURSE_ITEM_FIXTURE_PLUS_INGEST_PATH | THRESHOLD | YES | fixture_and_schema_validation | no discourse thread/item row or broken linkage path |
| source_surfaces | INGESTION_CLASS_MINIMUM | MINIMUM_5_SOURCE_SURFACES_COVERING_API_WEBSITE_SOCIAL_PLATFORM_MEDIA_SITE_MAP_LAYER | THRESHOLD | YES | source_surface_type_distribution_query | source_surface count < 5 or any required source_surface_type absent |
