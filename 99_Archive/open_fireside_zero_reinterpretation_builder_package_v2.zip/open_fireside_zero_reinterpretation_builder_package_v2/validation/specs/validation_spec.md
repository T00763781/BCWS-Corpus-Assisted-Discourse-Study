
# Validation Specification

Validation order is fixed:
1. reference dataset presence and counts
2. target matrix completeness and fixed rules
3. fixture integrity
4. ontology boundary tests
5. privacy boundary tests
6. phase boundary tests

Phase A sign-off is invalid if any test above fails.
