-- Canonical SQL assertions for minimal fixture
SELECT COUNT(*) = 1 AS one_fire_centre FROM fire_centres WHERE fire_centre_id = '11111111-1111-1111-1111-111111111111';
SELECT COUNT(*) = 1 AS one_locality FROM localities WHERE locality_id = '22222222-2222-2222-2222-222222222222';
SELECT structural_coverage_status <> evidence_coverage_status AS locality_coverages_distinct FROM localities WHERE locality_id = '22222222-2222-2222-2222-222222222222';
SELECT COUNT(*) = 1 AS one_actor FROM actors WHERE actor_id = '44444444-4444-4444-4444-444444444444';
SELECT COUNT(*) = 1 AS one_protected_entity FROM protected_private_entities WHERE protected_entity_id = '88888888-8888-8888-8888-888888888888';
SELECT COUNT(*) = 1 AS one_export_policy FROM redaction_policies WHERE redaction_policy_id = '12121212-1212-1212-1212-121212121212';
