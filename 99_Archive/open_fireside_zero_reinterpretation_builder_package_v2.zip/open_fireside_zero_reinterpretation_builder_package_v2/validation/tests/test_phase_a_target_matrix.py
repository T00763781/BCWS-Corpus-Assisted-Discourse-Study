
from __future__ import annotations

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REF = ROOT / 'reference'


def load(name: str):
    with open(REF / name, encoding='utf-8') as fh:
        return list(csv.DictReader(fh))


def test_target_matrix_has_all_required_rows():
    rows = load('phase_a_target_matrix.csv')
    required = {
        'fire_centres',
        'municipalities_localities',
        'external_communities',
        'incidents',
        'event_clusters',
        'public_actors',
        'actor_accounts',
        'protected_private_continuity_entities',
        'protected_private_accounts',
        'discourse_evidence_objects',
        'source_surfaces',
    }
    assert {r['requirement'] for r in rows} == required


def test_reference_rows_match_fixed_matrix_counts():
    matrix = {r['requirement']: r for r in load('phase_a_target_matrix.csv')}
    assert matrix['fire_centres']['minimum_required_count_or_coverage_rule'] == 'ALL_ROWS_IN_REFERENCE/bc_fire_centres.csv'
    assert matrix['municipalities_localities']['minimum_required_count_or_coverage_rule'] == 'ALL_ROWS_IN_REFERENCE/bc_municipalities_or_localities.csv'
    assert matrix['external_communities']['minimum_required_count_or_coverage_rule'] == 'ALL_ROWS_IN_REFERENCE/external_communities.csv'
    assert matrix['fire_centres']['required_before_phase_a_signoff'] == 'YES'
    assert matrix['municipalities_localities']['required_before_phase_a_signoff'] == 'YES'
    assert matrix['external_communities']['required_before_phase_a_signoff'] == 'YES'
