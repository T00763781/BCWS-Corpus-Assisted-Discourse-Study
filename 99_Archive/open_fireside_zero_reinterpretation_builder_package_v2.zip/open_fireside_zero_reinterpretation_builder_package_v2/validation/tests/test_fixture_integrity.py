import json
from pathlib import Path
import unittest

BASE = Path(__file__).resolve().parents[2]
FIXTURE = json.loads((BASE / 'fixtures/minimal/minimal_fixture.json').read_text())

class FixtureIntegrityTest(unittest.TestCase):
    def test_required_objects_exist(self):
        for key in ['fire_centre','locality','source_surface','actor','actor_account','incident','event_cluster','protected_private_entity','protected_private_account','discourse_thread','discourse_item','entity_link','redaction_policy']:
            self.assertIn(key, FIXTURE)

    def test_ids_are_distinct_across_public_and_protected_entities(self):
        self.assertNotEqual(FIXTURE['actor']['actor_id'], FIXTURE['protected_private_entity']['protected_entity_id'])
        self.assertNotEqual(FIXTURE['actor_account']['actor_account_id'], FIXTURE['protected_private_account']['protected_account_id'])

if __name__ == '__main__':
    unittest.main()
