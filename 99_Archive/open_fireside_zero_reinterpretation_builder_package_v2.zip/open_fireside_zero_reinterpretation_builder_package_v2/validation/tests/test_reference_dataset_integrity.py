
from __future__ import annotations

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REF = ROOT / 'reference'

REQUIRED_COLUMNS = ['canonical_id','canonical_name','type','province_state_territory','country','inclusion_basis','fire_centre_linkage','boundary_classification','active_in_phase_a','notes_provenance']


def load_csv(name: str):
    with open(REF / name, encoding='utf-8') as fh:
        return list(csv.DictReader(fh))


def test_reference_files_exist():
    for name in ['bc_fire_centres.csv','bc_municipalities_or_localities.csv','external_communities.csv','phase_a_target_matrix.csv','event_clusters.csv']:
        assert (REF / name).exists(), name


def test_expected_counts_are_fixed():
    assert len(load_csv('bc_fire_centres.csv')) == 6
    assert len(load_csv('bc_municipalities_or_localities.csv')) == 161
    assert len(load_csv('external_communities.csv')) == 13
    assert len(load_csv('event_clusters.csv')) == 1


def test_required_columns_and_uniqueness():
    for name in ['bc_fire_centres.csv','bc_municipalities_or_localities.csv','external_communities.csv']:
        rows = load_csv(name)
        assert rows
        for col in REQUIRED_COLUMNS:
            assert col in rows[0], (name, col)
        ids = [r['canonical_id'] for r in rows]
        assert len(ids) == len(set(ids)), name
        for row in rows:
            for col in ['canonical_id','canonical_name','type','province_state_territory','country','inclusion_basis','boundary_classification','active_in_phase_a','notes_provenance']:
                assert row[col] not in ('', None), (name, col, row)
