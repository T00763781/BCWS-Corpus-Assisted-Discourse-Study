import json
from pathlib import Path
import unittest

BASE = Path(__file__).resolve().parents[2]
FIXTURE = json.loads((BASE / 'fixtures/minimal/minimal_fixture.json').read_text())
GOV = (BASE / 'docs/governance/governance_privacy_export_v1.md').read_text()

class PrivacyBoundaryTest(unittest.TestCase):
    def test_protected_fixture_uses_protected_private_classification(self):
        self.assertEqual(FIXTURE['discourse_item']['privacy_classification'], 'PROTECTED_PRIVATE')

    def test_governance_doc_blocks_protected_identity_export(self):
        self.assertIn('No export of restricted identity-bearing fields', GOV)
        self.assertIn('default-private', GOV.lower())

if __name__ == '__main__':
    unittest.main()
