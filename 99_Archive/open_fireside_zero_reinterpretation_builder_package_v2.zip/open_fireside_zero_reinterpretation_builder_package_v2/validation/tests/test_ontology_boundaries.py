from pathlib import Path
import unittest

BASE = Path(__file__).resolve().parents[2]
DICT_TEXT = (BASE / 'schema/dictionaries/entity_dictionary.md').read_text()

class OntologyBoundaryTest(unittest.TestCase):
    def test_dictionary_mentions_separate_public_and_protected_models(self):
        self.assertIn('public actors are distinct from protected private continuity entities'.lower(), DICT_TEXT.lower())

    def test_dictionary_mentions_separate_locality_coverages(self):
        self.assertIn('structural_coverage_status', DICT_TEXT)
        self.assertIn('evidence_coverage_status', DICT_TEXT)

if __name__ == '__main__':
    unittest.main()
