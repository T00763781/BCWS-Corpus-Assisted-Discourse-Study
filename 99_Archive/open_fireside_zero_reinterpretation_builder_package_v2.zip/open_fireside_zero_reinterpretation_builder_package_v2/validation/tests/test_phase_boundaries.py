from pathlib import Path
import unittest

BASE = Path(__file__).resolve().parents[2]
PHASE_A = (BASE / 'planning/phasing/phase_a_mvp_cutoff.md').read_text()
PHASE_B = (BASE / 'planning/phasing/phase_b_realtime_transition.md').read_text()
README = (BASE / 'README.md').read_text()

class PhaseBoundaryTest(unittest.TestCase):
    def test_phase_a_historical_window_present(self):
        self.assertIn('2025-04-01 through 2026-03-31', README)
        self.assertIn('2025-04-01 through 2026-03-31', PHASE_A)

    def test_phase_b_start_date_present(self):
        self.assertIn('2026-04-01', PHASE_B)

    def test_phase_a_defers_realtime(self):
        self.assertIn('deferred', PHASE_A.lower())
        self.assertIn('real-time', PHASE_B.lower())

if __name__ == '__main__':
    unittest.main()
