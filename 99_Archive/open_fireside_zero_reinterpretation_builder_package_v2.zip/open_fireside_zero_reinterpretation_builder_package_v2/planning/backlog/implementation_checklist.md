# Implementation Checklist

- [ ] Apply schema SQL in order
- [ ] Load minimal fixture SQL
- [ ] Run SQL assertions
- [ ] Run Python validation tests
- [ ] Implement locality/fire-centre adapter internals
- [ ] Implement incident/event adapter internals
- [ ] Implement actor/account adapter internals
- [ ] Implement protected continuity adapter internals
- [ ] Implement discourse adapter internals
- [ ] Implement incident detail read model
- [ ] Implement locality comparison read model
- [ ] Verify Phase A MVP cutoff
- [ ] Freeze ontology before Phase B branch
