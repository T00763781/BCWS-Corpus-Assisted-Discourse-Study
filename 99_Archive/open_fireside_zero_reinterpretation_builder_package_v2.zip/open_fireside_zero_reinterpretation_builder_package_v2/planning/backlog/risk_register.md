# Risk Register

| Risk | Severity | Trigger | Mitigation |
|---|---|---|---|
| Ontology collapse between actors and protected continuities | High | Schema or adapter shortcuts | Privacy tests + anti-drift memo |
| Coverage collapse between locality structural/evidence states | High | Read model simplification | Separate fields + tests |
| Phase A scope creep into real-time infra | High | Builder adds scheduler early | Phase A cutoff enforcement |
| Export leakage of protected data | High | Read model misuse | Export policy schema + tests |
| Linkage overconfidence | Medium | Aggressive entity matching | Confidence schema + validation |
