
# Phase A MVP Cutoff

Phase A is complete only when:
- all 6 canonical fire centres are loaded and validated
- all 161 canonical B.C. municipalities are loaded and validated
- all 13 canonical external communities are loaded and validated
- minimum target matrix rows all pass their fixed validation rules
- minimal ontology fixture and reference validations pass
- incident, event-cluster, actor, account, discourse, protected-entity and export paths exist end-to-end.
