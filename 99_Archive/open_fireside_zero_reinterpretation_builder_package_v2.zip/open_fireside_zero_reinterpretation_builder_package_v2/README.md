
# Open Fireside Zero-Reinterpretation Builder Package v2

This package is the canonical implementation handoff for **Open Fireside**.

## Build objective
- Local-first implementation.
- Phase A historical-first build for **2025-04-01 through 2026-03-31**.
- Phase B real-time transition starting **2026-04-01**.

## SQL dialect
- PostgreSQL 16

## Bootstrap sequence
1. Apply SQL schema files in lexical order from `schema/sql/`.
2. Load canonical reference datasets from `reference/` using `ops/bootstrap/load_reference_data.sh`.
3. Validate reference dataset completeness with `validation/tests/test_reference_dataset_integrity.py` and `validation/tests/test_phase_a_target_matrix.py`.
4. Load the minimal ontology fixtures from `fixtures/minimal/minimal_fixture.sql`.
5. Run `ops/bootstrap/run_all_validations.sh`.

## Canonical reference universe fixed in this package
- 6 BC fire centres
- 161 BC incorporated municipalities as the complete Phase A structural B.C. municipality/locality reference layer
- 13 fixed external communities for cross-border context

## Phase A sign-off rule
Phase A structural sign-off is blocked if the canonical reference datasets or the target-matrix checks fail.
