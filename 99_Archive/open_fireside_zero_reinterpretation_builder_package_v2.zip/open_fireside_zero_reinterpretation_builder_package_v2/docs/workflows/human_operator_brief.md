
# Human Operator Brief

Inspect these files first:
- `reference/reference_layer_policy.md`
- `reference/phase_a_target_matrix.md`
- `schema/sql/005_reference_seed_tables.sql`
- `ops/bootstrap/load_reference_data.sh`
- `ops/bootstrap/run_all_validations.sh`
