# Research Workflows and UI Surfaces v1

## Actor/source workflows
- ingest public actor and source surface records
- link actor accounts to actors
- preserve source provenance on every normalized record

## Discourse explorer behavior
- browse discourse items, threads, media, and classifications
- filter by incident, event cluster, locality, fire centre, actor, source surface
- never treat discourse rows as replacements for core entities

## Incident reconstruction workflow
1. ingest incident
2. link to fire centre
3. link to localities
4. link to event cluster where applicable
5. attach discourse evidence and media
6. validate provenance/confidence

## Environment/discourse correlation workflow
Use incident, event cluster, locality, and time windows to compare discourse evidence against incident and location context.

## Protected identity review workflow
- route ambiguous/private persons into protected continuity tables
- review linkage through pseudonymous IDs only
- do not surface restricted identity fields in UI read models

## Locality/fire-centre comparison workflow
- compare localities within and across fire centres
- structural coverage and evidence coverage shown separately

## Export review workflow
- select analysis-safe read model
- bind redaction policy
- run export eligibility checks
- block output if privacy safeguards fail

## Core UI surfaces and purpose
- **Home**: seasonal state, validation summary
- **Fire Activity**: incidents, event clusters, fire centres
- **Map**: geography across fire centres, localities, incidents, event clusters
- **Incidents**: canonical incident detail
- **Discourse**: discourse explorer
- **Search**: entity and evidence lookup
- **Governance**: redaction/export review and audit
