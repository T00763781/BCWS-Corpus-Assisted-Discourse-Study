
Use the package files as the source of truth. Start with:
- `reference/reference_layer_policy.md`
- `reference/phase_a_target_matrix.md`
- `schema/dictionaries/entity_dictionary.md`
- `schema/sql/*.sql`
- `validation/tests/*.py`
Do not infer or extend reference populations beyond the canonical CSV files.
