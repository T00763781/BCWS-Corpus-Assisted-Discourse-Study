
# Anti-Drift Memo

The following are fixed and must not be reinterpreted:
- B.C. structural municipality/locality reference universe for Phase A = 161 incorporated municipalities only
- external-community reference universe for Phase A = fixed CSV list only
- fire-centre reference universe for Phase A = 6 BCWS regional fire centres
- Phase A sign-off is blocked if the target matrix or reference dataset tests fail
