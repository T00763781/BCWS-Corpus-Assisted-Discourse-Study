# Assumptions and Open Questions

## Fixed assumptions
- local database is PostgreSQL 16+
- validation runs locally with Python 3.11
- historical-first build uses replayed or imported historical material rather than live schedulers

## Open but non-ontological choices
- exact packaging tool for application runtime
- exact source-specific fetch implementation per upstream source
- exact local orchestration commands

## Source coverage unknowns
- source-specific field richness may vary across external wildfire/discourse sources
- some locality coverage thresholds may need tuning once larger datasets are ingested

## Locality threshold tuning questions
- what evidence count qualifies a locality as `PARTIAL` vs `SUFFICIENT`
- whether evidence thresholds should vary by fire centre or remain global

## Real-time scheduling questions
- exact scheduler choice after 2026-04-01
- checkpoint persistence strategy for incremental replay vs live polling
