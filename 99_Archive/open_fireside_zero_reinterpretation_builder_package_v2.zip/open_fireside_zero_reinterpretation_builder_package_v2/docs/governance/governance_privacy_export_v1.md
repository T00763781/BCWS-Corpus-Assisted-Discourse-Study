# Governance, Privacy, Export Standard v1

## Research posture
Open Fireside is an independent research system for wildfire information environments. It is not surveillance, enforcement, or citizen tracking.

## Identity classification policy
- **Public actor**: agency, organization, media outlet, program, elected office, official spokesperson, or public-role person relevant to wildfire information.
- **Protected private continuity**: any private person or ambiguous non-public person.
- When uncertain, classify as protected private continuity.

## Default-private rule
Ambiguous person identity classification defaults to protected/private storage.

## Pseudonymous continuity rules
Protected/private entities must be analyzed using `continuity_public_id`. Direct identity fields are never exposed in read models or exports.

## Restricted storage rules
Restricted identity-bearing data is allowed only in:
- `protected_private_entities`
- `protected_private_accounts`
- `protected_context_links`
- audit and redaction tables where necessary

## Export restrictions
- No export of restricted identity-bearing fields
- No export of protected accounts with raw handles unless explicitly redacted and approved
- All export jobs must bind to a redaction policy record

## Ethics/review policy
Any publication-facing export involving private continuity or small populations requires explicit review against the redaction policy.

## Security controls
- Restrict database role access to protected tables
- Restrict export generation to policy-aware workflows
- Log export and redaction actions

## Retention/deletion posture
Retain provenance and analysis-safe data for reproducibility. Restrict direct identity retention to the minimum needed for continuity and linkage verification.

## Publication safeguards
- No small-N exposures
- No direct identity publication from protected tables
- No publication of restricted handles or identifiers
- No export without associated policy record
