# Acceptance Criteria

## Package-complete criteria
The package is complete only if:
- all required directories exist
- canonical SQL files are executable PostgreSQL DDL
- JSON Schema contracts are valid JSON
- fixture data loads without schema violations
- validation tests exist and reference real files and entities
- anti-drift documents point to canonical artifacts

## Build-ready criteria
The build is ready only if:
- schema applies in order without modification
- fixture SQL inserts a coherent minimal ontology instance
- SQL assertions pass
- Python tests pass
- Phase A MVP items are implemented without Phase B dependencies
- privacy boundaries remain intact

## Ontology integrity checks
- public actors != protected private entities
- actor accounts != protected private accounts
- discourse evidence != primary ontology entities
- locality structural coverage != locality evidence coverage

## Governance/privacy checks
- protected fields never appear in analysis read models
- export jobs require redaction policy linkage
- default-private rule is encoded in docs and tests

## Phasing checks
- Phase A does not require schedulers or streaming infrastructure
- Phase B attaches to existing contracts without ontology change
