
# Codex Build Brief

Build order is fixed by package artifacts:
1. `schema/sql/*.sql`
2. `reference/*.csv`
3. `ops/bootstrap/load_reference_data.sh`
4. `fixtures/minimal/minimal_fixture.sql`
5. `ops/bootstrap/run_all_validations.sh`

Do not change:
- reference population counts
- reference CSV field names
- target matrix rules
- separation of public actors vs protected private continuity entities
- separation of actor accounts vs protected private accounts
