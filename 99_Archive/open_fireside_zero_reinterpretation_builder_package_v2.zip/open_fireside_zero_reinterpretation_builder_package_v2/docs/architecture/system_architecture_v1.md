# System Architecture v1

## Local-first architecture
Open Fireside runs as a local-first system with local database, local fixture loading, local validation, and local ingestion execution. Phase A has no dependency on real-time schedulers or cloud services.

## Modular proof-of-concept path
### Phase A — Historical reconstruction mode
Build a closed-loop system for the 2025-04-01 through 2026-03-31 period:
- load canonical schema
- normalize historical data into stable entities
- preserve provenance and privacy controls
- build research read models
- validate ontology and privacy boundaries

### Phase B — Future real-time mode
Starting 2026-04-01:
- attach schedulers
- add incremental ingestion checkpoints
- add ongoing change detection
- preserve the same normalized models and privacy boundaries

## Module boundaries
- `schema/`: canonical storage model
- `ingest/`: normalization adapters and linkage emitters
- `validation/`: integrity and privacy verification
- `app/read_models/`: deterministic read-model contracts
- `app/workflows/`: workflow orchestration rules
- `docs/governance/`: mandatory governance and export controls

## Canonical ontology/entity boundaries
- Public actors are distinct from protected private continuity entities.
- Actor accounts are distinct from protected private accounts.
- Discourse evidence is distinct from the primary ontology.
- Fire Centres are first-class aggregation entities.
- Locality structural coverage is distinct from locality evidence coverage.

## Evidence flow model
1. Raw source material is fetched externally.
2. Adapters normalize records into schema contracts.
3. Entity linkage emits confidence-scored links.
4. Protected/private information is routed to protected tables only.
5. Read models assemble analysis-safe views.
6. Export/redaction policy filters output.

## Protected identity subsystem
Protected/private entities are handled through:
- `protected_private_entities`
- `protected_private_accounts`
- `protected_context_links`
- export suppression/redaction rules

No protected row is inserted into the public actor tables.

## Ingestion contracts
Each ingestion adapter must implement deterministic interfaces for:
- incident/event records
- public actor records
- public account records
- discourse/evidence records
- locality/fire-centre records
- protected continuity records

## Validation pipeline
The canonical validation pipeline includes:
1. SQL schema assertions
2. fixture consistency tests
3. ontology boundary tests
4. privacy boundary tests
5. phasing tests
6. acceptance criteria checks

## Storage/read model separation
Storage tables preserve normalized evidence and provenance. Read models only expose analysis-safe projected views and must not leak restricted fields.

## UI surface model
Phase A supports these canonical surfaces:
- Home: seasonal summary and validation state
- Fire Activity: incident/event/fire-centre activity
- Map: locality, fire-centre, incident, and event geography
- Incidents: canonical incident detail
- Discourse: evidence explorer
- Search: entity and evidence search
- Governance: redaction/export review
