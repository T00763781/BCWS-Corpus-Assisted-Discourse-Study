# Research Proposal v2

## Mission
Open Fireside is a local-first research system for reconstructing and analyzing wildfire information environments using public wildfire, geospatial, institutional, and discourse evidence.

## Research problem
Wildfire understanding is fragmented across incident records, maps, agency communications, news, and public discourse. Open Fireside provides a durable, evidence-first system that reconstructs these layers for the 2025-2026 wildfire calendar year and supports later real-time continuation.

## Analytical domains
- Incident records
- Event clusters
- Fire Centres
- Localities and municipalities
- Public actors
- Actor accounts
- Source surfaces
- Discourse items, threads, and media
- Protected private continuity entities and accounts
- Governance and redaction actions

## Hybrid ontology
The system uses a hybrid ontology with the following rules:
- **Primary public ontology:** actors, actor accounts, source surfaces, incidents, fire centres, localities, event clusters
- **Evidence ontology:** discourse items, discourse threads, discourse media, linkages, classifications
- **Protected continuity ontology:** protected private continuities and protected private accounts are separate from public actors and actor accounts

## Fire Centres as first-class entities
Fire Centres are required top-level entities for aggregation, comparison, incident grouping, and workflow views.

## Locality / municipality coverage concept
Every locality stores two separate completion states:
- `structural_coverage_status`: whether the locality exists in the reference layer and has canonical structural fields populated
- `evidence_coverage_status`: whether the locality has sufficient attached evidence for analysis in the target season

These statuses must never be collapsed.

## Protected private identity principle
Private persons are not ordinary actors. They are stored only as protected continuity entities and analyzed through pseudonymous continuity IDs. Direct identity attributes are isolated in restricted storage.

## Event and jurisdiction scope
- Events may span multiple incidents.
- Events may span multiple localities and jurisdictions.
- Cross-jurisdiction handling is required whenever an event cluster touches multiple administrative areas or information domains.

## Methodological posture
- Evidence first
- Preserve provenance
- Preserve timestamps
- Preserve context links
- Default private when ambiguity exists in person identity classification
- Favor reproducible reconstruction over inferential expansion

## Non-surveillance framing
Open Fireside is not a surveillance or citizen-monitoring platform. It is a research system for studying wildfire information environments, public communications, narrative diffusion, and incident context.

## Success criteria
The system succeeds when it can, for the 2025-2026 season:
1. reconstruct incident, locality, fire-centre, actor, source, and discourse evidence
2. preserve provenance and confidence for all linkages
3. analyze discourse without collapsing it into the primary ontology
4. protect private persons through pseudonymous continuity and export controls
5. pass all validation, ontology, privacy, and phasing checks
