# Requirements Matrix

| Requirement | Proposal | Architecture | Schema | Governance | Workflows/UI | Notes |
|---|---|---|---|---|---|---|
| Local-first operation | Yes | Yes | Indirect | Indirect | Yes | Phase A requires local-only operation |
| Historical Phase A window 2025-04-01 to 2026-03-31 | Yes | Yes | Yes | Indirect | Yes | Hard seasonal scope |
| Real-time Phase B starts 2026-04-01 | Yes | Yes | Yes | Indirect | Yes | Deferred cleanly |
| Fire Centres are first-class entities | Yes | Yes | Yes | No | Yes | Not optional |
| Structural locality coverage | Yes | Yes | Yes | No | Yes | Separate from evidence |
| Locality evidence coverage | Yes | Yes | Yes | No | Yes | Separate from structural |
| Public actor model | Yes | Yes | Yes | Yes | Yes | Public only |
| Protected private continuity model | Yes | Yes | Yes | Yes | Yes | Separate subsystem |
| Actor accounts | Yes | Yes | Yes | Yes | Yes | Public accounts only |
| Protected private accounts | Yes | Yes | Yes | Yes | Yes | Separate subsystem |
| Discourse as evidence domain | Yes | Yes | Yes | Yes | Yes | Not primary ontology |
| Event clusters | Yes | Yes | Yes | No | Yes | Multi-incident possible |
| Cross-jurisdiction handling | Yes | Yes | Yes | Yes | Yes | Required for clusters |
| Temporal normalization | Yes | Yes | Yes | No | Yes | UTC storage |
| Geospatial normalization | Yes | Yes | Yes | No | Yes | Geometry + centroid rules |
| Linkage confidence | Yes | Yes | Yes | Yes | Yes | Confidence-scored links |
| Provenance retention | Yes | Yes | Yes | Yes | Yes | Source-first evidence |
| Export redaction controls | No | Yes | Yes | Yes | Yes | Mandatory |
| Small-N safeguards | No | No | Indirect | Yes | Yes | Required before export |
| Validation pipeline | Yes | Yes | Yes | Yes | Yes | Canonical tests included |
| Anti-drift continuity | No | Yes | Yes | Yes | Yes | Decision log + briefs |
