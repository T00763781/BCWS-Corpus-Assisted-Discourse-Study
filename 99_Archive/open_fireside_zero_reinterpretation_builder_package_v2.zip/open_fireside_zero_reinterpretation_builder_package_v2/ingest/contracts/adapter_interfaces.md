
# Adapter Interfaces

## LocalityFireCentreAdapter
- `load_fire_centres() -> list[dict]`
- `load_reference_places() -> list[dict]`
- `normalize_fire_centre(raw_record: dict) -> dict`
- `normalize_locality(raw_record: dict) -> dict`
- `emit_links(normalized_record: dict) -> list[dict]`

## IncidentEventAdapter
- `normalize_incident(raw_record: dict) -> dict`
- `normalize_event_cluster(raw_record: dict) -> dict`
- `emit_links(normalized_record: dict) -> list[dict]`

## ActorAdapter
- `normalize(raw_record: dict) -> dict`

## AccountAdapter
- `normalize(raw_record: dict) -> dict`

## DiscourseEvidenceAdapter
- `normalize(raw_record: dict) -> dict`

## ProtectedContinuityAdapter
- `normalize(raw_record: dict) -> dict`
