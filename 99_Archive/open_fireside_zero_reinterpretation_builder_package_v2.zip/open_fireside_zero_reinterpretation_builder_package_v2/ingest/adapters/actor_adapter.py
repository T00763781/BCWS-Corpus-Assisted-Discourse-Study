from __future__ import annotations

class ActorAdapter:
    def normalize(self, raw_record: dict) -> dict:
        return {'canonical_actor_name': raw_record['canonical_actor_name'], 'actor_type': raw_record['actor_type'], 'provenance_note': raw_record['provenance_note']}
