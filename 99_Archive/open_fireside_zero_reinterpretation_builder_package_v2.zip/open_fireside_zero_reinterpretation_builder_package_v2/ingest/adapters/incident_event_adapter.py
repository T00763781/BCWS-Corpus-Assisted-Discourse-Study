
from __future__ import annotations

class IncidentEventAdapter:
    def normalize_incident(self, raw_record: dict) -> dict:
        return {
            'canonical_incident_number': raw_record['incident_number'],
            'canonical_incident_name': raw_record['incident_name'],
            'incident_start_date': raw_record['incident_start_date'],
            'incident_end_date': raw_record.get('incident_end_date'),
            'stage_of_control': raw_record.get('stage_of_control'),
            'cause_category': raw_record.get('cause_category'),
            'source_surface_canonical_name': raw_record['source_surface_canonical_name'],
        }

    def normalize_event_cluster(self, raw_record: dict) -> dict:
        return {
            'canonical_event_cluster_name': raw_record['canonical_event_cluster_name'],
            'event_start_date': raw_record['event_start_date'],
            'event_end_date': raw_record.get('event_end_date'),
            'cross_jurisdiction_flag': bool(raw_record.get('cross_jurisdiction_flag', False)),
        }

    def emit_links(self, normalized_record: dict) -> list[dict]:
        links = []
        cluster = normalized_record.get('canonical_event_cluster_name')
        incident = normalized_record.get('canonical_incident_number')
        if incident and cluster:
            links.append({'incident_number': incident, 'event_cluster_name': cluster})
        return links
