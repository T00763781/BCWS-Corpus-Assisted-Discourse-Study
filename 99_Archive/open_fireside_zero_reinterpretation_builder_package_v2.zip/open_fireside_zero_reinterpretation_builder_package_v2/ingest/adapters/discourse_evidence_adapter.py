from __future__ import annotations

class DiscourseEvidenceAdapter:
    def normalize(self, raw_record: dict) -> dict:
        return {'external_item_id': raw_record['external_item_id'], 'discourse_item_type': raw_record['discourse_item_type'], 'privacy_classification': raw_record['privacy_classification'], 'source_surface_canonical_name': raw_record['source_surface_canonical_name']}
