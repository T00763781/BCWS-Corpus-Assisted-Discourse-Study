from __future__ import annotations

class ProtectedContinuityAdapter:
    def normalize(self, raw_record: dict) -> dict:
        return {'continuity_public_id': raw_record['continuity_public_id'], 'provenance_note': raw_record['provenance_note'], 'privacy_classification': 'PROTECTED_PRIVATE'}
