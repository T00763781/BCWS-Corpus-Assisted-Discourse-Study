
from __future__ import annotations

import csv
from pathlib import Path

class LocalityFireCentreAdapter:
    def __init__(self, root: str | Path):
        self.root = Path(root)

    def load_fire_centres(self) -> list[dict]:
        with open(self.root / 'reference' / 'bc_fire_centres.csv', encoding='utf-8') as fh:
            return list(csv.DictReader(fh))

    def load_reference_places(self) -> list[dict]:
        rows: list[dict] = []
        for name in ['bc_municipalities_or_localities.csv', 'external_communities.csv']:
            with open(self.root / 'reference' / name, encoding='utf-8') as fh:
                rows.extend(csv.DictReader(fh))
        return rows

    def normalize_fire_centre(self, raw_record: dict) -> dict:
        return {
            'canonical_id': raw_record['canonical_id'],
            'canonical_name': raw_record['canonical_name'],
            'type': raw_record['type'],
            'province_state_territory': raw_record['province_state_territory'],
            'country': raw_record['country'],
            'active_in_phase_a': raw_record['active_in_phase_a'].lower() == 'true',
        }

    def normalize_locality(self, raw_record: dict) -> dict:
        return {
            'canonical_id': raw_record['canonical_id'],
            'canonical_name': raw_record['canonical_name'],
            'type': raw_record['type'],
            'province_state_territory': raw_record['province_state_territory'],
            'country': raw_record['country'],
            'inclusion_basis': raw_record['inclusion_basis'],
            'fire_centre_linkage': raw_record['fire_centre_linkage'] or None,
            'boundary_classification': raw_record['boundary_classification'],
            'active_in_phase_a': raw_record['active_in_phase_a'].lower() == 'true',
            'notes_provenance': raw_record['notes_provenance'],
        }

    def emit_links(self, normalized_record: dict) -> list[dict]:
        if normalized_record.get('fire_centre_linkage'):
            return [{'source_canonical_id': normalized_record['canonical_id'], 'target_fire_centre_canonical_id': normalized_record['fire_centre_linkage']}]
        return []
