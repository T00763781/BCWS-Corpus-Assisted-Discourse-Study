from __future__ import annotations

class AccountAdapter:
    def normalize(self, raw_record: dict) -> dict:
        return {'actor_canonical_name': raw_record['actor_canonical_name'], 'platform': raw_record['platform'], 'account_handle': raw_record['account_handle'], 'account_url': raw_record.get('account_url')}
