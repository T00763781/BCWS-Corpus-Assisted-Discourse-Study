CREATE TABLE fire_centres (
    fire_centre_id uuid PRIMARY KEY,
    fire_centre_code text NOT NULL UNIQUE,
    fire_centre_name text NOT NULL UNIQUE,
    province_code text NOT NULL,
    geometry_wkt text,
    centroid_lat numeric(9,6),
    centroid_lon numeric(9,6),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CHECK ((centroid_lat IS NULL AND centroid_lon IS NULL) OR (centroid_lat IS NOT NULL AND centroid_lon IS NOT NULL))
);

CREATE TABLE localities (
    locality_id uuid PRIMARY KEY,
    canonical_locality_name text NOT NULL,
    municipality_name text,
    province_code text NOT NULL,
    country_code text NOT NULL,
    fire_centre_id uuid NOT NULL REFERENCES fire_centres(fire_centre_id),
    structural_coverage_status coverage_status NOT NULL,
    evidence_coverage_status coverage_status NOT NULL,
    geometry_wkt text,
    centroid_lat numeric(9,6),
    centroid_lon numeric(9,6),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (canonical_locality_name, province_code, country_code)
);

CREATE TABLE source_surfaces (
    source_surface_id uuid PRIMARY KEY,
    canonical_source_name text NOT NULL UNIQUE,
    source_surface_type source_surface_type NOT NULL,
    base_url text NOT NULL,
    provenance_rule text NOT NULL,
    privacy_classification privacy_classification NOT NULL DEFAULT 'PUBLIC',
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE actors (
    actor_id uuid PRIMARY KEY,
    canonical_actor_name text NOT NULL UNIQUE,
    actor_type actor_type NOT NULL,
    is_public_role boolean NOT NULL DEFAULT true,
    source_surface_id uuid REFERENCES source_surfaces(source_surface_id),
    provenance_note text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE actor_accounts (
    actor_account_id uuid PRIMARY KEY,
    actor_id uuid NOT NULL REFERENCES actors(actor_id) ON DELETE CASCADE,
    platform account_platform NOT NULL,
    account_handle text NOT NULL,
    account_url text,
    is_verified boolean NOT NULL DEFAULT false,
    source_surface_id uuid REFERENCES source_surfaces(source_surface_id),
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (platform, account_handle)
);

CREATE TABLE incidents (
    incident_id uuid PRIMARY KEY,
    canonical_incident_number text NOT NULL UNIQUE,
    canonical_incident_name text NOT NULL,
    fire_centre_id uuid NOT NULL REFERENCES fire_centres(fire_centre_id),
    incident_start_date date NOT NULL,
    incident_end_date date,
    stage_of_control text,
    cause_category text,
    centroid_lat numeric(9,6),
    centroid_lon numeric(9,6),
    geometry_wkt text,
    source_surface_id uuid REFERENCES source_surfaces(source_surface_id),
    provenance_note text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CHECK (incident_end_date IS NULL OR incident_end_date >= incident_start_date)
);

CREATE TABLE event_clusters (
    event_cluster_id uuid PRIMARY KEY,
    canonical_event_cluster_name text NOT NULL UNIQUE,
    event_start_date date NOT NULL,
    event_end_date date,
    cross_jurisdiction_flag boolean NOT NULL DEFAULT false,
    provenance_note text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (event_end_date IS NULL OR event_end_date >= event_start_date)
);

CREATE TABLE incident_event_cluster_links (
    incident_id uuid NOT NULL REFERENCES incidents(incident_id) ON DELETE CASCADE,
    event_cluster_id uuid NOT NULL REFERENCES event_clusters(event_cluster_id) ON DELETE CASCADE,
    link_confidence numeric(4,3) NOT NULL,
    provenance_note text NOT NULL,
    PRIMARY KEY (incident_id, event_cluster_id),
    CHECK (link_confidence >= 0.000 AND link_confidence <= 1.000)
);

CREATE TABLE incident_locality_links (
    incident_id uuid NOT NULL REFERENCES incidents(incident_id) ON DELETE CASCADE,
    locality_id uuid NOT NULL REFERENCES localities(locality_id) ON DELETE CASCADE,
    link_confidence numeric(4,3) NOT NULL,
    provenance_note text NOT NULL,
    PRIMARY KEY (incident_id, locality_id),
    CHECK (link_confidence >= 0.000 AND link_confidence <= 1.000)
);
