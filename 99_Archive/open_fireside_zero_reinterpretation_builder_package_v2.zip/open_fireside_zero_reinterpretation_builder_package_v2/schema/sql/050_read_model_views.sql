
CREATE OR REPLACE VIEW incident_detail_view AS
SELECT
    i.incident_id,
    i.canonical_incident_number,
    i.canonical_incident_name,
    i.incident_start_date,
    i.incident_end_date,
    i.stage_of_control,
    i.cause_category,
    fc.fire_centre_name,
    s.canonical_source_name AS primary_source_name,
    COUNT(DISTINCT il.locality_id) AS linked_locality_count,
    COUNT(DISTINCT iecl.event_cluster_id) AS linked_event_cluster_count
FROM incidents i
JOIN fire_centres fc ON fc.fire_centre_id = i.fire_centre_id
LEFT JOIN source_surfaces s ON s.source_surface_id = i.source_surface_id
LEFT JOIN incident_locality_links il ON il.incident_id = i.incident_id
LEFT JOIN incident_event_cluster_links iecl ON iecl.incident_id = i.incident_id
GROUP BY i.incident_id, fc.fire_centre_name, s.canonical_source_name;

CREATE OR REPLACE VIEW locality_comparison_view AS
SELECT
    l.locality_id,
    l.canonical_locality_name,
    l.structural_coverage_status,
    l.evidence_coverage_status,
    fc.fire_centre_name,
    COUNT(DISTINCT ill.incident_id) AS linked_incident_count
FROM localities l
JOIN fire_centres fc ON fc.fire_centre_id = l.fire_centre_id
LEFT JOIN incident_locality_links ill ON ill.locality_id = l.locality_id
GROUP BY l.locality_id, fc.fire_centre_name;
