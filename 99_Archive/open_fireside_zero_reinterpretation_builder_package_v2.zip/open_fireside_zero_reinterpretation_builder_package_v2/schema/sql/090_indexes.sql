CREATE INDEX idx_localities_fire_centre_id ON localities(fire_centre_id);
CREATE INDEX idx_incidents_fire_centre_id ON incidents(fire_centre_id);
CREATE INDEX idx_actor_accounts_actor_id ON actor_accounts(actor_id);
CREATE INDEX idx_discourse_items_thread_id ON discourse_items(discourse_thread_id);
CREATE INDEX idx_discourse_items_actor_account_id ON discourse_items(actor_account_id);
CREATE INDEX idx_discourse_items_protected_account_id ON discourse_items(protected_account_id);
CREATE INDEX idx_entity_links_source ON entity_links(source_entity_type, source_entity_id);
CREATE INDEX idx_entity_links_target ON entity_links(target_entity_type, target_entity_id);
CREATE INDEX idx_protected_context_links_target ON protected_context_links(target_type, target_id);
