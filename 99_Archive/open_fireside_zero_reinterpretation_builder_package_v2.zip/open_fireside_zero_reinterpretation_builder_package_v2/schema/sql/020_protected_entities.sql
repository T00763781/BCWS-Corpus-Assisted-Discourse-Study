CREATE TABLE protected_private_entities (
    protected_entity_id uuid PRIMARY KEY,
    continuity_public_id text NOT NULL UNIQUE,
    restricted_display_name text NOT NULL,
    identity_hash text NOT NULL UNIQUE,
    privacy_classification privacy_classification NOT NULL DEFAULT 'PROTECTED_PRIVATE',
    provenance_note text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE protected_private_accounts (
    protected_account_id uuid PRIMARY KEY,
    protected_entity_id uuid NOT NULL REFERENCES protected_private_entities(protected_entity_id) ON DELETE CASCADE,
    platform account_platform NOT NULL,
    restricted_account_handle text NOT NULL,
    handle_hash text NOT NULL UNIQUE,
    source_surface_id uuid REFERENCES source_surfaces(source_surface_id),
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (protected_entity_id, platform, restricted_account_handle)
);

CREATE TABLE protected_context_links (
    protected_context_link_id uuid PRIMARY KEY,
    protected_entity_id uuid REFERENCES protected_private_entities(protected_entity_id) ON DELETE CASCADE,
    protected_account_id uuid REFERENCES protected_private_accounts(protected_account_id) ON DELETE CASCADE,
    target_type link_target_type NOT NULL,
    target_id uuid NOT NULL,
    link_confidence numeric(4,3) NOT NULL,
    provenance_note text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK ((protected_entity_id IS NOT NULL) <> (protected_account_id IS NOT NULL)),
    CHECK (link_confidence >= 0.000 AND link_confidence <= 1.000)
);
