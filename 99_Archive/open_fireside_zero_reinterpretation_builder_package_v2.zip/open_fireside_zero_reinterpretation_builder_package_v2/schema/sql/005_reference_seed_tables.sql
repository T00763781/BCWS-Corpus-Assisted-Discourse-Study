
CREATE TABLE reference_fire_centres (
    canonical_id text PRIMARY KEY,
    canonical_name text NOT NULL UNIQUE,
    type text NOT NULL CHECK (type = 'fire_centre'),
    province_state_territory text NOT NULL,
    country text NOT NULL,
    inclusion_basis text NOT NULL,
    fire_centre_linkage text NOT NULL,
    boundary_classification text NOT NULL,
    active_in_phase_a boolean NOT NULL,
    notes_provenance text NOT NULL
);

CREATE TABLE reference_places (
    canonical_id text PRIMARY KEY,
    canonical_name text NOT NULL,
    type text NOT NULL CHECK (type IN ('municipality', 'locality', 'external_community')),
    province_state_territory text NOT NULL,
    country text NOT NULL,
    inclusion_basis text NOT NULL,
    fire_centre_linkage text,
    boundary_classification text NOT NULL,
    active_in_phase_a boolean NOT NULL,
    notes_provenance text NOT NULL
);

CREATE TABLE reference_event_clusters (
    canonical_id text PRIMARY KEY,
    canonical_name text NOT NULL UNIQUE,
    event_start_date date NOT NULL,
    event_end_date date,
    cross_jurisdiction_flag boolean NOT NULL DEFAULT false,
    notes_provenance text NOT NULL,
    CHECK (event_end_date IS NULL OR event_end_date >= event_start_date)
);

CREATE TABLE phase_a_target_matrix (
    requirement text PRIMARY KEY,
    target_basis text NOT NULL,
    minimum_required_count_or_coverage_rule text NOT NULL,
    coverage_mode text NOT NULL CHECK (coverage_mode IN ('EXHAUSTIVE','THRESHOLD')),
    required_before_phase_a_signoff text NOT NULL CHECK (required_before_phase_a_signoff IN ('YES','NO')),
    validation_method text NOT NULL,
    failure_condition text NOT NULL
);
