# Canonical Entity Dictionary

Public actors are distinct from protected private continuity entities. Actor accounts are distinct from protected private accounts. Structural locality coverage is distinct from evidence coverage.


## fire_centres
| Field | Type | Null | PK | FK | Unique | Enum | Privacy | Validation | Provenance |
|---|---|---:|---:|---:|---:|---|---|---|---|
| fire_centre_id | uuid | No | Yes | No | Yes |  | PUBLIC | valid uuid | system/generated |
| fire_centre_code | text | No | No | No | Yes |  | PUBLIC | non-empty | source-derived canonical code |
| fire_centre_name | text | No | No | No | Yes |  | PUBLIC | non-empty | source-derived canonical name |
| province_code | text | No | No | No | No |  | PUBLIC | 2+ chars | reference/source |
| geometry_wkt | text | Yes | No | No | No |  | PUBLIC | valid WKT if present | source geometry |
| centroid_lat | numeric(9,6) | Yes | No | No | No |  | PUBLIC | paired with lon | source-derived |
| centroid_lon | numeric(9,6) | Yes | No | No | No |  | PUBLIC | paired with lat | source-derived |

## localities
| Field | Type | Null | PK | FK | Unique | Enum | Privacy | Validation | Provenance |
|---|---|---:|---:|---:|---:|---|---|---|---|
| locality_id | uuid | No | Yes | No | Yes |  | PUBLIC | valid uuid | system/generated |
| canonical_locality_name | text | No | No | No | composite |  | PUBLIC | non-empty | source/reference canonicalization |
| municipality_name | text | Yes | No | No | No |  | PUBLIC |  | source/reference |
| province_code | text | No | No | No | composite |  | PUBLIC | non-empty | source/reference |
| country_code | text | No | No | No | composite |  | PUBLIC | non-empty | source/reference |
| fire_centre_id | uuid | No | No | Yes | No |  | PUBLIC | existing fire centre | source linkage |
| structural_coverage_status | coverage_status | No | No | No | No | NONE, STRUCTURAL_ONLY, PARTIAL, SUFFICIENT | PUBLIC | must exist | validation-derived |
| evidence_coverage_status | coverage_status | No | No | No | No | NONE, STRUCTURAL_ONLY, PARTIAL, SUFFICIENT | PUBLIC | must exist and remain distinct | validation-derived |
| geometry_wkt | text | Yes | No | No | No |  | PUBLIC | valid WKT if present | source geometry |
| centroid_lat | numeric(9,6) | Yes | No | No | No |  | PUBLIC | paired with lon | source-derived |
| centroid_lon | numeric(9,6) | Yes | No | No | No |  | PUBLIC | paired with lat | source-derived |

## source_surfaces
| Field | Type | Null | PK | FK | Unique | Enum | Privacy | Validation | Provenance |
|---|---|---:|---:|---:|---:|---|---|---|---|
| source_surface_id | uuid | No | Yes | No | Yes |  | PUBLIC | valid uuid | system/generated |
| canonical_source_name | text | No | No | No | Yes |  | PUBLIC | non-empty | canonical naming |
| source_surface_type | source_surface_type | No | No | No | No | API, WEBSITE, SOCIAL_PLATFORM, MEDIA_SITE, MAP_LAYER | PUBLIC | enum required | source classification |
| base_url | text | No | No | No | No |  | PUBLIC | absolute URL expected | source origin |
| provenance_rule | text | No | No | No | No |  | PUBLIC | non-empty | canonical provenance policy |
| privacy_classification | privacy_classification | No | No | No | No | PUBLIC, PROTECTED_PRIVATE, RESTRICTED | PUBLIC | enum required | governance rule |

## actors
| Field | Type | Null | PK | FK | Unique | Enum | Privacy | Validation | Provenance |
|---|---|---:|---:|---:|---:|---|---|---|---|
| actor_id | uuid | No | Yes | No | Yes |  | PUBLIC | valid uuid | system/generated |
| canonical_actor_name | text | No | No | No | Yes |  | PUBLIC | non-empty | source canonicalization |
| actor_type | actor_type | No | No | No | No | AGENCY, ORGANIZATION, MEDIA, PROGRAM, PUBLIC_ROLE_PERSON | PUBLIC | enum required | source classification |
| is_public_role | boolean | No | No | No | No |  | PUBLIC | true expected for person actors | governance rule |
| source_surface_id | uuid | Yes | No | Yes | No |  | PUBLIC | existing source surface if present | provenance source |
| provenance_note | text | No | No | No | No |  | PUBLIC | non-empty | required provenance |

## actor_accounts
| Field | Type | Null | PK | FK | Unique | Enum | Privacy | Validation | Provenance |
|---|---|---:|---:|---:|---:|---|---|---|---|
| actor_account_id | uuid | No | Yes | No | Yes |  | PUBLIC | valid uuid | system/generated |
| actor_id | uuid | No | No | Yes | No |  | PUBLIC | existing actor | linkage |
| platform | account_platform | No | No | No | composite | WEBSITE, X, FACEBOOK, INSTAGRAM, YOUTUBE, REDDIT, FORUM | PUBLIC | enum required | source classification |
| account_handle | text | No | No | No | composite |  | PUBLIC | non-empty | source handle |
| account_url | text | Yes | No | No | No |  | PUBLIC | URL if present | source URL |
| is_verified | boolean | No | No | No | No |  | PUBLIC | boolean | source metadata |
| source_surface_id | uuid | Yes | No | Yes | No |  | PUBLIC | existing source surface if present | provenance source |

## incidents
| Field | Type | Null | PK | FK | Unique | Enum | Privacy | Validation | Provenance |
|---|---|---:|---:|---:|---:|---|---|---|---|
| incident_id | uuid | No | Yes | No | Yes |  | PUBLIC | valid uuid | system/generated |
| canonical_incident_number | text | No | No | No | Yes |  | PUBLIC | non-empty | canonical source id |
| canonical_incident_name | text | No | No | No | No |  | PUBLIC | non-empty | source canonicalization |
| fire_centre_id | uuid | No | No | Yes | No |  | PUBLIC | existing fire centre | source linkage |
| incident_start_date | date | No | No | No | No |  | PUBLIC | within known season if Phase A | source timestamp |
| incident_end_date | date | Yes | No | No | No |  | PUBLIC | >= start if present | source timestamp |
| stage_of_control | text | Yes | No | No | No |  | PUBLIC | free text normalized upstream | source field |
| cause_category | text | Yes | No | No | No |  | PUBLIC | free text normalized upstream | source field |
| centroid_lat | numeric(9,6) | Yes | No | No | No |  | PUBLIC | paired with lon | source-derived |
| centroid_lon | numeric(9,6) | Yes | No | No | No |  | PUBLIC | paired with lat | source-derived |
| geometry_wkt | text | Yes | No | No | No |  | PUBLIC | valid WKT if present | source geometry |
| source_surface_id | uuid | Yes | No | Yes | No |  | PUBLIC | existing source surface | provenance source |
| provenance_note | text | No | No | No | No |  | PUBLIC | non-empty | required provenance |

## event_clusters
| Field | Type | Null | PK | FK | Unique | Enum | Privacy | Validation | Provenance |
|---|---|---:|---:|---:|---:|---|---|---|---|
| event_cluster_id | uuid | No | Yes | No | Yes |  | PUBLIC | valid uuid | system/generated |
| canonical_event_cluster_name | text | No | No | No | Yes |  | PUBLIC | non-empty | canonical naming |
| event_start_date | date | No | No | No | No |  | PUBLIC | within target history if Phase A | source-derived |
| event_end_date | date | Yes | No | No | No |  | PUBLIC | >= start if present | source-derived |
| cross_jurisdiction_flag | boolean | No | No | No | No |  | PUBLIC | boolean | analysis/source-derived |
| provenance_note | text | No | No | No | No |  | PUBLIC | non-empty | required provenance |

## discourse_threads / discourse_items / discourse_media / discourse_classifications
All discourse tables are **PUBLIC evidence tables** unless item classification explicitly changes. `actor_account_id` and `protected_account_id` are mutually exclusive. External ids must be unique by source/platform scope. Provenance is derived from source surface, external ids, and ingestion time.

## protected_private_entities
| Field | Type | Null | PK | FK | Unique | Enum | Privacy | Validation | Provenance |
|---|---|---:|---:|---:|---:|---|---|---|---|
| protected_entity_id | uuid | No | Yes | No | Yes |  | RESTRICTED | valid uuid | system/generated |
| continuity_public_id | text | No | No | No | Yes |  | PROTECTED_PRIVATE | non-empty pseudonymous id | generated continuity id |
| restricted_display_name | text | No | No | No | No |  | RESTRICTED | non-empty | restricted source-derived |
| identity_hash | text | No | No | No | Yes |  | RESTRICTED | non-empty | derived restricted hash |
| privacy_classification | privacy_classification | No | No | No | No | PROTECTED_PRIVATE | RESTRICTED | must be PROTECTED_PRIVATE | governance |
| provenance_note | text | No | No | No | No |  | RESTRICTED | non-empty | required provenance |

## protected_private_accounts
| Field | Type | Null | PK | FK | Unique | Enum | Privacy | Validation | Provenance |
|---|---|---:|---:|---:|---:|---|---|---|---|
| protected_account_id | uuid | No | Yes | No | Yes |  | RESTRICTED | valid uuid | system/generated |
| protected_entity_id | uuid | No | No | Yes | No |  | RESTRICTED | existing protected entity | linkage |
| platform | account_platform | No | No | No | No | WEBSITE, X, FACEBOOK, INSTAGRAM, YOUTUBE, REDDIT, FORUM | RESTRICTED | enum required | source classification |
| restricted_account_handle | text | No | No | No | No |  | RESTRICTED | non-empty | restricted source field |
| handle_hash | text | No | No | No | Yes |  | RESTRICTED | non-empty | derived restricted hash |
| source_surface_id | uuid | Yes | No | Yes | No |  | RESTRICTED | existing source if present | provenance source |

## protected_context_links / entity_links / export and audit tables
These tables preserve linkage confidence, provenance, validation summaries, and export policy enforcement. `entity_links` is analysis-safe. `protected_context_links` is restricted. `export_jobs` must reference `redaction_policies`.


## Reference Layer Entities

### reference_fire_centres
- canonical_id: text, not null, primary key, privacy=PUBLIC, provenance=canonical CSV seed
- canonical_name: text, not null, unique, privacy=PUBLIC
- type: text, not null, fixed `fire_centre`
- province_state_territory: text, not null
- country: text, not null
- inclusion_basis: text, not null
- fire_centre_linkage: text, not null, self-link to canonical_id
- boundary_classification: text, not null, fixed `BC_INTERNAL`
- active_in_phase_a: boolean, not null
- notes_provenance: text, not null

### reference_places
- canonical_id: text, not null, primary key, privacy=PUBLIC, provenance=canonical CSV seed
- canonical_name: text, not null
- type: text, not null, enum-like values: `municipality`, `locality`, `external_community`
- province_state_territory: text, not null
- country: text, not null
- inclusion_basis: text, not null
- fire_centre_linkage: text, nullable; blank for Phase A BC municipalities until boundary overlay resolution
- boundary_classification: text, not null, values used in package: `BC_INTERNAL`, `EXTERNAL_BORDER_REGION`
- active_in_phase_a: boolean, not null
- notes_provenance: text, not null
