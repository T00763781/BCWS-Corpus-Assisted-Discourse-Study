
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
python3 -m pytest "$ROOT/validation/tests/test_reference_dataset_integrity.py" -q
python3 -m pytest "$ROOT/validation/tests/test_phase_a_target_matrix.py" -q
python3 -m pytest "$ROOT/validation/tests/test_fixture_integrity.py" -q
python3 -m pytest "$ROOT/validation/tests/test_ontology_boundaries.py" -q
python3 -m pytest "$ROOT/validation/tests/test_phase_boundaries.py" -q
python3 -m pytest "$ROOT/validation/tests/test_privacy_boundaries.py" -q
