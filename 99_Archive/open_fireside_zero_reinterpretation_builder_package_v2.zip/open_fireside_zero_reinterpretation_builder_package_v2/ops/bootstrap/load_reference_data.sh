
#!/usr/bin/env bash
set -euo pipefail
: "${PGDATABASE:?PGDATABASE must be set}"
: "${PGUSER:?PGUSER must be set}"
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
psql -v ON_ERROR_STOP=1 -f "$ROOT/schema/sql/005_reference_seed_tables.sql"
psql -v ON_ERROR_STOP=1 -c "\copy reference_fire_centres from '$ROOT/reference/bc_fire_centres.csv' with (format csv, header true)"
psql -v ON_ERROR_STOP=1 -c "\copy reference_places from '$ROOT/reference/bc_municipalities_or_localities.csv' with (format csv, header true)"
psql -v ON_ERROR_STOP=1 -c "\copy reference_places from '$ROOT/reference/external_communities.csv' with (format csv, header true)"
psql -v ON_ERROR_STOP=1 -c "\copy reference_event_clusters from '$ROOT/reference/event_clusters.csv' with (format csv, header true)"
psql -v ON_ERROR_STOP=1 -c "\copy phase_a_target_matrix from '$ROOT/reference/phase_a_target_matrix.csv' with (format csv, header true)"
