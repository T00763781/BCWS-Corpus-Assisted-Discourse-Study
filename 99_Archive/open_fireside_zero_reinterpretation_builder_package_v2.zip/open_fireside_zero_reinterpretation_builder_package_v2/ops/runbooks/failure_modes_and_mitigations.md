# Failure Modes and Mitigations

## Failure: protected/private rows inserted into public actor tables
Mitigation: run privacy boundary tests; block merge until fixed.

## Failure: locality coverage fields collapsed
Mitigation: enforce separate columns and tests on structural vs evidence statuses.

## Failure: discourse used as surrogate for ontology
Mitigation: enforce distinct tables and linkage tests.

## Failure: Phase A depends on scheduler/live infra
Mitigation: block build if Phase B components appear in Phase A checklist.

## Failure: export leaks protected fields
Mitigation: require export job + redaction policy linkage and read-model restrictions.
