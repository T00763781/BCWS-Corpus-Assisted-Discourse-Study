
# Repo Bootstrap

1. Create PostgreSQL 16 database.
2. Apply SQL files in lexical order from `schema/sql/`.
3. Run `ops/bootstrap/load_reference_data.sh`.
4. Load `fixtures/minimal/minimal_fixture.sql`.
5. Run `ops/bootstrap/run_all_validations.sh`.

No schema mutation or reference-population edits are allowed before step 5 passes.
