# Phase A Workflows

## Workflow 1: Bootstrap historical environment
- apply schema
- load fixtures
- run validations

## Workflow 2: Historical ingestion replay
- ingest fire centres and localities
- ingest incidents and event clusters
- ingest public actors and accounts
- ingest protected continuities and protected accounts
- ingest discourse evidence
- emit linkage outputs
- validate

## Workflow 3: Research read models
- build incident detail projections
- build locality comparison projections
- run governance-aware export review
