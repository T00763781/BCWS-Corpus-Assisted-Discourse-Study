# Canonical view: schema/sql/050_read_model_views.sql -> locality_comparison_view
