# Canonical view: schema/sql/050_read_model_views.sql -> incident_detail_view
