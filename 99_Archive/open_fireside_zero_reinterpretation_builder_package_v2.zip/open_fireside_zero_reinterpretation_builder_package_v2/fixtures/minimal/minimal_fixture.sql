INSERT INTO fire_centres (fire_centre_id, fire_centre_code, fire_centre_name, province_code, centroid_lat, centroid_lon)
VALUES ('11111111-1111-1111-1111-111111111111', 'PG', 'Prince George Fire Centre', 'BC', 53.917100, -122.749700);

INSERT INTO localities (locality_id, canonical_locality_name, municipality_name, province_code, country_code, fire_centre_id, structural_coverage_status, evidence_coverage_status, centroid_lat, centroid_lon)
VALUES ('22222222-2222-2222-2222-222222222222', 'Summit Lake', 'Northern Rockies', 'BC', 'CA', '11111111-1111-1111-1111-111111111111', 'SUFFICIENT', 'PARTIAL', 58.736817, -124.591917);

INSERT INTO source_surfaces (source_surface_id, canonical_source_name, source_surface_type, base_url, provenance_rule, privacy_classification)
VALUES ('33333333-3333-3333-3333-333333333333', 'BCWS Public Incident API', 'API', 'https://wildfiresituation-api.nrs.gov.bc.ca', 'Use source identifiers and timestamps as provenance anchors.', 'PUBLIC');

INSERT INTO actors (actor_id, canonical_actor_name, actor_type, is_public_role, source_surface_id, provenance_note)
VALUES ('44444444-4444-4444-4444-444444444444', 'BC Wildfire Service', 'AGENCY', true, '33333333-3333-3333-3333-333333333333', 'Public agency actor from canonical source surface.');

INSERT INTO actor_accounts (actor_account_id, actor_id, platform, account_handle, account_url, is_verified, source_surface_id)
VALUES ('55555555-5555-5555-5555-555555555555', '44444444-4444-4444-4444-444444444444', 'WEBSITE', 'bcws-public-incidents', 'https://wildfiresituation.nrs.gov.bc.ca', true, '33333333-3333-3333-3333-333333333333');

INSERT INTO incidents (incident_id, canonical_incident_number, canonical_incident_name, fire_centre_id, incident_start_date, stage_of_control, cause_category, centroid_lat, centroid_lon, source_surface_id, provenance_note)
VALUES ('66666666-6666-6666-6666-666666666666', 'G90413', 'Summit Lake (G90413)', '11111111-1111-1111-1111-111111111111', '2025-05-28', 'UNDR_CNTRL', 'HUMAN', 58.736817, -124.591917, '33333333-3333-3333-3333-333333333333', 'Historical incident fixture within Phase A.');

INSERT INTO event_clusters (event_cluster_id, canonical_event_cluster_name, event_start_date, cross_jurisdiction_flag, provenance_note)
VALUES ('77777777-7777-7777-7777-777777777777', 'Northern Corridor Smoke and Response Cluster', '2025-06-01', false, 'Fixture event cluster for one-incident minimal ontology.');

INSERT INTO incident_event_cluster_links (incident_id, event_cluster_id, link_confidence, provenance_note)
VALUES ('66666666-6666-6666-6666-666666666666', '77777777-7777-7777-7777-777777777777', 0.950, 'Fixture linkage.');

INSERT INTO incident_locality_links (incident_id, locality_id, link_confidence, provenance_note)
VALUES ('66666666-6666-6666-6666-666666666666', '22222222-2222-2222-2222-222222222222', 0.980, 'Fixture locality linkage.');

INSERT INTO protected_private_entities (protected_entity_id, continuity_public_id, restricted_display_name, identity_hash, privacy_classification, provenance_note)
VALUES ('88888888-8888-8888-8888-888888888888', 'pc_0001', 'Restricted Witness A', 'hash_identity_pc_0001', 'PROTECTED_PRIVATE', 'Protected continuity fixture.');

INSERT INTO protected_private_accounts (protected_account_id, protected_entity_id, platform, restricted_account_handle, handle_hash, source_surface_id)
VALUES ('99999999-9999-9999-9999-999999999999', '88888888-8888-8888-8888-888888888888', 'FORUM', 'restricted_user_a', 'hash_handle_pc_0001', '33333333-3333-3333-3333-333333333333');

INSERT INTO discourse_threads (discourse_thread_id, source_surface_id, platform, external_thread_id, thread_url, created_at_source)
VALUES ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '33333333-3333-3333-3333-333333333333', 'FORUM', 'thread-1', 'https://example.local/thread-1', '2025-06-05T12:00:00Z');

INSERT INTO discourse_items (discourse_item_id, discourse_thread_id, discourse_item_type, source_surface_id, protected_account_id, external_item_id, content_text, content_language, created_at_source, privacy_classification)
VALUES ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'POST', '33333333-3333-3333-3333-333333333333', '99999999-9999-9999-9999-999999999999', 'post-1', 'Smoke visible near Summit Lake this afternoon.', 'en', '2025-06-05T12:10:00Z', 'PROTECTED_PRIVATE');

INSERT INTO discourse_media (discourse_media_id, discourse_item_id, media_url, media_type)
VALUES ('cccccccc-cccc-cccc-cccc-cccccccccccc', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'https://example.local/media-1.jpg', 'image/jpeg');

INSERT INTO discourse_classifications (discourse_classification_id, discourse_item_id, classification_label, classification_value, classifier_name, confidence)
VALUES ('dddddddd-dddd-dddd-dddd-dddddddddddd', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'topic', 'smoke-observation', 'manual-fixture', 0.910);

INSERT INTO entity_links (entity_link_id, source_entity_type, source_entity_id, target_entity_type, target_entity_id, link_confidence, provenance_note)
VALUES ('eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', 'INCIDENT', '66666666-6666-6666-6666-666666666666', 'LOCALITY', '22222222-2222-2222-2222-222222222222', 0.980, 'Fixture analysis-safe linkage.');

INSERT INTO protected_context_links (protected_context_link_id, protected_account_id, target_type, target_id, link_confidence, provenance_note)
VALUES ('ffffffff-ffff-ffff-ffff-ffffffffffff', '99999999-9999-9999-9999-999999999999', 'INCIDENT', '66666666-6666-6666-6666-666666666666', 0.720, 'Protected context linkage fixture.');

INSERT INTO redaction_policies (redaction_policy_id, policy_name, suppress_protected_handles, suppress_small_n, small_n_threshold, policy_json)
VALUES ('12121212-1212-1212-1212-121212121212', 'default-research-safe', true, true, 3, '{"suppress_fields": ["restricted_display_name", "restricted_account_handle"]}');

INSERT INTO export_jobs (export_job_id, redaction_policy_id, export_name, export_scope, export_status)
VALUES ('13131313-1313-1313-1313-131313131313', '12121212-1212-1212-1212-121212121212', 'fixture-safe-export', 'incident-detail', 'QUEUED');
