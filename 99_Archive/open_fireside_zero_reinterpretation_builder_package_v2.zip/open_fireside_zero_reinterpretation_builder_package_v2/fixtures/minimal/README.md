# Minimal Fixture Dataset

This dataset demonstrates the full canonical ontology with exactly one coherent example of each required object class:
- one fire centre
- one locality
- one incident
- one event cluster
- one public actor
- one actor account
- one protected private continuity entity
- one protected private account
- one source surface
- one discourse thread and discourse item
- one linkage/confidence record
- one governance/redaction record
