Reference fixture inputs are canonical CSV seeds loaded into the reference_* tables before minimal ontology fixtures.
