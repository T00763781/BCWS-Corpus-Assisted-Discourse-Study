-- Open Fireside registry foundation outline
-- Reference only. Final schema may evolve.

CREATE TABLE fire_centres (
  fire_centre_id TEXT PRIMARY KEY,
  fire_centre_name TEXT NOT NULL UNIQUE
);

CREATE TABLE municipalities (
  municipality_id TEXT PRIMARY KEY,
  municipality_name TEXT NOT NULL,
  fire_centre_id TEXT REFERENCES fire_centres(fire_centre_id),
  province_state TEXT NOT NULL DEFAULT 'British Columbia',
  country TEXT NOT NULL DEFAULT 'Canada',
  regional_group TEXT,
  UNIQUE(municipality_name, province_state)
);

CREATE TABLE actors (
  actor_id TEXT PRIMARY KEY,
  actor_name TEXT NOT NULL,
  actor_type TEXT NOT NULL,
  actor_class TEXT,
  municipality_id TEXT REFERENCES municipalities(municipality_id),
  fire_centre_id TEXT REFERENCES fire_centres(fire_centre_id),
  verification_status TEXT NOT NULL,
  public_basis TEXT,
  notes TEXT
);

CREATE TABLE actor_accounts (
  account_id TEXT PRIMARY KEY,
  actor_id TEXT NOT NULL REFERENCES actors(actor_id),
  platform TEXT NOT NULL,
  account_url TEXT NOT NULL UNIQUE,
  surface_type TEXT NOT NULL,
  verification_status TEXT NOT NULL
);

CREATE TABLE actor_evidence (
  evidence_id TEXT PRIMARY KEY,
  actor_id TEXT NOT NULL REFERENCES actors(actor_id),
  account_id TEXT REFERENCES actor_accounts(account_id),
  evidence_type TEXT NOT NULL,
  source_url TEXT NOT NULL,
  retrieval_utc TEXT NOT NULL,
  attribution_strength TEXT NOT NULL
);

CREATE TABLE discovery_leads (
  lead_id TEXT PRIMARY KEY,
  actor_id TEXT REFERENCES actors(actor_id),
  platform TEXT,
  candidate_url TEXT,
  discovery_query TEXT,
  status TEXT NOT NULL,
  notes TEXT
);

CREATE TABLE discourse_sources (
  source_id TEXT PRIMARY KEY,
  actor_id TEXT REFERENCES actors(actor_id),
  source_kind TEXT NOT NULL,
  source_url TEXT NOT NULL,
  ingestion_scope TEXT NOT NULL,
  verification_status TEXT NOT NULL
);

CREATE TABLE public_communities (
  community_id TEXT PRIMARY KEY,
  community_name TEXT NOT NULL,
  platform TEXT NOT NULL,
  community_url TEXT NOT NULL UNIQUE,
  verification_status TEXT NOT NULL
);

CREATE TABLE monitoring_subscriptions (
  subscription_id TEXT PRIMARY KEY,
  subject_type TEXT NOT NULL,
  subject_id TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  cadence TEXT NOT NULL,
  ingest_mode TEXT,
  last_run_utc TEXT,
  error_state TEXT
);
