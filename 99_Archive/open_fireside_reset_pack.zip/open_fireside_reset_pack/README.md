# Open Fireside Reset Pack

This pack is designed for a new closed project folder and a fresh Codex/ChatGPT session.

It contains:
- a compact high-value project brief
- an updated Open Fireside guardrails skill
- a DB-first architecture baseline
- reference CSVs for core domain objects and completion rules
- a starter SQL schema outline for the registry foundation

Recommended use:
1. Create a new private project folder.
2. Upload this zip.
3. Read `prompts/OPEN_FIRESIDE_MASTER_PROMPT.md` first.
4. Load `skills/open-fireside-guardrails/SKILL.md` as the governing guardrails.
5. Treat the `data/` CSVs and `db/` files as high-value reference material, not as final truth.

This pack intentionally avoids carrying forward noisy wave-specific artifacts.
