# Open Fireside — Reset Brief for a New Closed Project

You are working on **Open Fireside**, a private, local-first, multi-year wildfire research platform.

## Core identity
- **Open Fireside** = platform
- **Open Fireside Project** = research initiative
- Primary user = owner/operator/research lead
- Primary operating mode = private repo, local execution, local DB, private evidence base

## Core mission
Build a modular, defensible system that captures and links:
- **incidents**
- **environment**
- **discourse**
- **actors**
- **accounts/channels**
- **evidence**
- **sources**
- **maps/layers**
- **topics / narratives / campaigns / events**

The purpose is not publishing. It is not a government tool. It is not a citizen-surveillance product. It is a **private wildfire information and public discourse research system**.

Preferred framing:
- wildfire information environment
- public discourse research
- communication and engagement analysis
- rumours, misinformation, narratives, campaigns, uptake, context

Avoid framing like:
- surveillance
- citizen tracking
- covert monitoring
- threat monitoring of people

## Strategic correction
The project drifted into too many CSV wave passes before the operational foundation was frozen.

The new direction is:
1. **clean architecture first**
2. **DB-first canonical model**
3. **CSV as import/export and audit format, not long-term canonical write target**
4. **internal registry operations tool before public-facing product work**
5. **script-first for mechanical work**
6. **agents/LLM reasoning only for ambiguity, architecture, policy, and edge-case attribution**

## Non-negotiable architecture decisions
- Primary desktop application: **WinUI 3 / Windows App SDK**
- Local services/workers: Python is acceptable
- Primary operational store: **local SQLite DB**
- Raw captures retained on disk
- Registry exports may exist as CSV snapshots
- No browser-first MVP framing for the actual product
- No sweeping UI work before contracts, DB, import/export, admin workflows, and validation are defined

## Canonical domain model
At minimum, the system must support:
- municipalities
- fire_centres
- actors
- actor_accounts
- actor_evidence
- discovery_leads
- discourse_sources
- public_communities
- monitoring_subscriptions
- ingest_runs
- raw_captures

The conceptual hierarchy is:
Province/Region -> Municipality/Locality -> Actor -> Account/Surface -> Evidence -> Monitoring/Ingestion

## Meaning of core objects
### Actor
A named public individual, organization, institution, governing body, official program, community hub, operator, or other public-facing entity relevant to wildfire discourse, environment, or incident context.

### Actor account
A resolved direct public surface linked to an actor:
- website
- bulletin/news/alerts page
- Facebook
- Instagram
- X
- LinkedIn
- YouTube
- TikTok
- RSS/feed/newsletter

### Evidence
A row proving why the actor or account is trusted, where it was found, how it was attributed, and when it was retrieved.

### Discovery lead
An unresolved but plausible account/channel/source that has not yet met the evidence threshold for promotion to a resolved account.

### Discourse source
A source surface used for collection or analysis:
- official bulletin/newsroom
- news outlet
- feed
- community board
- public discussion venue
- operator/institution signal source

### Public community
A clearly public community surface where wildfire-related discourse may occur.

### Monitoring subscription
A control object that says whether a resolved account/source is actively monitored, how often, and in what mode.

## Finished-state definition
The foundational registry system is considered finished when:
1. the DB schema exists and is migration-backed
2. CSV import to staging works deterministically
3. validation and dedupe are script-first
4. export back to registry snapshots works
5. actor cards are supported by the DB model
6. accounts can be added, disabled, or promoted from discovery
7. evidence can be attached and reviewed
8. municipality packet completion can be scored automatically
9. the internal admin tool can manage actors, accounts, evidence, discovery, and monitoring
10. canonical paths and trust boundaries are explicit

## What the internal admin tool must eventually do
This tool is private and operator-facing.

Required tabs / surfaces:
- Actors
- Municipalities
- Fire Centres
- Accounts/Channels
- Evidence
- Discovery Queue
- Discourse Sources
- Public Communities
- Monitoring / Subscriptions
- Validation / Diagnostics

Each actor card should support:
- actor metadata
- locality and fire centre linkage
- linked accounts/channels
- linked evidence
- discovery leads
- monitoring state
- notes
- validation status
- add account / add evidence / promote lead actions

## Mechanical work should move to scripts
Push these into scripts wherever possible:
- dedupe
- validation
- CSV import to staging
- DB export to snapshots
- municipality completion scoring
- duplicate report generation
- contract diagnostics

Use agents / Codex for:
- architecture
- policy
- repo audit
- schema design
- ambiguous identity resolution
- edge-case attribution
- UI planning

## Municipality completion philosophy
Municipality “completion” should not be website-heavy.
A municipality is not complete just because it has 12 actors and a few websites.

A useful municipality packet should include:
- government root
- bulletin/news/alerts surface
- head-of-government public individual
- council/chair/governance surface
- fire/emergency organization
- emergency-role public individual
- external/local news
- public community/forum/board
- visitor/community hub
- wildfire-relevant operator/institution
- attributable non-web accounts where they exist
- explicit blocker notes where expected channels do not exist or cannot be attributed

## Repo hygiene expectations
- DB tables are canonical operational write targets
- `registry/master/*.csv` should become exported snapshots
- imports go to dedicated staging/import paths
- duplicate seed bundles and obsolete mirrors are archival only
- logs and diagnostics must have explicit homes
- historical wave artifacts are useful as evidence, not as active architecture truth

## Delivery style
Prefer:
1. decision
2. rationale
3. assumptions
4. proposed structure
5. smallest safe next step

Always distinguish:
- live
- wired-no-data
- stub
- mock

Never imply something is connected if it is not.

## Immediate priority in a new session
Do not start with new wave expansion.
Start with:
1. repo truth audit
2. skill audit
3. canonical architecture reset
4. DB foundation
5. import/export/validation/dedupe scripts
6. internal admin tool skeleton

That is the correct foundation for Open Fireside.
