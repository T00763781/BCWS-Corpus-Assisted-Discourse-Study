# Open Fireside Guardrails — Reset Version

Apply these rules to every Open Fireside task.

## Product framing
Open Fireside is an independent, private, local-first wildfire research platform.

It is built to capture and relate:
- incidents
- environment
- discourse
- actors
- accounts/channels
- evidence
- sources
- maps/layers
- topics / narratives / campaigns / events

Never frame it as citizen surveillance, covert tracking, or threat monitoring of people.
Prefer: public discourse research, wildfire information environment, communication context, rumours, misinformation, narratives, campaigns.

## Hard blockers
Reject or correct any proposal that:
- treats a browser tab or localhost web page as the primary desktop product
- proposes a primary stack other than WinUI 3 / Windows App SDK without explicit approval
- makes CSV the long-term canonical operational store once DB foundation exists
- hides whether something is live, wired-no-data, stub, or mock
- proposes broad UI work before contracts, DB, import/export, validation, and admin workflows exist
- turns plugin or source definitions into UI-only concepts
- collapses incident, environment, and discourse into one undifferentiated system
- uses toy-like consumer-dashboard styling for operator/research workflows
- assumes cloud dependency for core local use
- drifts from Open Fireside / Open Fireside Project naming

## Default stack
Unless explicitly overridden:
- primary app: WinUI 3 / Windows App SDK
- workers/services: Python is acceptable
- operational DB: local SQLite
- raw captures: disk-backed immutable storage
- registry exports: CSV snapshots are acceptable
- browser tech: secondary only, not the primary app framing

## Canonical system shape
Build systems before surfaces.

Preferred order:
1. contracts and schemas
2. DB foundation
3. import / staging pipeline
4. validation and dedupe scripts
5. export pipeline
6. internal admin tool
7. read models
8. operator-facing product surfaces

## DB-first rule
Once the DB foundation exists:
- canonical write target = DB tables
- `registry/master/*.csv` = exported snapshots / audit artifacts
- imports = staging paths or staging DB tables
- no long-term manual editing of exported snapshot CSVs as primary truth

## Minimum canonical entities
The stable system must support:
- fire_centres
- municipalities
- actors
- actor_accounts
- actor_evidence
- discovery_leads
- discourse_sources
- public_communities
- monitoring_subscriptions
- ingest_runs
- raw_captures

## Script-first rule
Move mechanical work into deterministic scripts wherever possible.

Script-first tasks:
- dedupe
- validation
- CSV import to staging
- DB export to snapshots
- municipality completion scoring
- duplicate diagnostics

Use agent reasoning for:
- architecture
- policy
- repo audit
- ambiguous attribution
- edge-case identity resolution
- finished-state definition

## Internal admin tool rule
Before public-facing product work, the system should support a private registry operations tool.

At minimum it should eventually support:
- actor management
- account/channel management
- evidence review
- discovery queue management
- municipality/fire centre views
- discourse source management
- monitoring settings
- validation diagnostics

## Actor/account rule
Actors are the primary research entities.
Accounts/channels are attached to actors.
Evidence proves actors/accounts.
Discovery leads remain separate until promoted.

Do not merge unresolved leads into resolved accounts.
Do not treat platform-root URLs as valid resolved accounts.

## Municipality packet rule
A municipality packet is not complete just because it has websites.
Completion must consider:
- actor mix
- non-web platform coverage
- discourse source breadth
- community/external signal presence
- evidence completeness
- blocker honesty where expected channels do not exist

## Repo path rule
Prefer clean separation between:
- docs/
- storage/db/
- tools/admin/
- registry/imports/
- registry/master/ (exports)
- logs/
- reviews/
- archive/quarantine/

Historical duplicates, audit dumps, and obsolete mirrors are not active truth.

## Delivery rule
Structure outputs in this order unless overridden:
1. decision
2. rationale
3. assumptions
4. proposed structure/design
5. smallest safe next step

Always state what is live, wired-no-data, stub, or mock.
