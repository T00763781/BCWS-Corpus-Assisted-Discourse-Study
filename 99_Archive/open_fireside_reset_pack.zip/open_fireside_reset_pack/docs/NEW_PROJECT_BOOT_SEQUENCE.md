# New Project Boot Sequence

1. Upload this pack into a fresh private project folder.
2. Load `prompts/OPEN_FIRESIDE_MASTER_PROMPT.md` into the first session.
3. Treat `skills/open-fireside-guardrails/SKILL.md` as governing architecture guardrails.
4. Start with repo truth audit and DB-first foundation.
5. Do not resume wave expansion until the DB contract, import path, dedupe, validation, and export path are trustworthy.
