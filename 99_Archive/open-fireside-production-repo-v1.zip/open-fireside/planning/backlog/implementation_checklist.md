# Implementation Checklist

- [ ] Shell composes all surface routes.
- [ ] Target registry loads all six fire centres.
- [ ] Verification queue can promote a candidate to verified.
- [ ] One discourse ingestor emits normalized evidence.
- [ ] Incident, environment, and maps PoCs render independently.
- [ ] Export governance applies redaction and suppression.
