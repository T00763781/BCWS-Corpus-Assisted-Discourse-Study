# Risk Register

- Reference drift from canonical BC and external community seed sets.
- Ontology collapse between actors, protected entities, and discourse evidence.
- Over-coupling shell to a single surface implementation.
- Building ingestion before verification workflow maturity.
- Weak provenance and freshness labeling on derived panels.
