# Phase A Workflows

- Home summarizes cross-surface state only after surfaces exist.
- Discourse begins with targets and verification, not ingestion.
- Environment, incidents, and maps remain independently buildable.
- Ops Console tracks orchestration and validation health.
