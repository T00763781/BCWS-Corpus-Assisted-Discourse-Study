# Incident Detail Contract

Fields:
- incidentId
- incidentName
- fireCentreName
- localitiesAffected
- sourceProvenance
- latestResponseSummary
- discourseEvidenceCount
