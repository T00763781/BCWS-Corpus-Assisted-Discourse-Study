# Locality Comparison Contract

Fields:
- localityId
- localityName
- fireCentreId
- structuralCoverageStatus
- evidenceCoverageStatus
- incidentCount
- discourseSignalCount
