from pathlib import Path
import subprocess, sys
ROOT = Path(__file__).resolve().parents[2]
TESTS = [
    ROOT / 'validation' / 'tests' / 'test_reference_dataset_integrity.py',
    ROOT / 'validation' / 'tests' / 'test_phase_a_target_matrix.py',
]
for test in TESTS:
    result = subprocess.run([sys.executable, str(test)], cwd=ROOT)
    if result.returncode != 0:
        raise SystemExit(result.returncode)
print('python validations passed')
