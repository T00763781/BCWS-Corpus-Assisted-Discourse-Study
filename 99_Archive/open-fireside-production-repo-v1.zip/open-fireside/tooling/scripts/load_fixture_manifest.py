from pathlib import Path
import json
ROOT = Path(__file__).resolve().parents[2]
fixture = ROOT / 'data' / 'fixtures' / 'cross-surface' / 'minimal_fixture.json'
manifest = {
    'loaded_fixture': fixture.name,
    'size_bytes': fixture.stat().st_size,
}
print(json.dumps(manifest, indent=2))
