# AGENTS.md

## Audience
Codex 5.4 and implementation agents operating inside this repo.

## Non-negotiable rules
1. Do not collapse public actors into protected private continuity entities.
2. Do not collapse actor accounts into protected private accounts.
3. Do not collapse discourse evidence into the primary entity ontology.
4. Do not merge structural locality coverage with evidence coverage.
5. Fire Centres are first-class entities and drive Phase 1 coverage packs.
6. Treat `data/reference/*.csv` and `data/reference/phase1_floors.yaml` as canonical for in-scope structural coverage.
7. Treat `packages/entity-contracts/schemas` and `data/schemas/sql` as canonical source of interface and storage truth.
8. Shell-first, surface-autonomous build order: shell -> discourse PoC -> environment/incidents/maps -> merge/home.
9. Governance, export, redaction, and provenance are implementation requirements, not later polish.
10. Never weaken historical-first Phase 1 requirements to satisfy real-time convenience.

## Expected execution order
- Inspect `README.md`
- Inspect `docs/product/shell-spec.md`
- Inspect `docs/architecture/repo-architecture.md`
- Inspect `data/reference/phase1_floors.yaml`
- Inspect `packages/entity-contracts/schemas`
- Inspect `services/target-registry` and `services/verification-workflow`
- Build or modify only with tests or validations updated in parallel

## Coding expectations
- TypeScript strict mode.
- Prefer pure functions for normalization and validation.
- All read-model outputs must have a corresponding schema in `packages/entity-contracts/schemas`.
- All adapters must emit lineage and provenance metadata.
- Every new surface-local feature must remain independently usable prior to shell integration.
