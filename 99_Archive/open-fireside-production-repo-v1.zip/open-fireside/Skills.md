# Skills

## Repo execution skills for Codex
- **Shell-first composition**: build shared page frame, routing, status bar, left rail, inspector drawer before surface-specific data logic.
- **Target registry first**: discourse work starts with canonical targets, candidate queue, and verification workflow before ingestion.
- **Contract-first changes**: update schemas and validators before changing storage or read models.
- **Reference integrity**: treat fire centres, municipalities, external communities, and phase floors as immutable inputs during Phase 1.
- **Governance-first export**: any export feature must pass through suppression, redaction, and audit modules.
- **Surface autonomy**: each app in `apps/` must be buildable, testable, and reviewable independently.
