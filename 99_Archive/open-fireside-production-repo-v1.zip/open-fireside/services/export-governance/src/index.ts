export type ExportDisposition = 'allow' | 'redact' | 'suppress';

export function resolveExportDisposition(isProtected: boolean, smallN: boolean): ExportDisposition {
  if (isProtected) return 'suppress';
  if (smallN) return 'redact';
  return 'allow';
}
