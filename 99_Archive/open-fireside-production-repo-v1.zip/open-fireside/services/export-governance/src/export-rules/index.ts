export const export_rules_service = 'export-governance/export-rules';
