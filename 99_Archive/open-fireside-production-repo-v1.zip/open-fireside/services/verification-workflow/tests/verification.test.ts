import { describe, expect, it } from 'vitest';
import { canPromote } from '../src/index';

describe('verification workflow', () => {
  it('promotes verified targets with evidence', () => {
    expect(canPromote({ targetId: 't1', evidenceUrl: 'https://example.org', reviewer: 'analyst', state: 'verified', reviewedAt: '2026-01-01T00:00:00Z' })).toBe(true);
  });
});
