export const status_transitions_service = 'verification-workflow/status-transitions';
