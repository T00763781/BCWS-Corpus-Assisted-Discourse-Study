export type VerificationState = 'candidate' | 'verified' | 'rejected' | 'inactive';
export interface VerificationRecord {
  targetId: string;
  evidenceUrl: string;
  reviewer: string;
  state: VerificationState;
  reviewedAt: string;
}
export function canPromote(record: VerificationRecord): boolean {
  return record.state === 'verified' && record.evidenceUrl.length > 0;
}
