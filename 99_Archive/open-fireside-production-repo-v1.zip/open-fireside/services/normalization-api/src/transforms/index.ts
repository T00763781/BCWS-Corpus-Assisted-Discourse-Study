export const transforms_service = 'normalization-api/transforms';
