export const adapters_service = 'normalization-api/adapters';
