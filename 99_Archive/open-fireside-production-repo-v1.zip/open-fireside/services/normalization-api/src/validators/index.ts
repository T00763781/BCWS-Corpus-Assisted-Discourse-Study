export const validators_service = 'normalization-api/validators';
