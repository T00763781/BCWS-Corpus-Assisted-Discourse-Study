export interface NormalizedEnvelope<T> {
  schema: string;
  source: string;
  capturedAt: string;
  payload: T;
}

export function normalizeEnvelope<T>(schema: string, source: string, payload: T): NormalizedEnvelope<T> {
  return {
    schema,
    source,
    capturedAt: new Date().toISOString(),
    payload,
  };
}
