export const coverage_ledger_service = 'target-registry/coverage-ledger';
