export const target_packs_service = 'target-registry/target-packs';
