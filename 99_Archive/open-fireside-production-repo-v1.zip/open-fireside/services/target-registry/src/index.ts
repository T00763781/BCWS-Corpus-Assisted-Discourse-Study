import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

export type CanonicalTargetPack = {
  fireCentreId: string;
  municipalityIds: string[];
  externalCommunityIds: string[];
};

export function loadPhaseOneFloors(): string {
  return readFileSync(resolve(process.cwd(), 'data/reference/phase1_floors.yaml'), 'utf-8');
}

export function buildCanonicalTargetPack(fireCentreId: string, municipalityIds: string[], externalCommunityIds: string[]): CanonicalTargetPack {
  return { fireCentreId, municipalityIds, externalCommunityIds };
}
