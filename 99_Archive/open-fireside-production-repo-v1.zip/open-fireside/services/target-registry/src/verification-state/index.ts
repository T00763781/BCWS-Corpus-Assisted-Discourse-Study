export const verification_state_service = 'target-registry/verification-state';
