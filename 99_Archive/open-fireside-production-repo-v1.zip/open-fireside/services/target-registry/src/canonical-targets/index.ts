export const canonical_targets_service = 'target-registry/canonical-targets';
