export const candidate_queue_service = 'target-registry/candidate-queue';
