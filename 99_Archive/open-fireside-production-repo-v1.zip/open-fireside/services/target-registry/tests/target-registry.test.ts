import { describe, expect, it } from 'vitest';
import { buildCanonicalTargetPack } from '../src/index';

describe('target registry', () => {
  it('builds target pack deterministically', () => {
    const pack = buildCanonicalTargetPack('fc_bc_cariboo', ['bc_100milehouse'], ['ext_ab_grande_prairie']);
    expect(pack.fireCentreId).toBe('fc_bc_cariboo');
    expect(pack.municipalityIds).toHaveLength(1);
  });
});
