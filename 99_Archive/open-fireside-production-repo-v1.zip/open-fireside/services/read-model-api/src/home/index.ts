export const home_service = 'read-model-api/home';
