export const maps_service = 'read-model-api/maps';
