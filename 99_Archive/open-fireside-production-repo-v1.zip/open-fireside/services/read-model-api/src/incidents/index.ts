export const incidents_service = 'read-model-api/incidents';
