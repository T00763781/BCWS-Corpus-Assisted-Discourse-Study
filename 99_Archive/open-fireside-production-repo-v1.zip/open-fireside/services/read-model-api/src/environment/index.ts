export const environment_service = 'read-model-api/environment';
