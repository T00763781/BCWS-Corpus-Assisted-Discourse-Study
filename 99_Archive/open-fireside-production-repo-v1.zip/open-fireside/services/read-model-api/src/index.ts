export interface IncidentReadModelQuery {
  incidentId: string;
}
export interface IncidentReadModel {
  incidentId: string;
  incidentName: string;
  fireCentreName: string;
  localityCoverageSummary: string;
  discourseEvidenceCount: number;
}
export function buildIncidentReadModel(input: IncidentReadModel): IncidentReadModel {
  return input;
}
