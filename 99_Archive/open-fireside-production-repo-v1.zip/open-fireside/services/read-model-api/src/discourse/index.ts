export const discourse_service = 'read-model-api/discourse';
