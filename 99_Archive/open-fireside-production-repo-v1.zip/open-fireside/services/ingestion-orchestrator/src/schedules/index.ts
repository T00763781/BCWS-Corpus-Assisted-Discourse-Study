export const schedules_service = 'ingestion-orchestrator/schedules';
