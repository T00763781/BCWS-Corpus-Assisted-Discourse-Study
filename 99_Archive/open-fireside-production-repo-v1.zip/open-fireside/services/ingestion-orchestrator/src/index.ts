export interface RunRequest {
  jobId: string;
  surface: 'discourse' | 'environment' | 'incidents' | 'maps';
  trigger: 'manual' | 'schedule' | 'retry';
}

export function createRunRequest(jobId: string, surface: RunRequest['surface'], trigger: RunRequest['trigger']): RunRequest {
  return { jobId, surface, trigger };
}
