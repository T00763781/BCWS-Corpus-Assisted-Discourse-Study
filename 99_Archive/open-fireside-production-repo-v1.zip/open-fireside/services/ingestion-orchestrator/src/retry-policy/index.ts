export const retry_policy_service = 'ingestion-orchestrator/retry-policy';
