# Open Fireside Monorepo

Open Fireside is a local-first, multi-surface wildfire research workstation built on a shared entity, provenance, and governance backbone.

## Canonical build scope
- Historical-first build window: **2025-04-01 to 2026-03-31**
- Real-time transition target: **2026-04-01 and after**
- Fire Centres are first-class entities.
- Structural locality coverage and evidence coverage remain distinct.
- Public actors remain distinct from protected private continuity entities.
- Actor accounts remain distinct from protected private accounts.

## Monorepo conventions
- Package manager: `pnpm`
- Task runner: `turbo`
- Language: TypeScript 5
- UI runtime: React 18
- Primary database dialect: PostgreSQL 16
- Shared contracts live in `packages/entity-contracts`
- Canonical reference data lives in `data/reference`

## Bootstrap
1. `pnpm install`
2. `pnpm bootstrap:reference`
3. `pnpm bootstrap:fixtures`
4. `pnpm validate`
5. `pnpm dev`

## Production architecture split
- `apps/` user-facing surfaces and shell
- `packages/` shared UI, contracts, provenance, reference data access
- `services/` backend and orchestration services
- `workers/` ingestion and validation execution units
- `data/` canonical seed data, schemas, fixtures, and quality assets
- `docs/` product, architecture, governance, phasing, and acceptance docs
- `tooling/` bootstrap, dev, ci, and utility scripts

## Historical-first Phase 1 floor
See `data/reference/phase1_floors.yaml` and `docs/phasing/phase-1-discourse-poc.md`.
