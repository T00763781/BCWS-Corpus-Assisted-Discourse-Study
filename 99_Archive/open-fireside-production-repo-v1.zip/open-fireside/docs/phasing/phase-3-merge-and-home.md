# Phase 3 Merge And Home

Merge surfaces into one shell and add Home as cross-surface synthesis only after standalone credibility.
