# Phase 1 Discourse Poc

Target-registry and verification-first discourse proof of concept for 2025-2026 historical reconstruction.
