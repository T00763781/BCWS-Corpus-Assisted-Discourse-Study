# Phase 0 Shell

Shell-first phase: app frame, navigation, layout primitives, and shared status/provenance chrome.
