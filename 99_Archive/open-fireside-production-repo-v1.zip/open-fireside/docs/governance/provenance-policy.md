# Provenance Policy

Every panel and normalized record must carry source, capture method, timestamp, and derivation metadata.
