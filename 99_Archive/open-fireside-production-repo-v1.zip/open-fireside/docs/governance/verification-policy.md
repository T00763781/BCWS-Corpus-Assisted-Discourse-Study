# Verification Policy

Targets become ingestible only after review evidence, reviewer identity, and status transition are stored.
