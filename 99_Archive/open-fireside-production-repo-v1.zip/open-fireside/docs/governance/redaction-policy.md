# Redaction Policy

Protected private continuity entities and accounts must never appear in public-facing exports.
