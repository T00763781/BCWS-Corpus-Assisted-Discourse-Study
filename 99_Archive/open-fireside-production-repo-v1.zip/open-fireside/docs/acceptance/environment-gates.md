# Environment Gates

Environment gates: outlook, product panels, fire-centre summary, and hazard provenance labels.
