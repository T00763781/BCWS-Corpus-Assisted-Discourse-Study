# Incidents Gates

Incident gates: list, detail, record tabs, response cards, gallery, map subview, discourse linkout.
