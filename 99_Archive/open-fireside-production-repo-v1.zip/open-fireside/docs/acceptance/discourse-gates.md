# Discourse Gates

Discourse gates: target pack coverage, verification queue, normalized evidence, signals, and evidence table.
