# Shell Gates

Shell gates: routes, frame, rail, status strip, inspector drawer, and search state.
