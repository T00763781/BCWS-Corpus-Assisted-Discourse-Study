# Merge Gates

Merge gates: cross-surface pivots, pinned context, summary cards, and home readiness.
