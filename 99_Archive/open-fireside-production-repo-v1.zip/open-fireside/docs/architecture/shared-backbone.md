# Shared Backbone

Backbone modules: entity contracts, provenance, reference data, target registry, verification workflow, read models, export governance.
