# Orchestration Model

Ingestion orchestrator schedules runs, emits health and events, and persists run history for the ops console.
