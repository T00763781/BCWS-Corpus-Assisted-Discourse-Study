# Repo Architecture

This repo is organized around **surface autonomy plus shared backbone**.

## Shared backbone
- `packages/entity-contracts`: canonical types, schemas, and validators
- `packages/reference-data`: canonical fire centre, municipality, external community, and archetype assets
- `packages/provenance`: lineage, confidence, source labels
- `services/target-registry`: canonical target packs and coverage ledger
- `services/verification-workflow`: candidate review and promotion logic
- `services/read-model-api`: stable read model assembly
- `services/export-governance`: redaction, suppression, and audit logic

## Surface autonomy
Each app under `apps/` is independently buildable and testable. Surface-local logic remains local until merge.
