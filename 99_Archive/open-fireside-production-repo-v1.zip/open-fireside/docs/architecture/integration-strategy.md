# Integration Strategy

Build shell first, discourse PoC second, environment/incidents/maps in parallel, home merge later.
