# Navigation Model

Explains global shell navigation, surface routes, record routes, and cross-surface pivots.
