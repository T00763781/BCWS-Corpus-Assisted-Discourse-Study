# Surface Model

Open Fireside surfaces are not equal tabs on a database. They are independent workspaces with a shared backbone.

- **Home**: cross-surface synthesis after merge
- **Discourse**: targets, verification, ingestion runs, signals, evidence records, actor/account detail
- **Environment**: outlook, products, fire-centre summaries, hazard panels
- **Incidents**: incident list, record views, response, gallery, maps, discourse linkout
- **Maps**: basemap, overlays, time controls, saved views
- **Ops Console**: ingestors, queues, logs, health, validation
