# Record View Model

Defines record header, subtab grammar, provenance panel, and linked evidence presentation.
