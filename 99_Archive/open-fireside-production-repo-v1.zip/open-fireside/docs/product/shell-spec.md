# Shell Spec

Canonical shell layout, navigation model, left rail, status bar, and inspector drawer rules.
