# Discourse Verification

Verification actions, evidence requirements, state transitions, and revalidation rules for discourse targets.
