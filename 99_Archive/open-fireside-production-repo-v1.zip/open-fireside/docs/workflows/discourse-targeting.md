# Discourse Targeting

Canonical place universe -> target archetypes -> candidate queue -> verification -> registry -> ingestion -> evidence.
