#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
mkdir -p "$ROOT/.runtime/reference-load"
cp "$ROOT/data/reference/fire_centres.csv" "$ROOT/.runtime/reference-load/fire_centres.csv"
cp "$ROOT/data/reference/municipalities.csv" "$ROOT/.runtime/reference-load/municipalities.csv"
cp "$ROOT/data/reference/external_communities.csv" "$ROOT/.runtime/reference-load/external_communities.csv"
cp "$ROOT/data/reference/target_archetypes.csv" "$ROOT/.runtime/reference-load/target_archetypes.csv"
cp "$ROOT/data/reference/phase1_floors.yaml" "$ROOT/.runtime/reference-load/phase1_floors.yaml"
echo "reference data staged at $ROOT/.runtime/reference-load"
