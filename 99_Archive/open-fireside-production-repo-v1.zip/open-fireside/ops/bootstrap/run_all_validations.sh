#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
python3 "$ROOT/tooling/scripts/run_python_validations.py"
echo "all reference and ontology validations completed"
