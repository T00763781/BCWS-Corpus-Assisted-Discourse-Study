# Repo Bootstrap

1. Install pnpm and Node 22.
2. Run `pnpm install`.
3. Run `pnpm bootstrap:reference`.
4. Run `pnpm bootstrap:fixtures`.
5. Run `pnpm validate`.
6. Start the shell and one selected surface with `pnpm dev`.
