CREATE OR REPLACE VIEW home_surface_summary AS
SELECT
  COUNT(DISTINCT i.incident_id) AS incident_count,
  COUNT(DISTINCT fc.fire_centre_id) AS fire_centre_count,
  COUNT(DISTINCT a.actor_id) AS public_actor_count,
  COUNT(DISTINCT d.discourse_item_id) AS discourse_item_count
FROM incidents i
LEFT JOIN fire_centres fc ON fc.fire_centre_id = i.fire_centre_id
LEFT JOIN actors a ON true
LEFT JOIN discourse_items d ON true;
