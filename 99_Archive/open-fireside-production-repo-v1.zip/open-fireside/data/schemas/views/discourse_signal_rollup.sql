CREATE OR REPLACE VIEW discourse_signal_rollup AS
SELECT
  di.platform,
  COUNT(*) AS item_count,
  MIN(di.published_at) AS first_seen_at,
  MAX(di.published_at) AS last_seen_at
FROM discourse_items di
GROUP BY di.platform;
