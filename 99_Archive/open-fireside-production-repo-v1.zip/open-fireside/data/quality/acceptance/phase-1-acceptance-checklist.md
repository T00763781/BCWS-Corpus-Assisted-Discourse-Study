# Phase 1 Acceptance Checklist
- Shell app loads all primary surfaces.
- Target registry resolves all six fire centres.
- Canonical municipalities and external communities load without count drift.
- Verification workflow can move a candidate to verified with evidence.
- One discourse ingestor emits normalized evidence and provenance.
- Incident, environment, and maps surfaces render independent proof-of-concept views.
