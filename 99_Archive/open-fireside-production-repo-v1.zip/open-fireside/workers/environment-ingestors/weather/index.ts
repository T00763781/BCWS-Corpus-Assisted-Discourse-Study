export const workerTask = 'environment-ingestors/weather';
