export const workerGroup = 'environment-ingestors';
