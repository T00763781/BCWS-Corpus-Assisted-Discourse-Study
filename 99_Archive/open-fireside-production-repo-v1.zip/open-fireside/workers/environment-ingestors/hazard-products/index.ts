export const workerTask = 'environment-ingestors/hazard-products';
