export const workerTask = 'environment-ingestors/bcws-products';
