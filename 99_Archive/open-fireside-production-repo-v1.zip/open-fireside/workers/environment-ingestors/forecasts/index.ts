export const workerTask = 'environment-ingestors/forecasts';
