export const workerGroup = 'validation-workers';
