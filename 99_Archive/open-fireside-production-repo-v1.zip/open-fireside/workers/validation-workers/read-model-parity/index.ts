export const workerTask = 'validation-workers/read-model-parity';
