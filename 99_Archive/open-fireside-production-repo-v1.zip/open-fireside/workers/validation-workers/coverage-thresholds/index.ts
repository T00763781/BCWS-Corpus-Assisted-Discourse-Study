export const workerTask = 'validation-workers/coverage-thresholds';
