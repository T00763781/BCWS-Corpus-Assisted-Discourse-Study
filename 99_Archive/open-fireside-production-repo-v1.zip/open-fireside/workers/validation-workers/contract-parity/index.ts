export const workerTask = 'validation-workers/contract-parity';
