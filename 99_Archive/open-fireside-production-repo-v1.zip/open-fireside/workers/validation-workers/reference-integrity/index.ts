export function requiredReferenceFiles() {
  return ['fire_centres.csv', 'municipalities.csv', 'external_communities.csv', 'target_archetypes.csv', 'phase1_floors.yaml'];
}
