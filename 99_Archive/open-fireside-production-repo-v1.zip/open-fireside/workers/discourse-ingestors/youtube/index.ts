export const workerTask = 'discourse-ingestors/youtube';
