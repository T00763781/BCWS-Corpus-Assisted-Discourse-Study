export const workerTask = 'discourse-ingestors/instagram';
