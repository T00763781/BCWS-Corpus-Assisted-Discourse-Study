export const workerGroup = 'discourse-ingestors';
