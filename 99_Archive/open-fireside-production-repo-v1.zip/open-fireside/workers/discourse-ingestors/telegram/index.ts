export const workerTask = 'discourse-ingestors/telegram';
