export const workerTask = 'discourse-ingestors/google-news';
