export function buildFacebookIngestJob(targetId: string, url: string) {
  return { platform: 'facebook', targetId, url, mode: 'historical-first' };
}
