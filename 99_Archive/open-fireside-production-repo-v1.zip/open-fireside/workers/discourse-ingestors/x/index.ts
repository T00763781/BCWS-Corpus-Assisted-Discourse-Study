export const workerTask = 'discourse-ingestors/x';
