export const workerTask = 'discourse-ingestors/discord';
