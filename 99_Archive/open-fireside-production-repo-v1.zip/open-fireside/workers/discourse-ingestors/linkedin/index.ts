export const workerTask = 'discourse-ingestors/linkedin';
