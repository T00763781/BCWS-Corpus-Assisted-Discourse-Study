export const workerTask = 'discourse-ingestors/reddit';
