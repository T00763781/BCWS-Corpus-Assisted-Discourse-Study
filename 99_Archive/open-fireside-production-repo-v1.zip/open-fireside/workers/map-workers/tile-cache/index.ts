export const workerTask = 'map-workers/tile-cache';
