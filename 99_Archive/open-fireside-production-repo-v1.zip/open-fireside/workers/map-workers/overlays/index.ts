export const workerTask = 'map-workers/overlays';
