export const workerTask = 'map-workers/layers';
