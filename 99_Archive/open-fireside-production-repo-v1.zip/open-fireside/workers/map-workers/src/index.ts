export const workerGroup = 'map-workers';
