export const workerTask = 'incident-ingestors/emergency-info-bc';
