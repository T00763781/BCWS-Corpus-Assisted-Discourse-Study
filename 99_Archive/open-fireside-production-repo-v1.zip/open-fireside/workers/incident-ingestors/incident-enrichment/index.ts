export const workerTask = 'incident-ingestors/incident-enrichment';
