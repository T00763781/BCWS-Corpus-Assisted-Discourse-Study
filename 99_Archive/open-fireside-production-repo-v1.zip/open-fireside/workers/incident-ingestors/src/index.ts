export const workerGroup = 'incident-ingestors';
