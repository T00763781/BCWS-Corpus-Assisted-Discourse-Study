export const workerTask = 'incident-ingestors/wildfire-situation';
