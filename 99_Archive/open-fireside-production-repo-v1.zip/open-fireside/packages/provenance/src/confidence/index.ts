export const confidence_api = 'provenance/confidence';
