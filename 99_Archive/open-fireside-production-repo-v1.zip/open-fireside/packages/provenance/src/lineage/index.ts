export interface LineageRecord {
  sourceLabel: string;
  capturedAt: string;
  derivation: 'raw' | 'normalized' | 'derived';
}
