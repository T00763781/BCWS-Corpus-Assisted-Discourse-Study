export const scope_selector_api = 'ui-shell/scope-selector';
