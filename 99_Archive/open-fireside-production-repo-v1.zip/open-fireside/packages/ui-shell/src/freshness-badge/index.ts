export const freshness_badge_api = 'ui-shell/freshness-badge';
