export const record_header_api = 'ui-shell/record-header';
