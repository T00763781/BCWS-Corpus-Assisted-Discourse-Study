export const search_bar_api = 'ui-shell/search-bar';
