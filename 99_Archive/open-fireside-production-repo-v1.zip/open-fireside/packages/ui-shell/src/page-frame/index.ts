export interface PageFrameProps {
  title: string;
  hasInspector?: boolean;
  hasStatusBar?: boolean;
}

export function buildPageFrame(props: PageFrameProps) {
  return {
    ...props,
    shell: 'canonical-page-frame',
  };
}
