export const packageId = 'ui-shell';
