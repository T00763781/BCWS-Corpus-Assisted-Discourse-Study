export const provenance_badge_api = 'ui-shell/provenance-badge';
