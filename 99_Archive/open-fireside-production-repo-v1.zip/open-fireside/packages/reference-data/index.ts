import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

export function readReferenceCsv(name: string): string {
  return readFileSync(resolve(process.cwd(), 'data/reference', name), 'utf-8');
}
