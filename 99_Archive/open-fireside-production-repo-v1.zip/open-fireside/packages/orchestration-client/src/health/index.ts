export const health_api = 'orchestration-client/health';
