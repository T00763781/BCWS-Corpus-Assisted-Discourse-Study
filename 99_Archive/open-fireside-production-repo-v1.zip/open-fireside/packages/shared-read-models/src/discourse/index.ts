export const discourse_api = 'shared-read-models/discourse';
