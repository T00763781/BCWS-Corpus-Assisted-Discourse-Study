export const environment_api = 'shared-read-models/environment';
