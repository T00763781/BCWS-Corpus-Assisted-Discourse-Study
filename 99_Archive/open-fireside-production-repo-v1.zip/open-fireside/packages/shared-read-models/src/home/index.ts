export const home_api = 'shared-read-models/home';
