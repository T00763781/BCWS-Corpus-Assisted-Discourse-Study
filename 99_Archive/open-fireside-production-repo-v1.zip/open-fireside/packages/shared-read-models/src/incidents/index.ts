export interface IncidentSummaryReadModel {
  incidentId: string;
  incidentName: string;
  fireCentreName: string;
  stageOfControl?: string;
  latestUpdatedAt?: string;
}
