export const packageId = 'shared-read-models';
