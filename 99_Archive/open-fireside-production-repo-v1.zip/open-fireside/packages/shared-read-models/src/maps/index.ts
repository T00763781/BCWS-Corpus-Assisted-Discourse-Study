export const maps_api = 'shared-read-models/maps';
