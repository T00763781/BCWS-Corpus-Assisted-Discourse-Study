export type UUID = string;

export type FireCentreId = UUID;
export type LocalityId = UUID;
export type IncidentId = UUID;
export type ActorId = UUID;
export type ActorAccountId = UUID;
export type ProtectedEntityId = UUID;
export type ProtectedAccountId = UUID;
export type SourceSurfaceId = UUID;

export type ActorType = 'AGENCY' | 'ORGANIZATION' | 'MEDIA' | 'PROGRAM' | 'PUBLIC_ROLE_PERSON';
export type CoverageStatus = 'NOT_STARTED' | 'STRUCTURAL_COMPLETE' | 'EVIDENCE_COMPLETE';
export type SourceSurfaceType = 'API' | 'WEBSITE' | 'SOCIAL_PLATFORM' | 'MEDIA_SITE' | 'MAP_LAYER';
