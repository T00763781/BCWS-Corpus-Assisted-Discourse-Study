import actorSchema from '../schemas/normalized_actor_record.schema.json';
import accountSchema from '../schemas/normalized_account_record.schema.json';
import incidentSchema from '../schemas/normalized_incident_record.schema.json';

export const schemas = {
  actorSchema,
  accountSchema,
  incidentSchema,
};

export function hasRequiredKeys<T extends object>(value: T, keys: string[]): boolean {
  return keys.every((key) => Object.prototype.hasOwnProperty.call(value, key));
}
