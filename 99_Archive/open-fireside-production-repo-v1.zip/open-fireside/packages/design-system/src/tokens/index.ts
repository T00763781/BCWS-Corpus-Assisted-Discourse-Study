export const colorTokens = {
  bg: '#0b1220',
  panel: '#132034',
  text: '#e7eef7',
  accent: '#7cd0ff',
  warning: '#ffd166',
  danger: '#ff6b6b',
};
