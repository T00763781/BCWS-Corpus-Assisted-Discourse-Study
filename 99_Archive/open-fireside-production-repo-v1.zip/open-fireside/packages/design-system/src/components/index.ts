export const components_api = 'design-system/components';
