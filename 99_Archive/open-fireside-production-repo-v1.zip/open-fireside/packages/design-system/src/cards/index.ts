export const cards_api = 'design-system/cards';
