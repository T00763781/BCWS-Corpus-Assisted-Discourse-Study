export const tabs_api = 'design-system/tabs';
