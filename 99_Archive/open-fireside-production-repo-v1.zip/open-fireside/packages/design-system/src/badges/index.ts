export const badges_api = 'design-system/badges';
