export const packageId = 'design-system';
