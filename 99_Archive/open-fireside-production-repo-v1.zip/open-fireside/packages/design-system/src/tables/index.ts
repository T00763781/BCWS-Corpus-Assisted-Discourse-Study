export const tables_api = 'design-system/tables';
