export const layouts_api = 'design-system/layouts';
