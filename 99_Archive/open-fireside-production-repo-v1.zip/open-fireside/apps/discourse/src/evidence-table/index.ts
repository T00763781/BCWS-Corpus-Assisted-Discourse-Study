export const evidence_table_module = 'discourse/evidence-table';
