export const actor_detail_module = 'discourse/actor-detail';
