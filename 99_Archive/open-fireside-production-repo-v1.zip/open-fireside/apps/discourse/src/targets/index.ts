export function buildDiscourseTargetWorkspace() {
  return {
    stages: ['canonical place universe', 'candidate discovery', 'verification', 'verified registry', 'ingestion'],
  };
}
