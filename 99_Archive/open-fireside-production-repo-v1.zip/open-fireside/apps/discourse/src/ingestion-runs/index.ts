export const ingestion_runs_module = 'discourse/ingestion-runs';
