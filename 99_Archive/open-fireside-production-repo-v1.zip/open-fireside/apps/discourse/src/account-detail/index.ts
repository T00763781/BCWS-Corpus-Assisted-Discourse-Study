export const account_detail_module = 'discourse/account-detail';
