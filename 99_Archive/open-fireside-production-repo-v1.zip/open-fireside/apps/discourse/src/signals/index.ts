export const signals_module = 'discourse/signals';
