export const verification_module = 'discourse/verification';
