export const appId = 'discourse';
export const appTitle = 'Discourse';
export const routes = ["/discourse"];
