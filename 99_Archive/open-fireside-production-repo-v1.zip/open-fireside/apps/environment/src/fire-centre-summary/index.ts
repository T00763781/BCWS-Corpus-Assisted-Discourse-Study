export const fire_centre_summary_module = 'environment/fire-centre-summary';
