export function buildEnvironmentOutlook() {
  return { section: 'outlook', provenanceRequired: true };
}
