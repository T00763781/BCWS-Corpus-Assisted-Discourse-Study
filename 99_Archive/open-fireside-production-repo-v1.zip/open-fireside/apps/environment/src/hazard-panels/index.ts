export const hazard_panels_module = 'environment/hazard-panels';
