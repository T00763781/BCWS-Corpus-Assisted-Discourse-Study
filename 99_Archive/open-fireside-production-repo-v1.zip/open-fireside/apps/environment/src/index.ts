export const appId = 'environment';
export const appTitle = 'Environment';
export const routes = ["/environment"];
