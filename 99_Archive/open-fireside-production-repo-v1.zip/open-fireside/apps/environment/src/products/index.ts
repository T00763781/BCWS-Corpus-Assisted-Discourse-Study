export const products_module = 'environment/products';
