export const status_bar_module = 'shell/status-bar';
