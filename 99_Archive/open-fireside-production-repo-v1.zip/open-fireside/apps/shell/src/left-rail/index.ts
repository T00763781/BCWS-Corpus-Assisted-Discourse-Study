export const left_rail_module = 'shell/left-rail';
