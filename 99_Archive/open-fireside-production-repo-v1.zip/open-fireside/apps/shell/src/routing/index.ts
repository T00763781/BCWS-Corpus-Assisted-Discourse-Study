export const routing_module = 'shell/routing';
