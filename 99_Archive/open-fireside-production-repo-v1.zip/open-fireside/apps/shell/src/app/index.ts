export const shellApp = {
  title: 'Open Fireside Shell',
  primarySurfaces: ['home', 'discourse', 'environment', 'incidents', 'maps'],
  secondarySurface: 'ops-console',
};
