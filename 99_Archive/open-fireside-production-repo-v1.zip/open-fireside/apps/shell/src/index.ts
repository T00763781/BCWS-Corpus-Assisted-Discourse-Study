export const appId = 'shell';
export const appTitle = 'Shell';
export const routes = ["/shell"];
