export const inspector_drawer_module = 'shell/inspector-drawer';
