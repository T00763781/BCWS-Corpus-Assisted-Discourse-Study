export function buildIncidentDetailWorkspace() {
  return { tabs: ['response', 'gallery', 'maps', 'discourse-linkout'] };
}
