export const discourse_linkout_module = 'incidents/discourse-linkout';
