export const appId = 'incidents';
export const appTitle = 'Incidents';
export const routes = ["/incidents"];
