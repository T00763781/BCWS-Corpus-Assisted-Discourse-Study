export const gallery_module = 'incidents/gallery';
