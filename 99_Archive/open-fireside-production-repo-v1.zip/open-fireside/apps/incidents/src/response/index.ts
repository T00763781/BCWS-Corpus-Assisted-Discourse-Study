export const response_module = 'incidents/response';
