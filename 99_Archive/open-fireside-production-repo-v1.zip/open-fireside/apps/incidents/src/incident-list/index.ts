export const incident_list_module = 'incidents/incident-list';
