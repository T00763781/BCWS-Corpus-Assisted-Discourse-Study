export const maps_module = 'incidents/maps';
