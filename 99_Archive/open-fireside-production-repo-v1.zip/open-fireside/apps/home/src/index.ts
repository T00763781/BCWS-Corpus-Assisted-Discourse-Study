export const appId = 'home';
export const appTitle = 'Home';
export const routes = ["/home"];
