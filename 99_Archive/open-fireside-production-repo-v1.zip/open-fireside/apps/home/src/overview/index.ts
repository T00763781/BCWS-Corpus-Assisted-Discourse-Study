export function buildHomeOverview() {
  return {
    headline: 'Cross-surface readiness',
    cards: ['incidents', 'environment', 'discourse', 'maps'],
  };
}
