export const pinned_context_module = 'home/pinned-context';
