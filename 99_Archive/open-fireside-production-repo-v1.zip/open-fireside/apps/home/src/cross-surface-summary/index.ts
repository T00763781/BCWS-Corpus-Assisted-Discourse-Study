export const cross_surface_summary_module = 'home/cross-surface-summary';
