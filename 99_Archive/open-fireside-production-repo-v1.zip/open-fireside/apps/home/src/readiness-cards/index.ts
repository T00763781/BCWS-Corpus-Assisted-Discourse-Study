export const readiness_cards_module = 'home/readiness-cards';
