export const time_controls_module = 'maps/time-controls';
