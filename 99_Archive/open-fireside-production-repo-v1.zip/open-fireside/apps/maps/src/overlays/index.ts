export function buildOverlayWorkspace() {
  return { hasSavedViews: true, hasTimeControls: true };
}
