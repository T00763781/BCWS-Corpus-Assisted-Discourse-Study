export const saved_views_module = 'maps/saved-views';
