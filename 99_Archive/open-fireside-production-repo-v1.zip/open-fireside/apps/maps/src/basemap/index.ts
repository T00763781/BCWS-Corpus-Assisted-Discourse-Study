export const basemap_module = 'maps/basemap';
