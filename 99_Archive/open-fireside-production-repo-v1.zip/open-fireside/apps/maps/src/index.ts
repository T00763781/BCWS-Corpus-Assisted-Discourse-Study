export const appId = 'maps';
export const appTitle = 'Maps';
export const routes = ["/maps"];
