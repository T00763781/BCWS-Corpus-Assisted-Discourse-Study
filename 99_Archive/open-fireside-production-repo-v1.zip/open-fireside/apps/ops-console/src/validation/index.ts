export function buildValidationConsole() {
  return { checks: ['reference-integrity', 'coverage-thresholds', 'contract-parity', 'read-model-parity'] };
}
