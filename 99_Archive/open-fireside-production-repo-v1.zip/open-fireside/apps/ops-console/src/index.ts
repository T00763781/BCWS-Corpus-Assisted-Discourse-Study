export const appId = 'ops-console';
export const appTitle = 'Ops Console';
export const routes = ["/ops-console"];
