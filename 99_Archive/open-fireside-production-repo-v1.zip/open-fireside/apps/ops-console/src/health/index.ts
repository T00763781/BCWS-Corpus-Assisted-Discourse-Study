export const health_module = 'ops-console/health';
