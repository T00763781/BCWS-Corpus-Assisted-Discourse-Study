export const logs_module = 'ops-console/logs';
