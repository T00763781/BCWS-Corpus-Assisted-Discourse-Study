export const ingestors_module = 'ops-console/ingestors';
