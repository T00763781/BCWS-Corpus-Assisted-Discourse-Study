export const queues_module = 'ops-console/queues';
