Temporary scratch outputs for repo hygiene work belong here. Keep this directory gitignored and delete contents between runs if desired. Do not commit files from this folder.
