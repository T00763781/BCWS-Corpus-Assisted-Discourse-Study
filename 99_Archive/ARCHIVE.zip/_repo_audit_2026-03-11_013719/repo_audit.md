﻿# Open Fireside Repo Audit

Generated: 2026-03-11 01:37:20

## Top-level contents


## Registry row counts

- registry\master\actor_targets.csv: 119
- registry\master\actor_account_targets.csv: 298
- registry\master\actor_account_discovery_queue.csv: 320
- registry\master\actor_osint_evidence.csv: 298
- registry\master\public_communities.csv: 13
- registry\master\discourse_sources.csv: 79
- registry\master\verification_log.csv: 294

## Key control files present

- AGENTS.md : PRESENT
- .codex\skills\osint-registry-builder\SKILL.md : PRESENT
- agents\agent_contract.yaml : PRESENT
- registry\ops\universe_registry_orchestration.yaml : PRESENT
- registry\ops\codex_boot_note.md : PRESENT
- reviews\discourse\D-G1\summary.md : PRESENT
- reviews\discourse\D-G2\summary.md : PRESENT

## Output files

- tree.txt
- files.csv
- registry_row_counts.csv
- repo_audit.md
