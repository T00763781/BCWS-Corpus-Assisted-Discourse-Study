`seed-1.zip` was renamed to `seed-1.zip.orig` and moved here to document its archival status. The canonical packaged seed remains `seed.zip` at the repo root.
