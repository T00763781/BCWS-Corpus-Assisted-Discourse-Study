from pathlib import Path
import importlib.util


def test_environment_snapshot_importable():
    path = Path('workers/environment/fetch_environment_snapshot.py')
    spec = importlib.util.spec_from_file_location('fetch_environment_snapshot', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    assert hasattr(mod, 'run')
