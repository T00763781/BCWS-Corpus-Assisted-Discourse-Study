import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_registry_quality_script_runs():
    result = subprocess.run(
        ['python', str(ROOT / 'workers/discourse/registry/check_registry_quality.py'), str(ROOT / 'registry/master/actor_targets.csv')],
        capture_output=True,
        text=True,
        check=True,
    )
    payload = json.loads(result.stdout)
    assert isinstance(payload, list)
    assert payload[0]['rows'] > 0
