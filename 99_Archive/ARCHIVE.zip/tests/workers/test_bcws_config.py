from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[2]
CFG = ROOT / 'workers/incidents/bcws/config.yaml'


def test_bcws_config_keys_exist():
    data = yaml.safe_load(CFG.read_text(encoding='utf-8'))
    for key in ['list_endpoint', 'incident_detail_template', 'attachment_template', 'external_uri_template', 'user_agent']:
        assert key in data
