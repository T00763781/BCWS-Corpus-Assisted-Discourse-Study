from pathlib import Path
import subprocess, sys


def test_validate_repo_state_runs():
    result = subprocess.run([sys.executable, 'tools/validate_repo_state.py'], capture_output=True, text=True)
    assert result.returncode == 0
    assert 'missing_required' in result.stdout
