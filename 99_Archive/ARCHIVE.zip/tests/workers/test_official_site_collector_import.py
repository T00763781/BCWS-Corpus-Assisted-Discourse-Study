from pathlib import Path
import importlib.util


def test_official_site_collector_importable():
    path = Path('workers/discourse/official_sites/collect_official_site.py')
    spec = importlib.util.spec_from_file_location('collect_official_site', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    assert hasattr(mod, 'run')
