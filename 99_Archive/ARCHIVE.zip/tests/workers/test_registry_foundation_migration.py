from pathlib import Path
import sqlite3


ROOT = Path(__file__).resolve().parents[2]
MIGRATIONS = [
    ROOT / "storage/db/migrations/001_init.sql",
    ROOT / "storage/db/migrations/002_discourse_environment.sql",
    ROOT / "storage/db/migrations/003_registry_foundation.sql",
]

REQUIRED_FOUNDATION_TABLES = {
    "fire_centres",
    "municipalities",
    "actors",
    "actor_accounts",
    "actor_evidence",
    "discovery_leads",
    "discourse_sources",
    "public_communities",
    "monitoring_subscriptions",
    "ingest_runs",
    "raw_captures",
}


def test_registry_foundation_tables_exist():
    conn = sqlite3.connect(":memory:")
    for migration in MIGRATIONS:
        conn.executescript(migration.read_text(encoding="utf-8"))

    rows = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
    existing = {row[0] for row in rows}
    assert REQUIRED_FOUNDATION_TABLES.issubset(existing)
