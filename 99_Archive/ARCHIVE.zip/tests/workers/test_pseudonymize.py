from workers.common.hashing.pseudonymize import stable_pseudonym


def test_stable_pseudonym_is_stable():
    assert stable_pseudonym('Alice', 'salt') == stable_pseudonym('alice', 'salt')


def test_stable_pseudonym_changes_with_salt():
    assert stable_pseudonym('Alice', 'a') != stable_pseudonym('Alice', 'b')
