import json
import subprocess
import sys
from pathlib import Path


def test_import_registry_csv_to_staging_reports_rejections(tmp_path):
    repo = Path(__file__).resolve().parents[2]
    db_path = tmp_path / "test.sqlite"
    out_dir = tmp_path / "diag"
    csv_path = tmp_path / "actor_targets.csv"
    csv_path.write_text(
        "\n".join(
            [
                "target_id,target_name,verification_status,geography",
                "actor_ok,Example Actor,approved,\"Quesnel, British Columbia\"",
                "actor_bad,,approved,\"Quesnel, British Columbia\"",
            ]
        ),
        encoding="utf-8",
    )

    cmd = [
        sys.executable,
        str(repo / "tools/admin/import_registry_csv_to_staging.py"),
        "--db",
        str(db_path),
        "--inputs",
        str(csv_path),
        "--output-dir",
        str(out_dir),
        "--clear-staging-first",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    payload = json.loads(result.stdout)
    summary_path = Path(payload["summary_json"])
    summary = json.loads(summary_path.read_text(encoding="utf-8"))

    assert summary["totals"]["imported"] == 1
    assert summary["totals"]["rejected"] == 1
