import csv
import json
import subprocess
import sys
from pathlib import Path


def test_dedupe_registry_generates_duplicate_report(tmp_path):
    repo = Path(__file__).resolve().parents[2]
    csv_path = tmp_path / "sample.csv"
    out_dir = tmp_path / "diag"
    csv_path.write_text(
        "\n".join(
            [
                "target_name,url_or_endpoint",
                "City of Example,https://example.gov/page",
                "City of Example,https://example.gov/page",
                "City of Exampel,https://example.gov/page",
            ]
        ),
        encoding="utf-8",
    )

    cmd = [
        sys.executable,
        str(repo / "tools/admin/dedupe_registry.py"),
        "--inputs",
        str(csv_path),
        "--output-dir",
        str(out_dir),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    payload = json.loads(result.stdout)
    summary = json.loads(Path(payload["summary_json"]).read_text(encoding="utf-8"))
    report_path = Path(payload["report_csv"])

    assert summary["exact_count"] >= 1
    with report_path.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) >= 1
