import csv
import json
import sqlite3
import subprocess
import sys
from pathlib import Path


def test_export_registry_snapshots_from_staging(tmp_path):
    repo = Path(__file__).resolve().parents[2]
    db_path = tmp_path / "staging.sqlite"
    out_dir = tmp_path / "snapshots"
    conn = sqlite3.connect(db_path)
    conn.execute('CREATE TABLE staging_actors (target_id TEXT, target_name TEXT, verification_status TEXT)')
    conn.execute('CREATE TABLE staging_actor_accounts (account_target_id TEXT, parent_target_id TEXT, target_url_or_surface TEXT)')
    conn.execute('CREATE TABLE staging_actor_evidence (evidence_id TEXT, actor_id TEXT, account_target_id TEXT)')
    conn.execute("INSERT INTO staging_actors VALUES ('actor_1','Actor One','approved')")
    conn.execute("INSERT INTO staging_actor_accounts VALUES ('acct_1','actor_1','https://example.com')")
    conn.execute("INSERT INTO staging_actor_evidence VALUES ('ev_1','actor_1','acct_1')")
    conn.commit()
    conn.close()

    cmd = [
        sys.executable,
        str(repo / "tools/admin/export_registry_snapshots.py"),
        "--db",
        str(db_path),
        "--output-dir",
        str(out_dir),
        "--use-staging",
        "--tables",
        "actors",
        "actor_accounts",
        "actor_evidence",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    payload = json.loads(result.stdout)
    manifest_path = Path(payload["manifest"])
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    assert len(manifest["exports"]) == 3
    actor_csv = out_dir / "actor_targets.csv"
    with actor_csv.open("r", encoding="utf-8", newline="") as handle:
        headers = next(csv.reader(handle))
    assert "target_id" in headers
