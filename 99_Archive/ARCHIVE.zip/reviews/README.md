# Reviews

Every gate review for Earl should live under this folder.
Each gate gets its own directory with evidence, diagnostics, and an explicit decision request.
