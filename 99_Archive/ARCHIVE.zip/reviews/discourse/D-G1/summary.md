# D-G1 Gate Summary - Discourse / Actors Lane

## Date
2026-03-10

## Scope completed
- Closed D-G1 only for discourse/actors lane.
- No D-G2 work started.
- No registry expansion performed.
- No incident, environment, map, or app work performed.

## Minimum fixes completed
1. Reconciled `seeded_unverified` status semantics in `registry/dictionaries/status_values.yaml`.
2. Fixed `identity_rule` vs `identity_handling` mismatch in `workers/discourse/official_sites/collect_official_site.py`.
3. Documented platform-root URL problem in `registry/master/discourse_sources.csv` (`discourse_011`, `discourse_014`-`discourse_018`) as discovery placeholders.
4. Documented desktop app stack as WinUI 3 / Windows App SDK `stub`, not WPF.

## Final D-G1 checker alignment patch
- Updated `workers/discourse/registry/check_registry_quality.py` to load valid statuses from `registry/dictionaries/status_values.yaml` instead of using a stale hardcoded set.
- Updated URL/discovery validation logic to support account-target seed patterns:
- Accept `target_url_or_surface` as URL field for account rows.
- Do not treat discovery-query rows (`manual_search_uri` + `discovery_query`) as missing URL failures.
- Added `expected_state_counts` output so seeded/discovery states are visible without being treated as errors.

## Validation run
Command:
`python workers/discourse/registry/check_registry_quality.py registry/master/actor_targets.csv registry/master/actor_account_targets.csv registry/master/public_communities.csv registry/master/discourse_sources.csv`

Result:
- Exit code `0`
- `issue_count: 0` for all four discourse registry CSVs
- Expected seeded/discovery states reported in `expected_state_counts`

## D-G1 closure position
D-G1 validation is now semantically clean for the current seeded discourse registry and is ready for approval.
