﻿# D-G2 Summary - Cariboo Wave 1.1 deep OSINT expansion

## Date
2026-03-11

## Scope
- Wave 1.1 deep OSINT registry expansion for Cariboo municipalities only: `100 Mile House`, `Clinton`, `Quesnel`, `Williams Lake`, `Wells`.
- Focus: actor expansion first, then cross-platform channel discovery and evidence linkage.
- No Wave 2 work, no pipeline work, and no changes outside allowed canonical paths.

## What changed
- Added 38 new Cariboo actor rows (public individuals, emergency/public-safety, institutions/operators, and community surfaces).
- Added 79 resolved account rows with 79 matching evidence rows.
- Added 10 unresolved discovery leads for missing plausible official public-individual/emergency social surfaces.
- Added 10 discourse-source rows and 5 public-community rows for local news/community/operator coverage.
- Added 5 verification-log entries for Wave 1.1 packet review traceability.

## Municipality v4 snapshot
| Municipality | Actor count | Resolved | Non-web | Platforms | Public-individual social | Emergency-role social | News sources | Community sources | Operator sources | Status |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| 100 Mile House | 21 | 32 | 11 | 5 | 0 | 5 | 3 | 2 | 1 | under-complete |
| Clinton | 24 | 34 | 10 | 5 | 0 | 5 | 3 | 2 | 0 | under-complete |
| Quesnel | 25 | 40 | 15 | 5 | 0 | 5 | 4 | 1 | 1 | under-complete |
| Williams Lake | 22 | 34 | 12 | 5 | 0 | 5 | 3 | 1 | 2 | under-complete |
| Wells | 20 | 42 | 22 | 5 | 0 | 5 | 2 | 2 | 1 | under-complete |

## Row count deltas (Wave 1.1 vs Wave 1 baseline)
- `actor_targets.csv`: 184 -> 222 (`+38`)
- `actor_account_targets.csv`: 380 -> 459 (`+79`)
- `actor_account_discovery_queue.csv`: 336 -> 346 (`+10`)
- `actor_osint_evidence.csv`: 380 -> 459 (`+79`)
- `public_communities.csv`: 17 -> 22 (`+5`)
- `discourse_sources.csv`: 98 -> 108 (`+10`)
- `verification_log.csv`: 314 -> 319 (`+5`)

## Validation
- Ran `python workers/discourse/registry/check_registry_quality.py registry/master/actor_targets.csv registry/master/actor_account_targets.csv registry/master/actor_account_discovery_queue.csv registry/master/actor_osint_evidence.csv registry/master/public_communities.csv registry/master/discourse_sources.csv`.
- Exit code: `0`
- `issue_count`: `0` for all six checked registry files.

## Control-plane notes
- `qa_merge_agent` remained the only writer for `registry/master/*`.
- `reviews/discourse/D-G2/diagnostics/cariboo_completion_table_v4.csv` is the Wave 1.1 completion artifact.
- Remaining blockers are concentrated in attributable public-individual social accounts and municipality-specific operator/community-source diversity in selected packets.
