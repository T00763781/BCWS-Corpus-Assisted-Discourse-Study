﻿# D-G2 Decision Request - Cariboo Wave 1.1 deep OSINT expansion

## Gate
D-G2 - discourse/actors registry expansion and attribution hardening

## Request
Review and approve Wave 1.1 for the Cariboo municipality packet with deep actor + platform expansion.

## Why Wave 1.1 is materially stronger
- Expanded actor registry depth first (+38 actors), especially public individuals and emergency/institution/operator surfaces.
- Shifted channel mix away from website-only bias with large non-web expansion (+79 resolved channels) and strong evidence linkage.
- Preserved resolved/discovery split: unresolved official social leads are explicit discovery rows, not fabricated resolved accounts.
- Added local news/community/operator discourse and public-community surfaces to strengthen municipality-level discourse context.
- Completion remains blocker-aware: municipalities not meeting all account/source floors are marked under-complete with explicit notes.

## Validation status
- Required checker run completed with exit code `0`.
- `issue_count = 0` for `actor_targets.csv`, `actor_account_targets.csv`, `actor_account_discovery_queue.csv`, `actor_osint_evidence.csv`, `public_communities.csv`, and `discourse_sources.csv`.
- Canonical completion artifact for this run: `reviews/discourse/D-G2/diagnostics/cariboo_completion_table_v4.csv`.
