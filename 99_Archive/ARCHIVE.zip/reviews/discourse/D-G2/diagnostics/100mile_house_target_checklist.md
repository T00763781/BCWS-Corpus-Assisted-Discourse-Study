# 100 Mile House Municipality Packet Checklist

Minimum 12 actor slots (Cariboo fire centre, locality-grade geography, evidence-ready):
1. Municipality root (official district website)
2. Official bulletin/news/alerts surface (news + alert page, emergency updates)
3. Mayor / elected head public official
4. Council / governing body surface
5. Emergency-role public individual (fire chief, emergency manager, communicator)
6. Fire service lead (distinct from mayor/emergency lead if possible)
7. Local emergency page or alerts page (EOC, emergency notifications)
8. Local news outlet (radio, print, digital newsroom)
9. Local public discussion/community signal (forum, community board, social hub)
10. Local visitor/DMO/welcome body (tourism office, visitor centre)
11. Wildfire-relevant local institution/operator (utility, watershed, transport)
12. Second wildfire-relevant local institution or public signal (health, school district, operator)

Optional expansion slots (up to ~20):
- Additional official social/media outlets tied to the municipality
- Second public individual (deputy mayor, councillor with wildfire remit)
- Local school district / public institution with wildfire messaging
- Utility/distributor public surface (electricity, water, transit)
- Local health/public safety actor with wildfire context
- Second local news or community source
- Wildfire-relevant local business/operator or infrastructure actor

Each slot should note:
- Target name or handle
- Source URL or platform
- Desired account type (website, bulletin, social)
- Evidence link note
- Fire centre (Cariboo)
