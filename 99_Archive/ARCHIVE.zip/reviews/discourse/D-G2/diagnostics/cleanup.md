### Repo hygiene cleanup log (2026-03-11)
- Created canonical logging (`logs/repo-hygiene/`) and scratch (`tmp/repo-hygiene/`) folders with README markers and started `run.log`.
- Documented seed mirrors with README notes and expanded the seed import staging README at `registry/imports/seed/`.
- Quarantined duplicate `seed-1.zip` by renaming/moving it to `_repo_audit_2026-03-11_013719/seed-1.zip.orig` and added `DUPLICATE_SEED_README.md`.
No registry/master or registry/ops edits were touched (path-hygiene only).
