﻿# Cariboo Wave 1.1 conflicts and notes

## Canonical merge notes
- Wave 1.1 preserved existing valid Cariboo rows and performed additive deep-OSINT expansion only.
- Actor expansion preceded channel expansion; all new resolved account rows carry matching evidence rows.
- Platform-root URLs were not used as resolved rows.

## Remaining blocker conditions
- All five municipalities still lack attributable public-individual social accounts at the required floor (`>=2`).
- Municipality-specific operator-source diversity remains below floor in 100 Mile House, Clinton, Quesnel, and Wells in this pass.
- Quesnel and Williams Lake remain short on community-source count under the strict v4 thresholds.

## Control-plane mismatch to carry forward
- `reviews/discourse/D-G2/diagnostics/fire_centre_checks.csv` still routes Clinton to Kamloops while this controlled Cariboo scope keeps Clinton in Wave 1.1 packet ownership.
