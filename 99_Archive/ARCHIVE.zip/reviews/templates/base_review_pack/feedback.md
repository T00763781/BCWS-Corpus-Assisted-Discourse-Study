Decision: revise

What is wrong:
1.
2.

Must fix before proceed:
-

Can wait:
-

Promote to canonical? no
