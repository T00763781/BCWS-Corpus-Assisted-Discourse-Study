# Decision Request

## What is working
-

## What is still provisional
-

## Decision needed
State exactly what Earl should approve, revise, or block.
