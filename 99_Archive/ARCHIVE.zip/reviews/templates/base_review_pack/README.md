# Base Review Pack

A good review pack should let Earl answer three questions quickly:
1. what changed?
2. what is now working?
3. what decision is needed before Codex continues?

Populate all required files before asking for approval.
