# Seed import staging

This folder is the canonical unpack/stage area for new packaged seeds. Copy unpacked CSVs here before importing them into `registry/seed/`. Do not edit or merge seed data directly from `open_fireside_universe_seed/` or `seed/open_fireside_universe_seed/`.
