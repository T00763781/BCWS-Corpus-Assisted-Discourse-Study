# registry/master

This folder contains the canonical editable registry CSVs.
If the same logical table exists in `recon/parsed/`, the version here wins.

## Canonical tables
- `actor_targets.csv`
- `actor_account_targets.csv`
- `public_communities.csv`
- `discourse_sources.csv`
- `incident_sources.csv`
- `environment_sources.csv`
- `map_layers.csv`
- `tagging_dictionary.csv`
- `verification_log.csv`

## Editing rules
- preserve column order unless there is a documented reason to change it
- do not silently introduce new enum values; update `registry/dictionaries/` too
- prefer downgrading questionable rows to `provisional` or `discovery_needed` rather than inflating confidence
- record meaningful workflow changes in `docs/decisions/decision-log.md`
- when verification changes materially, update `verification_log.csv` or notes fields

## Row lifecycle
1. seeded
2. provisional or discovery_needed
3. verified_accessible / verified_empty_but_valid / blocked_or_auth_required / unreachable / parse_failed / manual_review_needed / rejected

## Identity handling
Use the identity rules in `registry/dictionaries/identity_rules.yaml` and the methodology docs when a row touches private-individual discourse.
