This folder is the canonical log/diagnostic location for repo hygiene passes. Append summaries to `run.log` and keep diagnostics under `diagnostics/`. Do not scatter logs elsewhere.
