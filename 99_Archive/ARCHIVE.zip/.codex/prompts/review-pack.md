# Codex Prompt — Review Pack

Every review pack must explain:
- what changed,
- what is working,
- what is still provisional,
- what decision Earl needs to make,
- what commands were run,
- what evidence files or DB rows support the claim.
