# Codex Prompt — Environment Lane

Work only on source proof, snapshotting, and clear separation between state feeds and map/layer metadata.
Do not claim environment lane maturity beyond the implemented helpers.
