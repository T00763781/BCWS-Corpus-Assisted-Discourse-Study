# Codex Prompt — Incident Lane

Use only BCWS public web-app-derived sources already documented in the repo.
Do not expand incident collection beyond BCWS during this lane.

## Mandatory checks
- `python workers/incidents/bcws/collect_bcws.py --db storage/db/local/open_fireside.sqlite --limit 5`
- `python tools/db_inspect.py storage/db/local/open_fireside.sqlite --query "SELECT * FROM incident_versions ORDER BY collected_at DESC LIMIT 10"`
