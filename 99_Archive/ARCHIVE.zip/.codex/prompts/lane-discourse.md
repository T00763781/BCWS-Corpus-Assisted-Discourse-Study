# Codex Prompt — Discourse Lane

Read in order:
1. `AGENTS.md`
2. `docs/autorun/operating-order.md`
3. `docs/autorun/lanes.yaml`
4. `docs/lane-notes/discourse.md`
5. `docs/targeting-rules.md`
6. `docs/repo-truth-matrix.md`

## Your task
Improve the discourse registry for the 2025–2026 wildfire year without inventing unsupported targets or overstating verification.

## Allowed write zones
- `registry/master/actor_targets.csv`
- `registry/master/actor_account_targets.csv`
- `registry/master/public_communities.csv`
- `registry/master/discourse_sources.csv`
- `registry/master/verification_log.csv`
- `docs/decisions/decision-log.md`
- `reviews/discourse/D-G1/*`

## Forbidden write zones
- broad UI files
- `recon/raw/`
- `dist/`
- packaging scripts unless instructed

## Mandatory checks before stopping
- `python tools/verify_targets.py registry/master/actor_targets.csv registry/master/actor_account_targets.csv registry/master/public_communities.csv registry/master/discourse_sources.csv`
- `python workers/discourse/registry/check_registry_quality.py registry/master/*.csv`
- `python workers/discourse/official_sites/collect_official_site.py --csv registry/master/discourse_sources.csv --db storage/db/local/open_fireside.sqlite --limit 3`

## Stop condition
Build `reviews/discourse/D-G1/` and set discourse lane status to `ready_for_user`.
