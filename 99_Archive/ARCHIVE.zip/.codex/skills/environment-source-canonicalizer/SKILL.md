---
name: environment-source-canonicalizer
description: verify and classify environment and map source families. use when codex needs a repeatable workflow for this exact task inside the open fireside repo.
---
# Purpose
Use this skill only for its named workflow.

## Read first
- `AGENTS.md`
- `docs/repo-truth-matrix.md`
- the active lane note

## Primary files to read
- registry/master/environment_sources.csv
- registry/master/map_layers.csv
- recon/raw/*
- docs/recon/*

## Allowed change zones
- registry/master/environment_sources.csv
- registry/master/map_layers.csv
- docs/decisions/decision-log.md

## Workflow
1. separate state feeds from map/layer metadata
2. mark unstable ArcGIS roots honestly
3. use snapshot helpers for proof
4. do not overstate source stability

## Validation
Run the lane-appropriate commands from `AGENTS.md` before stopping.

## Stop condition
Stop with a review pack or explicit lane-state update. Do not silently continue into the next lane.
