---
name: discourse-ingestion-method-planner
description: choose collection method per discourse surface. use when codex needs a repeatable workflow for this exact task inside the open fireside repo.
---
# Purpose
Use this skill only for its named workflow.

## Read first
- `AGENTS.md`
- `docs/repo-truth-matrix.md`
- the active lane note

## Primary files to read
- registry/master/discourse_sources.csv
- docs/methodology.md
- docs/targeting-rules.md

## Allowed change zones
- registry/master/discourse_sources.csv
- docs/decisions/decision-log.md

## Workflow
1. choose from api, rss, html_page, headless_browser, manual_search_uri, not_safely_collectible
2. preserve notes and rationale
3. prefer simpler public methods first

## Validation
Run the lane-appropriate commands from `AGENTS.md` before stopping.

## Stop condition
Stop with a review pack or explicit lane-state update. Do not silently continue into the next lane.
