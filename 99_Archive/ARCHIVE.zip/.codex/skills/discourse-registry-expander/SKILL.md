---
name: discourse-registry-expander
description: discourse lane registry work. use when codex needs a repeatable workflow for this exact task inside the open fireside repo.
---
# Purpose
Use this skill only for its named workflow.

## Read first
- `AGENTS.md`
- `docs/repo-truth-matrix.md`
- the active lane note

## Primary files to read
- registry/master/actor_targets.csv
- registry/master/actor_account_targets.csv
- registry/master/public_communities.csv
- registry/master/discourse_sources.csv

## Allowed change zones
- registry/master/*.csv
- docs/decisions/decision-log.md
- reviews/discourse/D-G1/*

## Workflow
1. read targeting and identity rules
2. update only canonical registry CSVs
3. downgrade uncertain rows instead of inflating confidence
4. preserve notes for non-obvious decisions
5. run verifier and registry QA
6. build D-G1 review pack

## Validation
Run the lane-appropriate commands from `AGENTS.md` before stopping.

## Stop condition
Stop with a review pack or explicit lane-state update. Do not silently continue into the next lane.
