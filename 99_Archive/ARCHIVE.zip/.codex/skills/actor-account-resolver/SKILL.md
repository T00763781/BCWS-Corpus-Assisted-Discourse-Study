---
name: actor-account-resolver
description: resolve named public targets into official websites and public account surfaces without inventing handles. use when codex needs a repeatable workflow for this exact task inside the open fireside repo.
---
# Purpose
Use this skill only for its named workflow.

## Read first
- `AGENTS.md`
- `docs/repo-truth-matrix.md`
- the active lane note

## Primary files to read
- registry/master/actor_targets.csv
- registry/master/actor_account_targets.csv
- registry/dictionaries/platforms.yaml

## Allowed change zones
- registry/master/actor_account_targets.csv
- docs/decisions/decision-log.md

## Workflow
1. keep named public targets named
2. resolve only official or clearly public surfaces
3. if unresolved, create discovery rows marked discovery_needed
4. do not invent handles
5. re-run target verification

## Validation
Run the lane-appropriate commands from `AGENTS.md` before stopping.

## Stop condition
Stop with a review pack or explicit lane-state update. Do not silently continue into the next lane.
