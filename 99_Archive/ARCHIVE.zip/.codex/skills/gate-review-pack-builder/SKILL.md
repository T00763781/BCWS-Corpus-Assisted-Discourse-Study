---
name: gate-review-pack-builder
description: produce review packs that let Earl approve or revise the next step. use when codex needs a repeatable workflow for this exact task inside the open fireside repo.
---
# Purpose
Use this skill only for its named workflow.

## Read first
- `AGENTS.md`
- `docs/repo-truth-matrix.md`
- the active lane note

## Primary files to read
- reviews/templates/base_review_pack/*
- docs/gates-and-feedback-protocol.md
- tools/build_review_pack.py

## Allowed change zones
- reviews/*
- tools/build_review_pack.py

## Workflow
1. build the gate folder
2. include summary, decision request, changed files, diagnostics, raw samples, db samples, screenshots if any
3. make the decision request short and explicit

## Validation
Run the lane-appropriate commands from `AGENTS.md` before stopping.

## Stop condition
Stop with a review pack or explicit lane-state update. Do not silently continue into the next lane.
