---
name: open-fireside-repo-hygiene
description: Open Fireside–specific repo hygiene guardrails that forbid duplicate canonical writes, define logging/diagnostics, and keep multi-agent registry work within the control plane.
---

# Purpose
Use this skill to anchor every Codex contribution in Open Fireside to the control-plane folders, to log each run cleanly, and to enforce deterministic multi-agent discipline. No pipelines, incidents, environment, maps, or UI work should be launched while this skill is active.

## Read first
1. `AGENTS.md` (mission, lane order, gates, truth map, validation commands)
2. `docs/repo-truth-matrix.md` (what folders are mature)
3. `docs/repo-map.md` (control plane map)
4. `agents/agent_contract.yaml` (fire-centre/multi-agent contract)
5. `registry/ops/universe_registry_orchestration.yaml` (shared control plane)
6. The latest `reviews/discourse/D-G2/summary.md` (current hygiene status and merged seed)

## Observed hygiene problems in the current repo shape
- Multiple seed artifacts exist (`seed.zip`, `seed-1.zip`, `open_fireside_universe_seed/`, `seed/open_fireside_universe_seed/`, `_repo_audit_*/` snapshots) with no single canonical write location.
- Duplicated directories contain the same CSV sources but in varying nested paths, which invites accidental writes in the wrong folder.
- No explicit policy currently exists for where logs, diagnostics, or temporary artifacts belonging to Codex runs should live, so ad hoc outputs scatter through the tree.
- Multi-agent work is emerging via `agent_contract.yaml` and `universe_registry_orchestration.yaml`, yet contributions risk stepping on each other without serialized/merge-controlled guidance.

## Canonical folder rules
Hardcode these as the only write targets for their families and never create competing canonical folders.
1. Registry masters → `registry/master/`
2. Registry ops/control plane → `registry/ops/`
3. Registry seeds → `registry/seed/` (includes `registry/seed/fire_centre_directories/` and top-level seed CSVs)
4. Review packs → `reviews/<lane>/<gate>/` (includes audits/ diagnostics/ samples inside that gate)
5. Workers → `workers/...`
6. Docs → `docs/...`
7. Tools → `tools/...`
8. Tests → `tests/...`
9. Temporary audit outputs → `_repo_audit_*`
10. Packaged seed artifact → single canonical `seed.zip` in the repo root (never rewrite duplicates)

Forbidden writes:
- Do not write registry masters or canonical seeds into duplicate seed folders (e.g., `open_fireside_universe_seed/`, `seed/open_fireside_universe_seed/`, or `_repo_audit_*` snapshots). Those are reference/artifact folders only.
- Never add canonical files to unpacked zip mirrors (`open_fireside_universe_seed/seed/` etc.) unless you are packaging a new seed release and explicitly note that the added copy is archival.

## Duplicate-location handling
1. Always identify canonical folders explicitly before writing. If you encounter `open_fireside_universe_seed/` or `seed/open_fireside_universe_seed/`, treat them as duplicate/reference copies; the canonical write happens under `registry/seed/` or `seed.zip`.
2. Document each duplicate you touch (e.g., mention in your run log or review summary that `seed-1.zip` exists) and recommend quarantine or archival handling (move to `_repo_audit_YYYY-MM-DD/` with a README entry). Do not silently write into either copy.
3. If both `seed.zip` and `seed-1.zip` exist, treat `seed.zip` as the canonical packaged artifact: read from it, copy from it, and never write new data into `seed-1.zip`. Refer to `docs/runbook/repo-hygiene-rules.md` for the recommended quarantine naming (e.g., rename the duplicate to `seed-1.zip.orig` before archiving).
4. When a new seed is unpacked for reference, keep the unpacked directory read-only; only copy data needed into `registry/seed/`.

## Multi-agent write discipline
1. Files safe for parallel edits: `docs/runbook/*`, skills under `.codex/skills/` (if agents coordinate through the runbook), and read-only audit artifacts. Document collisions in your review pack.
2. Files requiring serialized/merge-controlled edits: `agents/agent_contract.yaml`, `registry/ops/universe_registry_orchestration.yaml`, `registry/master/actor_*`, `registry/master/discourse_sources.csv`, `registry/master/verification_log.csv`. These must only be updated by the merge/QA agent (see agent contract) after fire-centre packets finish and conflicts are resolved.
3. Orchestration is source of truth. Always read `agents/agent_contract.yaml` and `registry/ops/universe_registry_orchestration.yaml` before editing registry artifacts, and follow the listed owner agents for each packet.
4. Each agent limits writes to its assigned fire-centre scope or complementary provincewide files. When multiple agents need to touch the same file, defer to the `qa_merge_agent` for the final write; the QA agent should coordinate merges and evidence linkage.
5. Merge/QA agent responsibilities: dedupe, geography normalization, evidence linkage, final canonical writes for `registry/master/*`, and update review packs accordingly.

## Logging rules
1. Canonical run log location: `logs/repo-hygiene/run.log`. Append every Codex execution summary (family touched, time, agent rule) here. Create the folder if missing but never commit the log if it contains runtime secrets.
2. Diagnostics/artefacts: `logs/repo-hygiene/diagnostics/` (store structured diagnostics JSON/CSV; rotate by date).  
3. Review-pack evidence: keep the official run artifacts inside `reviews/<lane>/<gate>/diagonistics/` (per gate template) and `reviews/<lane>/<gate>/sample_raw/`.
4. Temporary scratch outputs: `tmp/repo-hygiene/` (non-committed, gitignored, created per run). Do *not* move temporary files into canonical zones.
5. Forbidden artifacts: do not commit raw HTTP payload dumps, browser session cookies, or zipped scratch directories. Also, never commit logs that contain plaintext credentials or seed duplicates.

## Registry-specific rules
- `registry/master/actor_account_targets.csv` must contain resolved direct public URLs only; platform-root URLs are disallowed. Every row needs `evidence_id` pointing to `actor_osint_evidence.csv`.
- `registry/master/actor_account_discovery_queue.csv` may contain only unresolved leads (`discovery_needed`, `provisional`, etc.) along with `discovery_query` metadata.
- `registry/master/actor_osint_evidence.csv` holds attribution evidence only; each entry must reference a resolved account and use public attribution sources.
- Never store private-citizen contact information. Only public officials, municipalities, regional districts, ministries, DMOs, or official communicators may include public contact info.
- Local actors require locality-grade geography (city/town + `British Columbia`). Avoid province-only entries unless the actor truly lacks locality data.
- Municipalities/localities seeded via `registry/seed/` must keep their fire-centre tag unless contrary evidence is documented in a review note.

## Generated vs canonical distinction
1. Canonical sources: `registry/master/*`, `registry/ops/*`, `docs/*`, `tools/*`, `tests/*`, `agents/agent_contract.yaml`, `reviews/<lane>/<gate>/manifest*`.
2. Generated snapshots: `_repo_audit_*` (files.csv, registry_row_counts.csv, tree.txt) are diagnostics; treat them as ephemeral references and never edit canonical tables there.
3. Review-pack outputs (summary.md, decision_request.md, changed_files.txt, manifest.json, diagnostics/, sample_raw/) stay under `reviews/<lane>/<gate>/`.
4. Imported seed material: `registry/seed/*` is the only place to consume the new seed; zipped stores (`seed.zip`) or mirror directories (`open_fireside_universe_seed/`, `seed/open_fireside_universe_seed/`) stay read-only references.
5. Archived/reference-only files (e.g., `seed-1.zip`, previous `_repo_audit_*` folders) should be marked in `docs/runbook/repo-hygiene-rules.md` as archive copies and not updated during active work.

## Stop-and-escalate rules
Stop and document a review note whenever you encounter:
1. Two candidate canonical folders (e.g., `registry/seed/` vs. `seed/open_fireside_universe_seed/`) both being writable. Record which one must stay canonical in the review pack before proceeding.
2. A seed folder conflicting with a registry canonical folder (e.g., when a seed copy appears inside `registry/seed/`). Escalate via `reviews/discourse/D-G2/decision_request.md` if needed.
3. A write that would touch both canonical and duplicate locations simultaneously. Pause and note the potential conflict.
4. Ambiguous naming/location (folders with multiple possible canonical meanings). Do not invent new canonical names—update the runbook and share the reasoning before writing.
5. Multi-agent conflicts (two agent roles needing the same file). Let the QA agent coordinate and add a note to `reviews/<lane>/<gate>/diagnostics/conflicts.md`.

## Cleanup recommendation behavior
Do not delete duplicates automatically. Instead:
1. Mark duplicates (e.g., "seed-1.zip is duplicate of `seed.zip`") in the runbook or review summary.
2. Recommend quarantine by moving duplicates to `_repo_audit_<timestamp>/` or renaming them (e.g., `seed-1.zip.orig`) and document the steps in `reviews/<lane>/<gate>/diagnostics/cleanup.md`.
3. Prefer non-destructive actions: copy needed data into canonical zones, log the duplicate as a reference, and note the hygiene recommendation.
4. Record all hygiene recommendations in the review pack summary and changed_files manifest so future agents know why duplicates remain.

## Supporting doc
See `docs/runbook/repo-hygiene-rules.md` for the living checklist that implementations should cite when describing cleanup recommendations, logging conventions, or canonical path enforcement.
