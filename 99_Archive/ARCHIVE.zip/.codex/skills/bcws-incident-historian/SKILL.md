---
name: bcws-incident-historian
description: build and deepen the BCWS incident lane only from BCWS sources. use when codex needs a repeatable workflow for this exact task inside the open fireside repo.
---
# Purpose
Use this skill only for its named workflow.

## Read first
- `AGENTS.md`
- `docs/repo-truth-matrix.md`
- the active lane note

## Primary files to read
- workers/incidents/bcws/collect_bcws.py
- workers/incidents/bcws/config.yaml
- storage/db/migrations/*.sql
- registry/master/incident_sources.csv

## Allowed change zones
- workers/incidents/bcws/*
- storage/db/migrations/*.sql
- tests/workers/*
- reviews/incidents/*

## Workflow
1. preserve BCWS-only scope
2. write raw before normalized where feasible
3. append history, do not clear and replace
4. track attachments and external URIs
5. prove with SQLite queries

## Validation
Run the lane-appropriate commands from `AGENTS.md` before stopping.

## Stop condition
Stop with a review pack or explicit lane-state update. Do not silently continue into the next lane.
