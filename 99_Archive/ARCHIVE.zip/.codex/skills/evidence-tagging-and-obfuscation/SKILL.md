---
name: evidence-tagging-and-obfuscation
description: apply identity handling and tagging rules consistently. use when codex needs a repeatable workflow for this exact task inside the open fireside repo.
---
# Purpose
Use this skill only for its named workflow.

## Read first
- `AGENTS.md`
- `docs/repo-truth-matrix.md`
- the active lane note

## Primary files to read
- docs/methodology.md
- docs/evidence-review-standard.md
- registry/dictionaries/*.yaml
- workers/common/hashing/pseudonymize.py

## Allowed change zones
- registry/master/*.csv
- workers/common/hashing/pseudonymize.py
- docs/decisions/decision-log.md

## Workflow
1. retain named public targets
2. obfuscate private individuals at ingestion
3. keep tags and statuses controlled
4. never leave identity-handling ambiguous

## Validation
Run the lane-appropriate commands from `AGENTS.md` before stopping.

## Stop condition
Stop with a review pack or explicit lane-state update. Do not silently continue into the next lane.
