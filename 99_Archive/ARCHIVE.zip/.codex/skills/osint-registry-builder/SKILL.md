---
name: osint-registry-builder
description: deterministic public-source attribution workflow for Open Fireside discourse actor/account registry work.
---
# Purpose
Use this skill to perform deterministic, government-research-grade registry attribution in Open Fireside.

## Scope
- Registry contract work only.
- Public-source OSINT attribution only.
- No crawler/pipeline implementation.
- No incident/environment/map/UI work.

## Read first
1. `AGENTS.md`
2. `docs/methodology.md`
3. `docs/targeting-rules.md`
4. `docs/repo-truth-matrix.md`
5. `workers/discourse/registry/check_registry_quality.py`

## Canonical files
- `registry/master/actor_targets.csv`
- `registry/master/actor_account_targets.csv` (resolved URLs only)
- `registry/master/actor_account_discovery_queue.csv` (unresolved hypotheses only)
- `registry/master/actor_osint_evidence.csv` (attribution evidence path)
- `registry/master/public_communities.csv`
- `registry/master/discourse_sources.csv`
- `registry/master/verification_log.csv`

## Deterministic workflow
1. Start from one seed actor/org/person/community already in `actor_targets.csv` or `public_communities.csv`.
2. Identify the official/public anchor page:
   - official website root, official public profile page, or official institutional directory entry.
3. Resolve direct public surfaces from evidence:
   - website header/footer/about/contact/news/media links
   - official platform profile links clearly tied to the seed actor
4. Classify each candidate:
   - `resolved`: direct URL with attribution evidence
   - `discovery_needed`: plausible lead not yet attributable
5. Write tables strictly:
   - `actor_account_targets.csv`: resolved direct URLs only
   - `actor_account_discovery_queue.csv`: unresolved hypotheses/leads only
   - `actor_osint_evidence.csv`: evidence path for each resolved row
6. Normalize geography in actor updates:
   - `locality`, `province_state`, `country` quality in fields/notes
   - avoid province-only entries for local actors where locality is known
7. Handle public contact data:
   - allowed for public individuals, public institutions, municipalities/regional districts, ministries/agencies, DMOs, official programs
   - never include private-citizen identifiable contact info
8. Apply status discipline:
   - never mark unresolved leads as resolved
   - never leave platform-root URLs in resolved account rows
9. Record provenance:
   - each resolved account row must link to an evidence row via `evidence_id`
10. Run validation and stop at review-pack update.

## Hard rules
- Never invent handles.
- Never invent endpoints.
- Never claim attribution without a direct public URL or explicit public evidence path.
- Never move private-individual identifying information into registry outputs.

## Expected outputs
- Updated registry CSVs with strict resolved/discovery split.
- Updated evidence table with attribution metadata.
- Updated `verification_log.csv` notes for material contract/migration changes.
- Updated review pack under `reviews/discourse/D-G2/`.

## Validation
Run:
`python workers/discourse/registry/check_registry_quality.py registry/master/actor_targets.csv registry/master/actor_account_targets.csv registry/master/actor_account_discovery_queue.csv registry/master/actor_osint_evidence.csv registry/master/public_communities.csv registry/master/discourse_sources.csv`

## Stop condition
Stop after contract updates, migration, checker pass, and review-pack updates are complete.
