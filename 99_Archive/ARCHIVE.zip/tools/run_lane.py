#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]
LANES = ROOT / 'docs/autorun/lanes.yaml'


def main():
    ap = argparse.ArgumentParser(description='Update Open Fireside lane status')
    ap.add_argument('lane')
    ap.add_argument('--status')
    ap.add_argument('--gate')
    ap.add_argument('--approve', choices=['true','false'])
    ap.add_argument('--note')
    args = ap.parse_args()
    data = yaml.safe_load(LANES.read_text(encoding='utf-8'))
    lane = data['lanes'][args.lane]
    if args.status:
        lane['status'] = args.status
    if args.gate:
        lane['active_gate'] = args.gate
    if args.approve is not None:
        lane['approved'] = args.approve == 'true'
    if args.note:
        lane['notes'] = args.note
    LANES.write_text(yaml.safe_dump(data, sort_keys=False), encoding='utf-8')
    print(json.dumps(data['lanes'][args.lane], indent=2))


if __name__ == '__main__':
    main()
