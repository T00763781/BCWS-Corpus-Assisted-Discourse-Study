#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
required = [
    ROOT / 'AGENTS.md',
    ROOT / 'docs/repo-truth-matrix.md',
    ROOT / 'registry/master/incident_sources.csv',
    ROOT / 'workers/incidents/bcws/collect_bcws.py',
    ROOT / 'storage/db/migrations/001_init.sql',
]

missing = [str(p.relative_to(ROOT)) for p in required if not p.exists()]
pycache = [str(p.relative_to(ROOT)) for p in ROOT.rglob('__pycache__')]
pytest_cache = [str(p.relative_to(ROOT)) for p in ROOT.rglob('.pytest_cache')]
print(json.dumps({
    'missing_required': missing,
    'pycache_dirs': pycache,
    'pytest_cache_dirs': pytest_cache,
    'ok': not missing and not pycache and not pytest_cache,
}, indent=2))
