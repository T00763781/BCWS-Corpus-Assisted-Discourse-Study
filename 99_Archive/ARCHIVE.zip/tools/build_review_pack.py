#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def build_pack(lane: str, gate: str, summary: Path | None):
    pack = ROOT / 'reviews' / lane / gate
    pack.mkdir(parents=True, exist_ok=True)
    for sub in ['diagnostics', 'sample_raw', 'sample_db_queries', 'screenshots']:
        (pack / sub).mkdir(exist_ok=True)
    if summary:
        summary.parent.mkdir(parents=True, exist_ok=True)
        if not summary.exists():
            summary.write_text(f'# {lane} {gate} summary\n', encoding='utf-8')
        shutil.copy(summary, pack / 'summary.md')
    defaults = {
        'decision_request.md': '# Decision request\n\nState what is working, what is provisional, and what decision is needed.\n',
        'changed_files.txt': '',
        'feedback.md': 'Decision: revise\n',
    }
    for required_name, default_content in defaults.items():
        target = pack / required_name
        if not target.exists():
            target.write_text(default_content, encoding='utf-8')
    manifest = {
        'lane': lane,
        'gate': gate,
        'path': str(pack),
        'files': sorted(str(p.relative_to(pack)) for p in pack.rglob('*') if p.is_file())
    }
    (pack / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print(json.dumps(manifest))


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='Build Open Fireside review pack folder and manifest')
    ap.add_argument('lane')
    ap.add_argument('gate')
    ap.add_argument('--summary', default=None)
    args = ap.parse_args()
    build_pack(args.lane, args.gate, Path(args.summary) if args.summary else None)
