#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, datetime as dt, json, time
from pathlib import Path
from urllib.parse import urlparse

import requests

EXTRA_FIELDS = ['http_status','collectible','content_type_detected','sample_record_count','verification_notes']
STATUS_VALUES = {
    'ok':'verified_accessible',
    'empty':'verified_empty_but_valid',
    'blocked':'blocked_or_auth_required',
    'unreachable':'unreachable',
    'parse':'parse_failed',
    'manual':'manual_review_needed',
}


def now_iso():
    return dt.datetime.utcnow().replace(microsecond=0).isoformat() + 'Z'


def lightweight_get(url, timeout=20, retries=2):
    headers = {'User-Agent':'OpenFiresideVerifier/0.4 (+public-source research)'}
    last_err = None
    for attempt in range(retries + 1):
        try:
            return requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)
        except Exception as e:
            last_err = e
            time.sleep(0.2 * (attempt + 1))
    raise last_err


def verify_row(row):
    url = str(row.get('url_or_endpoint','')).strip()
    mode = str(row.get('verification_mode','html_page')).strip() or 'html_page'
    if not url and mode != 'manual_search_uri':
        return STATUS_VALUES['manual'], '', 'no', '', '', 'missing url'
    if mode == 'manual_search_uri':
        return STATUS_VALUES['manual'], '', 'discovery_needed', '', '', 'discovery query row; verify manually or with browser/agent'
    if mode == 'social_surface' and urlparse(url).netloc in {'x.com','www.facebook.com','www.instagram.com','www.tiktok.com','telegram.org'}:
        try:
            r = lightweight_get(url)
            status = STATUS_VALUES['ok'] if r.status_code < 400 else STATUS_VALUES['blocked']
            return status, str(r.status_code), 'maybe' if r.status_code < 400 else 'no', r.headers.get('content-type',''), '', 'surface reachable; heavy scraping not performed'
        except Exception as e:
            return STATUS_VALUES['unreachable'], '', 'no', '', '', str(e)
    try:
        r = lightweight_get(url)
        ctype = r.headers.get('content-type','')
        http_status = str(r.status_code)
        if r.status_code in (401,403):
            return STATUS_VALUES['blocked'], http_status, 'no', ctype, '', 'auth or permission blocked'
        if r.status_code >= 400:
            return STATUS_VALUES['unreachable'], http_status, 'no', ctype, '', 'http error'
        if mode in ('http_json','wp_api','arcgis_service','arcgis_query'):
            try:
                data = r.json()
                count = ''
                if isinstance(data, dict):
                    if 'error' in data:
                        return STATUS_VALUES['parse'], http_status, 'no', ctype or 'application/json', '', f"json error object: {data['error']}"
                    if 'features' in data:
                        if isinstance(data['features'], list):
                            count = str(len(data['features']))
                            if len(data['features']) == 0:
                                return STATUS_VALUES['empty'], http_status, 'yes', ctype or 'application/json', count, 'valid json, empty features'
                        elif data['features'] is None:
                            return STATUS_VALUES['empty'], http_status, 'yes', ctype or 'application/json', '0', 'valid json, features null'
                    elif 'collection' in data and isinstance(data['collection'], list):
                        count = str(len(data['collection']))
                        if len(data['collection']) == 0:
                            return STATUS_VALUES['empty'], http_status, 'yes', ctype or 'application/json', count, 'valid json, empty collection'
                return STATUS_VALUES['ok'], http_status, 'yes', ctype or 'application/json', count, 'json parse successful'
            except Exception as e:
                return STATUS_VALUES['parse'], http_status, 'maybe', ctype, '', f'json parse failed: {e}'
        text = r.text[:5000].lower()
        if '<html' in text or '<!doctype html' in text or 'wordpress' in text:
            return STATUS_VALUES['ok'], http_status, 'yes', ctype or 'text/html', '', 'html-like response'
        return STATUS_VALUES['ok'], http_status, 'maybe', ctype, '', 'reachable but atypical response type'
    except Exception as e:
        return STATUS_VALUES['unreachable'], '', 'no', '', '', str(e)


def update_csv(path: Path):
    with path.open('r', encoding='utf-8', newline='') as f:
        rows = list(csv.DictReader(f))
        if not rows:
            print(f'skipped empty {path}')
            return {'updated': str(path), 'rows': 0}
        fields = list(rows[0].keys())
    for extra in EXTRA_FIELDS:
        if extra not in fields:
            fields.append(extra)
    for row in rows:
        status, http_status, collectible, ctype, sample_count, notes = verify_row(row)
        row['verification_status'] = status
        row['last_verified_utc'] = now_iso()
        row['http_status'] = http_status
        row['collectible'] = collectible
        row['content_type_detected'] = ctype
        row['sample_record_count'] = sample_count
        row['verification_notes'] = notes
    with path.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    result = {'updated': str(path), 'rows': len(rows)}
    print(json.dumps(result))
    return result


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='Verify Open Fireside target CSVs in place')
    ap.add_argument('paths', nargs='+')
    args = ap.parse_args()
    for p in args.paths:
        update_csv(Path(p))
