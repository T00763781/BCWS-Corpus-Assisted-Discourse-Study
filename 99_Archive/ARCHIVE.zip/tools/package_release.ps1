$ErrorActionPreference = 'Stop'
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$out = Join-Path "dist/staging" "open_fireside_dev_bundle_$stamp"
New-Item -ItemType Directory -Force -Path $out | Out-Null
Copy-Item README.md -Destination $out
Copy-Item AGENTS.md -Destination $out
Copy-Item registry -Destination $out -Recurse
Copy-Item docs -Destination $out -Recurse
Write-Host "Created development bundle at $out"
