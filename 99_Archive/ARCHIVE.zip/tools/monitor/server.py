"""
Lightweight local monitor for Open Fireside development progress.

Serves a small HTML/JS dashboard that polls canonical files at regular intervals.
All file access is read-only, and no registry or app files are modified.
"""

from collections import defaultdict, deque
from datetime import datetime
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import argparse
import csv
import json
import os
import threading

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "tools" / "monitor" / "static"

LOG_PATH = Path("logs/repo-hygiene/run.log")
ORCHESTRATION_PATH = Path("registry/ops/universe_registry_orchestration.yaml")
FIRE_CENTRE_WAVE_PATH = Path(
    "reviews/discourse/D-G2/diagnostics/fire_centre_wave_sizing.csv"
)
MUNICIPALITIES_MISSING_PATH = Path(
    "reviews/discourse/D-G2/diagnostics/municipalities_missing_from_seed.csv"
)
MUNICIPALITY_UNIVERSE_PATH = Path(
    "reviews/discourse/D-G2/diagnostics/municipality_universe_table.csv"
)
ACTOR_TARGETS_PATH = Path("registry/master/actor_targets.csv")
ACTOR_ACCOUNT_TARGETS_PATH = Path("registry/master/actor_account_targets.csv")
ACTOR_ACCOUNT_DISCOVERY_PATH = Path(
    "registry/master/actor_account_discovery_queue.csv"
)
ACTOR_EVIDENCE_PATH = Path("registry/master/actor_osint_evidence.csv")
PUBLIC_COMMUNITIES_PATH = Path("registry/master/public_communities.csv")
DISCOURSE_SOURCES_PATH = Path("registry/master/discourse_sources.csv")
VERIFICATION_LOG_PATH = Path("registry/master/verification_log.csv")

CANONICAL_INPUTS = [
    LOG_PATH,
    ORCHESTRATION_PATH,
    FIRE_CENTRE_WAVE_PATH,
    MUNICIPALITIES_MISSING_PATH,
    MUNICIPALITY_UNIVERSE_PATH,
    ACTOR_TARGETS_PATH,
    ACTOR_ACCOUNT_TARGETS_PATH,
    ACTOR_ACCOUNT_DISCOVERY_PATH,
    ACTOR_EVIDENCE_PATH,
    PUBLIC_COMMUNITIES_PATH,
    DISCOURSE_SOURCES_PATH,
    VERIFICATION_LOG_PATH,
    DIAGNOSTIC_DIR,
]

DIAGNOSTIC_DIR = BASE_DIR / "reviews" / "discourse" / "D-G2" / "diagnostics"
LOG_TAIL_LINES = 20
MUNICIPALITY_CATEGORIES = [
    ("below 3", lambda count: count < 3),
    ("below 8", lambda count: 3 <= count < 8),
    ("below 12", lambda count: 8 <= count < 12),
    ("at or above 20", lambda count: count >= 20),
]


def tail_lines(path: Path, limit=LOG_TAIL_LINES):
    """Return the last *limit* lines from the given file."""
    if not path.exists():
        return []
    buffer = deque(maxlen=limit)
    with path.open("r", encoding="utf-8", errors="ignore") as fh:
        for line in fh:
            buffer.append(line.rstrip("\n"))
    return list(buffer)


def count_csv_rows(path: Path):
    if not path.exists():
        return 0
    with path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.reader(fh)
        row_count = sum(1 for _ in reader)
    return max(row_count - 1, 0)


def read_verification_events(path: Path, limit=6):
    if not path.exists():
        return []
    rows = []
    with path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            rows.append(row)
    if not rows:
        return []
    # keep the last *limit* rows
    selected = rows[-limit:]
    events = []
    for row in selected:
        events.append(
            {
                "object_table": row.get("object_table"),
                "object_id": row.get("object_id"),
                "status": row.get("verification_status"),
                "timestamp": row.get("last_verified_utc") or "",
                "notes": row.get("notes") or "",
            }
        )
    return events


def parse_work_packets(path: Path):
    """Ad hoc YAML parser that extracts packet_id, owner_agent, and status."""
    if not path.exists():
        return [], {}
    packets = []
    fire_centre_map = {}
    current_packet = None
    current_fire_centre = {}
    section = None
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            if stripped == "fire_centres:":
                section = "fire_centres"
                continue
            if stripped == "work_packets:":
                section = "work_packets"
                continue
            if section == "fire_centres":
                if stripped.startswith("- fire_centre:"):
                    current_fire_centre = {
                        "fire_centre": stripped.split(":", 1)[1].strip()
                    }
                    packets_name = current_fire_centre["fire_centre"]
                    fire_centre_map[current_fire_centre.get("code")] = packets_name
                elif stripped.startswith("code:") and current_fire_centre:
                    current_fire_centre["code"] = stripped.split(":", 1)[1].strip()
                    fire_centre_map[
                        current_fire_centre["code"]
                    ] = current_fire_centre["fire_centre"]
            elif section == "work_packets":
                if stripped.startswith("- packet_id:"):
                    if current_packet:
                        packets.append(current_packet)
                    current_packet = {
                        "packet_id": stripped.split(":", 1)[1].strip()
                    }
                    continue
                if stripped.startswith("-"):
                    continue
                if current_packet and ":" in stripped:
                    key, value = stripped.split(":", 1)
                    current_packet[key.strip()] = value.strip()
        if current_packet:
            packets.append(current_packet)
    return packets, fire_centre_map


def parse_fire_centre_counts(path: Path):
    counts = {}
    if not path.exists():
        return counts
    with path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            try:
                counts[row.get("fire_centre")] = int(row.get("municipality_count") or 0)
            except ValueError:
                counts[row.get("fire_centre")] = 0
    return counts


def parse_missing_municipalities(path: Path):
    blockers = defaultdict(list)
    if not path.exists():
        return blockers
    with path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            fc = row.get("fire_centre_assignment") or "unknown"
            name = row.get("municipality_name") or "unknown"
            blockers[fc].append(name)
    return blockers


def load_municipality_mapping(path: Path):
    mapping = {}
    normalized_lookup = {}
    if not path.exists():
        return mapping, normalized_lookup
    with path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            city = row.get("municipality_name")
            if not city:
                continue
            fc = row.get("fire_centre_assignment") or "unknown"
            normalized = normalize_text(city)
            mapping[city] = fc
            normalized_lookup[normalized] = city
    return mapping, normalized_lookup


def normalize_text(value: str):
    if not value:
        return ""
    value = value.lower()
    for prefix in (
        "city of ",
        "regional district of ",
        "district of ",
        "town of ",
        "village of ",
        "district municipality of ",
        "first nation of ",
    ):
        if value.startswith(prefix):
            value = value[len(prefix) :]
    return value.replace(".", "").replace("'", "").strip()


def compute_municipality_completion(actor_path: Path, universe_path: Path):
    if not actor_path.exists() or not universe_path.exists():
        return {}
    mapping, normalized_lookup = load_municipality_mapping(universe_path)
    counts = defaultdict(int)
    with actor_path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            geography = row.get("geography", "").strip()
            if not geography:
                continue
            candidate = match_municipality(geography, normalized_lookup)
            if not candidate:
                continue
            counts[candidate] += 1
    bucketed = defaultdict(lambda: defaultdict(list))
    for municipality, total in counts.items():
        fire_centre = mapping.get(municipality, "unknown")
        assigned = False
        for label, predicate in MUNICIPALITY_CATEGORIES:
            if predicate(total):
                bucketed[fire_centre][label].append(
                    {"name": municipality, "count": total}
                )
                assigned = True
                break
        if not assigned:
            bucketed[fire_centre]["others"].append(
                {"name": municipality, "count": total}
            )
    return bucketed


def match_municipality(geography: str, normalized_lookup: dict):
    normalized_geo = normalize_text(geography)
    if not normalized_geo:
        return None
    if normalized_geo in normalized_lookup:
        return normalized_lookup[normalized_geo]
    for norm_key, municipality in normalized_lookup.items():
        if norm_key in normalized_geo or normalized_geo in norm_key:
            return municipality
    return None


def get_recent_files(paths):
    hits = []
    for path in paths:
        if path.is_dir():
            for child in path.glob("*.csv"):
                hits.append(child)
            continue
        if path.exists():
            hits.append(path)
    records = []
    for path in hits:
        try:
            records.append(
                {
                    "path": str(path),
                    "modified": datetime.fromtimestamp(path.stat().st_mtime).isoformat(),
                }
            )
        except OSError:
            continue
    records.sort(key=lambda entry: entry["modified"], reverse=True)
    return records[:6]


def format_status(status: str):
    if not status:
        return "unknown"
    return status.lower().replace(" ", "_")


def gather_status():
    ticker = {
        "log_tail": tail_lines(BASE_DIR / CANONICAL_INPUTS[0]),
        "validation_events": read_verification_events(BASE_DIR / CANONICAL_INPUTS[-1], limit=5),
        "packet_changes": [],
    }
    packets, fire_centre_map = parse_work_packets(BASE_DIR / CANONICAL_INPUTS[1])
    packet_counts = parse_fire_centre_counts(BASE_DIR / CANONICAL_INPUTS[2])
    blockers = parse_missing_municipalities(BASE_DIR / CANONICAL_INPUTS[3])
    completion_summary = compute_municipality_completion(
        BASE_DIR / CANONICAL_INPUTS[5], BASE_DIR / CANONICAL_INPUTS[4]
    )
    packet_list = []
    for packet in packets:
        packet_id = packet.get("packet_id") or "unknown"
        code = packet_id.split("_", 1)[0]
        fire_centre = fire_centre_map.get(code) or "unknown"
        packet_entry = {
            "fire_centre": fire_centre,
            "packet_id": packet_id,
            "owner_agent": packet.get("owner_agent") or "unknown",
            "status": packet.get("status") or "unknown",
            "municipality_count": packet_counts.get(fire_centre, 0),
            "blockers": blockers.get(fire_centre, [])[:4],
        }
        packet_list.append(packet_entry)
        ticker["packet_changes"].append(
            {
                "packet_id": packet_entry["packet_id"],
                "status": packet_entry["status"],
                "fire_centre": fire_centre,
            }
        )
    ticker["packet_changes"] = ticker["packet_changes"][-6:]
    totals = {
        "actor_count": count_csv_rows(BASE_DIR / CANONICAL_INPUTS[5]),
        "resolved_account_count": count_csv_rows(BASE_DIR / CANONICAL_INPUTS[6]),
        "discovery_count": count_csv_rows(BASE_DIR / CANONICAL_INPUTS[7]),
        "evidence_count": count_csv_rows(BASE_DIR / CANONICAL_INPUTS[8]),
        "discourse_sources": count_csv_rows(BASE_DIR / CANONICAL_INPUTS[10]),
        "public_communities": count_csv_rows(BASE_DIR / CANONICAL_INPUTS[9]),
    }
    validation_events = read_verification_events(BASE_DIR / CANONICAL_INPUTS[-1], limit=1)
    latest_validation = validation_events[-1] if validation_events else {}
    validation_summary = {
        "latest_checker": latest_validation,
        "issue_count": len(blockers),
        "timestamp": latest_validation.get("timestamp") or datetime.utcnow().isoformat(),
    }
    recent_activity = get_recent_files(CANONICAL_INPUTS[:])
    return {
        "ticker": ticker,
        "packets": packet_list,
        "registry_totals": totals,
        "municipality_completion": completion_summary,
        "validation_summary": validation_summary,
        "recent_files": recent_activity,
    }


class MonitorHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC_DIR), **kwargs)

    def do_GET(self):
        if self.path.startswith("/api/status"):
            try:
                payload = gather_status()
                body = json.dumps(payload).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)
            except Exception as exc:  # pragma: no cover - best effort
                self.send_response(500)
                self.send_header("Content-Type", "text/plain")
                self.end_headers()
                self.wfile.write(str(exc).encode("utf-8"))
            return
        super().do_GET()


def run_server(host: str, port: int):
    server = ThreadingHTTPServer((host, port), MonitorHandler)
    print(f"Monitor running on http://{host}:{port} (read-only)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()
        server.server_close()


def main():
    parser = argparse.ArgumentParser(
        description="Run the Open Fireside read-only development monitor."
    )
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind the monitor server.")
    parser.add_argument(
        "--port", type=int, default=8888, help="Port for the monitor server."
    )
    args = parser.parse_args()
    run_server(args.host, args.port)


if __name__ == "__main__":
    main()
