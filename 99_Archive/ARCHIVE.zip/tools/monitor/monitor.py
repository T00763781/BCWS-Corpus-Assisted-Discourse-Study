import os
import glob
import pandas as pd
import streamlit as st
import yaml
from datetime import datetime
from streamlit_autorefresh import st_autorefresh

st.set_page_config(page_title='Open Fireside Monitor', layout='wide')
st_autorefresh(interval=5000, key='monitor_autorefresh')

CANONICAL_FILES = {
    'run_log': 'logs/repo-hygiene/run.log',
    'orchestration': 'registry/ops/universe_registry_orchestration.yaml',
    'actor_targets': 'registry/master/actor_targets.csv',
    'actor_accounts': 'registry/master/actor_account_targets.csv',
    'discovery': 'registry/master/actor_account_discovery_queue.csv',
    'evidence': 'registry/master/actor_osint_evidence.csv',
    'public_comm': 'registry/master/public_communities.csv',
    'sources': 'registry/master/discourse_sources.csv',
    'verification': 'registry/master/verification_log.csv',
}

FIRE_CENTRE_DIR = 'registry/seed/fire_centre_directories'

@st.cache_data(ttl=5)
def tail_text(path, lines=5):
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            all_lines = f.readlines()
    except FileNotFoundError:
        return [f'file not found: {path}']
    return all_lines[-lines:]

@st.cache_data(ttl=5)
def read_yaml(path):
    if not os.path.exists(path):
        return {}
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

@st.cache_data(ttl=5)
def read_csv(path):
    if not os.path.exists(path):
        return pd.DataFrame()
    try:
        return pd.read_csv(path)
    except Exception:
        return pd.DataFrame()

@st.cache_data(ttl=5)
def packet_status_orchestration():
    data = read_yaml(CANONICAL_FILES['orchestration'])
    packets = data.get('work_packets', [])
    rows = []
    for p in packets:
        rows.append({
            'fire_centre': p.get('owner_agent', '').replace('_fire_centre_agent', '').replace('_', ' ').title(),
            'packet_id': p.get('packet_id'),
            'owner_agent': p.get('owner_agent'),
            'status': p.get('status'),
            'scope_files': '\n'.join(p.get('scope_files', [])),
        })
    return pd.DataFrame(rows)

@st.cache_data(ttl=5)
def fire_centre_municipality_counts():
    data = []
    for fc_dir in glob.glob(os.path.join(FIRE_CENTRE_DIR, '*')):
        fc_name = os.path.basename(fc_dir)
        localities = glob.glob(os.path.join(fc_dir, 'localities.csv'))
        if not localities:
            continue
        df = read_csv(localities[0])
        data.append({'fire_centre_code': fc_name, 'municipalities': len(df)})
    return pd.DataFrame(data)

@st.cache_data(ttl=5)
def read_verification_summary():
    df = read_csv(CANONICAL_FILES['verification'])
    if df.empty:
        return None
    latest = df.iloc[-1]
    return {
        'timestamp': latest.get('last_verified_utc', latest.get('verification_timestamp', 'unknown')),
        'issue_count': latest.get('issue_count', 'N/A'),
        'details': latest.to_dict(),
    }

@st.cache_data(ttl=5)
def registry_totals():
    def row_count(path):
        if not os.path.exists(path):
            return 0
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            return sum(1 for _ in f) - 1
    return {
        'actors': row_count(CANONICAL_FILES['actor_targets']),
        'accounts': row_count(CANONICAL_FILES['actor_accounts']),
        'discovery': row_count(CANONICAL_FILES['discovery']),
        'evidence': row_count(CANONICAL_FILES['evidence']),
        'sources': row_count(CANONICAL_FILES['sources']),
        'public_communities': row_count(CANONICAL_FILES['public_comm']),
    }

@st.cache_data(ttl=5)
def municipality_completion():
    df = read_csv(CANONICAL_FILES['actor_targets'])
    if df.empty:
        return {}
    seeds = read_csv('registry/seed/municipality_directory_seed.csv') if os.path.exists('registry/seed/municipality_directory_seed.csv') else pd.DataFrame()
    seed_map = {row['locality_name']: row['fire_centre'] for _, row in seeds.iterrows()} if not seeds.empty else {}
    counts = {}
    for _, row in df.iterrows():
        geography = str(row.get('geography', '')).split(',')[0].strip()
        if not geography:
            continue
        counts[geography] = counts.get(geography, 0) + 1
    summary = {}
    for municipality, count in counts.items():
        fc = seed_map.get(municipality, 'unknown').title()
        entry = summary.setdefault(fc, {'<3': 0, '<8': 0, '<12': 0, '>=20': 0})
        if count < 3:
            entry['<3'] += 1
        if count < 8:
            entry['<8'] += 1
        if count < 12:
            entry['<12'] += 1
        if count >= 20:
            entry['>=20'] += 1
    return summary

@st.cache_data(ttl=5)
def recent_file_activity():
    rows = []
    for path in CANONICAL_FILES.values():
        if os.path.exists(path):
            stat = os.stat(path)
            rows.append({'file': path, 'mtime': datetime.fromtimestamp(stat.st_mtime).isoformat()})
    rows.sort(key=lambda x: x['mtime'], reverse=True)
    return rows[:6]

st.title('Open Fireside Development Monitor')
st.caption('Read-only status dashboard. Auto-refreshes every few seconds.')

st.markdown('### Live ticker')
col1, col2 = st.columns([2, 1])
with col1:
    st.subheader('Run log tail')
    for line in tail_text(CANONICAL_FILES['run_log'], 5):
        st.text(line.strip())
with col2:
    st.subheader('Latest validation')
    validation = read_verification_summary()
    if validation:
        st.metric('Issue count', validation['issue_count'])
        st.write(validation['timestamp'])
    else:
        st.write('No data yet')

st.markdown('### Packet status')
packets = packet_status_orchestration()
counts = fire_centre_municipality_counts()
if packets.empty:
    st.write('No packets defined yet.')
else:
    df = packets.merge(counts, left_on='fire_centre', right_on='fire_centre_code', how='left')
    df_display = df[['fire_centre', 'packet_id', 'owner_agent', 'status', 'municipalities']]
    st.dataframe(df_display)

st.markdown('### Registry totals')
totals = registry_totals()
cols = st.columns(6)
for idx, (label, value) in enumerate(totals.items()):
    cols[idx].metric(label.replace('_', ' ').title(), value)

st.markdown('### Municipality completion summary')
summary = municipality_completion()
if not summary:
    st.write('No municipality coverage yet.')
else:
    for fc, values in summary.items():
        st.write(f'{fc}: <3={values["<3"]}, <8={values["<8"]}, <12={values["<12"]}, >=20={values[">=20"]}')

st.markdown('### Validation summary details')
if validation:
    st.write(validation['details'])
else:
    st.write('Validation log empty.')

st.markdown('### Recent canonical file activity')
for entry in recent_file_activity():
    st.write(f"{entry['mtime']} � {entry['file']}")

st.markdown('### Notes')
st.write('Monitor reads canonical logs and registry CSVs only. No files are modified.')
