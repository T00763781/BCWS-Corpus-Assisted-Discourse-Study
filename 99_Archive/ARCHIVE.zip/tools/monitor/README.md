# Local Development Monitor

This Streamlit app provides a read-only dashboard for Open Fireside registry progress.

## Run Instructions
1. Ensure dependencies are installed:
   ```bash
   pip install streamlit pandas pyyaml streamlit-autorefresh
   ```
2. From the repository root, run:
   ```bash
   streamlit run tools/monitor/monitor.py
   ```
3. The UI polls every ~5 seconds and shows the tail of the run log, packet statuses, registry totals, municipality completion counts, validation data, and recent file activity.

## Files read
- `logs/repo-hygiene/run.log`
- `registry/ops/universe_registry_orchestration.yaml`
- `registry/master/actor_targets.csv`
- `registry/master/actor_account_targets.csv`
- `registry/master/actor_account_discovery_queue.csv`
- `registry/master/actor_osint_evidence.csv`
- `registry/master/public_communities.csv`
- `registry/master/discourse_sources.csv`
- `registry/master/verification_log.csv`
- `registry/seed/fire_centre_directories/*/localities.csv`

## Write discipline
- The monitor only reads files; it writes nothing in the repo.
- No registry master or ops files are modified.
