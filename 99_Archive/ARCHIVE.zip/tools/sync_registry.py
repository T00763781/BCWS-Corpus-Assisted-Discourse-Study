#!/usr/bin/env python3
from __future__ import annotations
import argparse, shutil
from pathlib import Path


def main():
    ap = argparse.ArgumentParser(description='Copy canonical registry CSVs to a snapshot folder')
    ap.add_argument('--dest', required=True)
    args = ap.parse_args()
    src = Path('registry/master')
    dest = Path(args.dest)
    dest.mkdir(parents=True, exist_ok=True)
    for csv_path in src.glob('*.csv'):
        shutil.copy(csv_path, dest / csv_path.name)
        print(f'copied {csv_path} -> {dest / csv_path.name}')


if __name__ == '__main__':
    main()
