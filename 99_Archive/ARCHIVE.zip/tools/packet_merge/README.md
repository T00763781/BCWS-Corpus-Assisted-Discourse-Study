# Municipality Packet Merge Kit � 100 Mile House

## Overview
This packet kit captures the empty actor/account/evidence templates and scaffolds everything needed to append a Cariboo / 100 Mile House municipality packet into the canonical registry tables. The merge script enforces the resolved/discovery/evidence contract and updates the completion table.

## Steps
1. **Populate the templates**
   - `reviews/discourse/D-G2/diagnostics/100mile_house_actor_packet_template.csv`: fill one row per actor. Keep Cariboo fire_centre, locality-grade geography, and the required actor slots listed in the checklist. Replace `TODO-*` placeholders with real IDs.
   - `reviews/discourse/D-G2/diagnostics/100mile_house_account_packet_template.csv`: add resolved account rows (linkable to evidence) under the `# Resolved accounts` section and discovery leads (if any) under the `# Discovery leads` section. Do not mix resolved/discovery rows. Provide unique IDs and platform-specific URLs (no platform-root entries).
   - `reviews/discourse/D-G2/diagnostics/100mile_house_evidence_packet_template.csv`: add a row per resolved account with evidence metadata (evidence_id, actor_id, account_target_id, evidence URLs, strength, last_verified UTC).
   - `reviews/discourse/D-G2/diagnostics/100mile_house_completion_row_template.csv`: update the placeholder row with the final counts, boolean flags, resolution status, blocker notes, and timestamp.

2. **Run the merge script**
   ```bash
   python tools/packet_merge/merge_municipality_packet.py \
     --actor-packet reviews/discourse/D-G2/diagnostics/100mile_house_actor_packet_template.csv \
     --account-packet reviews/discourse/D-G2/diagnostics/100mile_house_account_packet_template.csv \
     --discovery-packet reviews/discourse/D-G2/diagnostics/100mile_house_account_packet_template.csv \
     --evidence-packet reviews/discourse/D-G2/diagnostics/100mile_house_evidence_packet_template.csv \
     --completion-row reviews/discourse/D-G2/diagnostics/100mile_house_completion_row_template.csv
   ```
   The script appends rows to the canonical registry tables and updates the completion table. It refuses duplicate IDs, platform-root URLs, and resolved accounts without evidence.

3. **Validation**
   After the merge, run the canonical checker:
   ```bash
   python workers/discourse/registry/check_registry_quality.py registry/master/actor_targets.csv registry/master/actor_account_targets.csv registry/master/actor_account_discovery_queue.csv registry/master/actor_osint_evidence.csv registry/master/public_communities.csv registry/master/discourse_sources.csv
   ```
   Include the exit code and issue counts in the review report.

## What files are read / not modified
The merge script reads the canonical registry CSVs and the packet templates but does not modify the templates themselves. It writes only to the canonical targets/evidence tables and the completion table; it leaves `registry/ops`, `app`, and the rest of the repo untouched.
