import argparse
import logging
import os
from datetime import datetime

import pandas as pd

CANONICAL_PATHS = {
    'actors': 'registry/master/actor_targets.csv',
    'accounts': 'registry/master/actor_account_targets.csv',
    'discovery': 'registry/master/actor_account_discovery_queue.csv',
    'evidence': 'registry/master/actor_osint_evidence.csv',
    'completion': 'reviews/discourse/D-G2/diagnostics/cariboo_completion_table.csv',
}
PLATFORM_ROOTS = {
    'facebook': 'facebook.com',
    'x': 'x.com',
    'instagram': 'instagram.com',
    'youtube': 'youtube.com',
    'linkedin': 'linkedin.com',
    'tiktok': 'tiktok.com',
}

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
logger = logging.getLogger('packet-merge')


def read_csv(path):
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        return pd.DataFrame()
    return pd.read_csv(path, dtype=str)


def append_df(path, df, key_column=None):
    existing = read_csv(path)
    if key_column and key_column in df.columns and key_column in existing.columns:
        dupes = set(existing[key_column]).intersection(df[key_column])
        if dupes:
            raise ValueError(f'Duplicate keys detected for {key_column}: {dupes}')
    need_header = not os.path.exists(path) or os.path.getsize(path) == 0
    df.to_csv(path, mode='a', index=False, header=need_header)
    logger.info('Appended %d rows to %s', len(df), path)


def is_platform_root(url, platform):
    if not isinstance(url, str) or not url:
        return False
    root = PLATFORM_ROOTS.get(platform.lower())
    if not root:
        return False
    norm = url.strip().lower().rstrip('/')
    return norm in {root, f'http://{root}', f'https://{root}'}


def validate_actor_rows(df):
    required_columns = ['target_id', 'target_name', 'geography', 'fire_centre', 'role_title']
    missing = [c for c in required_columns if c not in df.columns]
    if missing:
        raise ValueError(f'Missing actor columns: {missing}')


def validate_accounts(resolved_df, evidence_df):
    required_columns = ['account_target_id', 'parent_target_id', 'platform', 'target_url_or_surface', 'evidence_id']
    missing = [c for c in required_columns if c not in resolved_df.columns]
    if missing:
        raise ValueError(f'Missing account columns: {missing}')
    if resolved_df['target_url_or_surface'].isnull().any():
        raise ValueError('Resolved accounts must list a target_url_or_surface')
    missing_evidence = set(resolved_df['evidence_id']) - set(evidence_df['evidence_id'])
    if missing_evidence:
        raise ValueError(f'Resolved accounts refer to missing evidence_id(s): {missing_evidence}')
    for _, row in resolved_df.iterrows():
        if is_platform_root(row['target_url_or_surface'], row['platform']):
            raise ValueError(f'Platform-root URL is not allowed: {row["target_url_or_surface"]}')


def validate_discovery(df):
    required_columns = ['discovery_id', 'parent_target_id', 'candidate_url_or_handle']
    missing = [c for c in required_columns if c not in df.columns]
    if missing:
        raise ValueError(f'Missing discovery columns: {missing}')


def validate_evidence(df):
    required_columns = ['evidence_id', 'actor_id', 'account_target_id', 'platform', 'resolved_url']
    missing = [c for c in required_columns if c not in df.columns]
    if missing:
        raise ValueError(f'Missing evidence columns: {missing}')


def update_completion_table(path, template_df):
    existing = read_csv(path)
    if 'municipality_name' not in template_df.columns:
        raise ValueError('Completion template must include municipality_name column')
    municipality = template_df.iloc[0]['municipality_name']
    if not municipality:
        raise ValueError('municipality_name cannot be empty')
    filtered = existing[existing['municipality_name'] != municipality] if not existing.empty else pd.DataFrame()
    merged = pd.concat([filtered, template_df], ignore_index=True)
    merged.to_csv(path, index=False)
    logger.info('Updated completion table %s for %s', path, municipality)


def main():
    parser = argparse.ArgumentParser(description='Merge municipality packet into canonical registry tables')
    parser.add_argument('--actor-packet', required=True, help='CSV file with actor_targets rows')
    parser.add_argument('--account-packet', required=True, help='CSV file with actor_account_targets rows')
    parser.add_argument('--discovery-packet', required=True, help='CSV file with actor_account_discovery_queue rows')
    parser.add_argument('--evidence-packet', required=True, help='CSV file with actor_osint_evidence rows')
    parser.add_argument('--completion-row', required=True, help='CSV file with completion row for cariboo table')
    args = parser.parse_args()

    actor_df = read_csv(args.actor_packet)
    account_df = read_csv(args.account_packet)
    discovery_df = read_csv(args.discovery_packet)
    evidence_df = read_csv(args.evidence_packet)
    completion_df = read_csv(args.completion_row)

    for label, df in [('actors', actor_df), ('accounts', account_df), ('discovery', discovery_df), ('evidence', evidence_df)]:
        if df.empty:
            raise ValueError(f'{label} packet {getattr(args, f"{label}_packet") if label != "accounts" else args.account_packet} is empty')

    validate_actor_rows(actor_df)
    validate_accounts(account_df, evidence_df)
    validate_discovery(discovery_df)
    validate_evidence(evidence_df)
    if completion_df.empty:
        raise ValueError('Completion row template is empty')

    append_df(CANONICAL_PATHS['actors'], actor_df, key_column='target_id')
    append_df(CANONICAL_PATHS['accounts'], account_df, key_column='account_target_id')
    append_df(CANONICAL_PATHS['discovery'], discovery_df, key_column='discovery_id')
    append_df(CANONICAL_PATHS['evidence'], evidence_df, key_column='evidence_id')

    update_completion_table(CANONICAL_PATHS['completion'], completion_df)

    logger.info('Packet merge completed successfully at %s', datetime.utcnow().isoformat() + 'Z')

if __name__ == '__main__':
    main()
