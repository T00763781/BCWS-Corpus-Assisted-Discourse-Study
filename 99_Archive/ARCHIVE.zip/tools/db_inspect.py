#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, sqlite3, sys
from pathlib import Path


def main():
    ap = argparse.ArgumentParser(description='Inspect SQLite with query output options')
    ap.add_argument('db')
    ap.add_argument('--query', required=True)
    ap.add_argument('--format', choices=['table', 'json', 'csv'], default='json')
    args = ap.parse_args()
    conn = sqlite3.connect(args.db)
    cur = conn.execute(args.query)
    cols = [d[0] for d in cur.description]
    rows = [dict(zip(cols, row)) for row in cur.fetchall()]
    if args.format == 'json':
        print(json.dumps(rows, indent=2, ensure_ascii=False))
    elif args.format == 'csv':
        writer = csv.DictWriter(sys.stdout, fieldnames=cols)
        writer.writeheader()
        writer.writerows(rows)
    else:
        print(' | '.join(cols))
        for row in rows:
            print(' | '.join(str(row[c]) for c in cols))


if __name__ == '__main__':
    main()
