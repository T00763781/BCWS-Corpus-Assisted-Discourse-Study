#!/usr/bin/env python3
"""Export DB registry tables into CSV snapshots.

Default output is `registry/snapshots/<run_id>/` to avoid rewriting active CSVs.
Supports exporting from canonical tables or staging tables.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import sqlite3
from pathlib import Path

TABLE_EXPORT_MAP = {
    "actors": "actor_targets.csv",
    "actor_accounts": "actor_account_targets.csv",
    "actor_evidence": "actor_osint_evidence.csv",
    "discovery_leads": "actor_account_discovery_queue.csv",
    "discourse_sources": "discourse_sources.csv",
    "public_communities": "public_communities.csv",
    "municipalities": "municipalities.csv",
    "fire_centres": "fire_centres.csv",
    "monitoring_subscriptions": "monitoring_subscriptions.csv",
}



def make_run_id(prefix: str) -> str:
    stamp = dt.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    return f"{prefix}_{stamp}"



def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Export DB registry tables to CSV snapshot files.")
    parser.add_argument("--db", required=True, help="SQLite database path.")
    parser.add_argument("--output-dir", default=None, help="Optional output directory.")
    parser.add_argument("--use-staging", action="store_true", help="Export from staging_* tables.")
    parser.add_argument(
        "--tables",
        nargs="*",
        default=None,
        help="Optional subset of canonical table keys to export (e.g. actors actor_accounts actor_evidence).",
    )
    return parser.parse_args()



def export_table(conn: sqlite3.Connection, table_name: str, output_path: Path) -> int:
    cursor = conn.execute(f"SELECT * FROM {table_name}")
    cols = [desc[0] for desc in cursor.description]
    rows = cursor.fetchall()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(cols)
        writer.writerows(rows)
    return len(rows)



def main() -> int:
    args = parse_args()
    run_id = make_run_id("export_registry")
    db_path = Path(args.db)
    if not db_path.exists():
        print(json.dumps({"run_id": run_id, "error": f"database does not exist: {db_path}"}, indent=2))
        return 1

    output_dir = Path(args.output_dir) if args.output_dir else Path("registry/snapshots") / run_id
    output_dir.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    existing_tables = {
        row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
    }

    selected_keys = args.tables if args.tables else list(TABLE_EXPORT_MAP.keys())
    manifest = {
        "run_id": run_id,
        "db_path": str(db_path),
        "output_dir": str(output_dir),
        "use_staging": bool(args.use_staging),
        "exports": [],
    }

    for table_key in selected_keys:
        file_name = TABLE_EXPORT_MAP.get(table_key)
        if not file_name:
            manifest["exports"].append({"table_key": table_key, "status": "unknown_table_key"})
            continue

        source_table = f"staging_{table_key}" if args.use_staging else table_key
        if source_table not in existing_tables:
            manifest["exports"].append({"table_key": table_key, "source_table": source_table, "status": "missing"})
            continue

        row_count = export_table(conn, source_table, output_dir / file_name)
        manifest["exports"].append(
            {
                "table_key": table_key,
                "source_table": source_table,
                "file": file_name,
                "row_count": row_count,
                "status": "ok",
            }
        )

    conn.close()
    manifest_path = output_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({"run_id": run_id, "manifest": str(manifest_path)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
