#!/usr/bin/env python3
"""Score municipality completion from DB counts.

Supports canonical tables or staging tables and emits machine-readable diagnostics.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import sqlite3
from pathlib import Path



def make_run_id(prefix: str) -> str:
    stamp = dt.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    return f"{prefix}_{stamp}"



def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Score municipality completion from DB-backed registry data.")
    parser.add_argument("--db", required=True, help="SQLite database path.")
    parser.add_argument("--output-dir", default="logs/diagnostics", help="Diagnostics output directory.")
    parser.add_argument("--use-staging", action="store_true", help="Score from staging_* tables.")
    parser.add_argument("--fire-centre", default=None, help="Optional fire centre filter (e.g. Cariboo).")
    return parser.parse_args()



def _score(actor_count: int, resolved_count: int, non_web_count: int, distinct_platforms: int) -> tuple[int, str, list[str]]:
    score = 0
    blockers: list[str] = []
    if actor_count >= 12:
        score += 1
    else:
        blockers.append("actor_count_below_12")
    if resolved_count >= 20:
        score += 1
    else:
        blockers.append("resolved_account_count_below_20")
    if non_web_count >= 5:
        score += 1
    else:
        blockers.append("non_web_account_count_below_5")
    if distinct_platforms >= 4:
        score += 1
    else:
        blockers.append("distinct_platform_count_below_4")

    status = "complete" if score >= 3 else "under_complete"
    return score, status, blockers



def main() -> int:
    args = parse_args()
    run_id = make_run_id("municipality_score")
    db_path = Path(args.db)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if not db_path.exists():
        print(json.dumps({"run_id": run_id, "error": f"database does not exist: {db_path}"}, indent=2))
        return 1

    actor_table = "staging_actors" if args.use_staging else "actors"
    account_table = "staging_actor_accounts" if args.use_staging else "actor_accounts"

    conn = sqlite3.connect(db_path)
    existing = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    if actor_table not in existing or account_table not in existing:
        print(json.dumps({"run_id": run_id, "error": f"required tables missing: {actor_table}, {account_table}"}, indent=2))
        conn.close()
        return 1

    actor_rows = conn.execute(
        f"""
        SELECT target_id, target_name, geography, tags, notes
        FROM {actor_table}
        """
    ).fetchall()

    account_rows = conn.execute(
        f"""
        SELECT parent_target_id, platform, target_url_or_surface
        FROM {account_table}
        """
    ).fetchall()
    conn.close()

    actor_to_municipality: dict[str, str] = {}
    actor_to_fire_centre: dict[str, str] = {}
    municipality_counts: dict[str, dict[str, int | set[str] | list[str]]] = {}

    for actor_id, _name, geography, tags, notes in actor_rows:
        geo = str(geography or "")
        municipality = geo.split(",")[0].strip() if "," in geo else geo.strip()
        municipality = municipality or "unknown"

        context = f"{tags or ''} {notes or ''}".lower()
        fire_centre = "unknown"
        for candidate in ["cariboo", "coastal", "kamloops", "northwest", "prince george", "southeast"]:
            if candidate in context:
                fire_centre = candidate.title() if candidate != "prince george" else "Prince George"
                break

        actor_to_municipality[str(actor_id)] = municipality
        actor_to_fire_centre[str(actor_id)] = fire_centre
        municipality_counts.setdefault(
            municipality,
            {
                "fire_centre": fire_centre,
                "actor_ids": set(),
                "resolved_account_count": 0,
                "non_web_account_count": 0,
                "platforms": set(),
            },
        )
        municipality_counts[municipality]["actor_ids"].add(str(actor_id))

    for parent_actor, platform, _url in account_rows:
        actor_id = str(parent_actor or "")
        municipality = actor_to_municipality.get(actor_id)
        if not municipality:
            continue
        platform_value = str(platform or "").strip().lower()
        municipality_counts[municipality]["resolved_account_count"] += 1
        if platform_value and platform_value != "website":
            municipality_counts[municipality]["non_web_account_count"] += 1
        if platform_value:
            municipality_counts[municipality]["platforms"].add(platform_value)

    rows = []
    for municipality, payload in sorted(municipality_counts.items(), key=lambda x: x[0]):
        fire_centre = str(payload["fire_centre"])
        if args.fire_centre and fire_centre.lower() != args.fire_centre.lower():
            continue
        actor_count = len(payload["actor_ids"])
        resolved_count = int(payload["resolved_account_count"])
        non_web_count = int(payload["non_web_account_count"])
        distinct_platforms = len(payload["platforms"])

        score, status, blockers = _score(actor_count, resolved_count, non_web_count, distinct_platforms)
        rows.append(
            {
                "municipality_name": municipality,
                "fire_centre": fire_centre,
                "actor_count": actor_count,
                "resolved_account_count": resolved_count,
                "non_web_account_count": non_web_count,
                "distinct_platform_count": distinct_platforms,
                "completion_score": score,
                "completion_status": status,
                "blockers": ";".join(blockers),
            }
        )

    csv_path = output_dir / f"{run_id}_municipality_completion.csv"
    fields = [
        "municipality_name",
        "fire_centre",
        "actor_count",
        "resolved_account_count",
        "non_web_account_count",
        "distinct_platform_count",
        "completion_score",
        "completion_status",
        "blockers",
    ]
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    summary = {
        "run_id": run_id,
        "row_count": len(rows),
        "complete_count": sum(1 for row in rows if row["completion_status"] == "complete"),
        "under_complete_count": sum(1 for row in rows if row["completion_status"] == "under_complete"),
        "report_csv": str(csv_path),
        "use_staging": bool(args.use_staging),
        "fire_centre_filter": args.fire_centre,
    }
    json_path = output_dir / f"{run_id}_municipality_completion_summary.json"
    json_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
