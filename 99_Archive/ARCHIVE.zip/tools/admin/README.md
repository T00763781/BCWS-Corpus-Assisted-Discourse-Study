# DB-First Registry Admin Tools

This folder contains script-first operations for deterministic registry mechanics.

## Policy
- DB tables are the canonical write target.
- `registry/master/*.csv` are exported snapshots, not primary editable storage.
- Mechanical operations should run via scripts:
  - dedupe report generation
  - registry DB validation
  - CSV import staging
  - DB export snapshots
  - municipality completion scoring

## Scripts
- `dedupe_registry.py`
  - input: one or more CSV files
  - output: machine-readable duplicate diagnostics in `logs/diagnostics/`
- `validate_registry_db.py`
  - input: SQLite DB path
  - output: validation diagnostics in `logs/diagnostics/`
- `import_registry_csv_to_staging.py`
  - input: CSV paths and DB path
  - output: `staging_*` tables in DB and import manifest in `logs/diagnostics/`
- `export_registry_snapshots.py`
  - input: DB path
  - output: snapshot CSVs to `registry/snapshots/<run_id>/` by default
- `score_municipality_completion.py`
  - input: DB path
  - output: municipality scoring report in `logs/diagnostics/`

## Examples
```powershell
python tools/admin/dedupe_registry.py --inputs registry/master/*.csv
python tools/admin/validate_registry_db.py --db storage/db/local/open_fireside.sqlite
python tools/admin/import_registry_csv_to_staging.py --db storage/db/local/open_fireside.sqlite --inputs registry/master/actor_targets.csv registry/master/actor_account_targets.csv
python tools/admin/export_registry_snapshots.py --db storage/db/local/open_fireside.sqlite
python tools/admin/score_municipality_completion.py --db storage/db/local/open_fireside.sqlite
```
