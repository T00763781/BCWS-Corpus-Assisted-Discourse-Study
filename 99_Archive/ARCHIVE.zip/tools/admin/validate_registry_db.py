#!/usr/bin/env python3
"""Validate DB-first registry foundation contracts.

This script performs deterministic checks and writes machine-readable diagnostics.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sqlite3
from pathlib import Path

REQUIRED_TABLES = {
    "fire_centres",
    "municipalities",
    "actors",
    "actor_accounts",
    "actor_evidence",
    "discovery_leads",
    "discourse_sources",
    "public_communities",
    "monitoring_subscriptions",
    "ingest_runs",
    "raw_captures",
}

VERIFICATION_STATUSES = {
    "approved",
    "seeded_unverified",
    "verified_accessible",
    "verified_empty_but_valid",
    "provisional",
    "discovery_needed",
    "blocked_or_auth_required",
    "unreachable",
    "parse_failed",
    "manual_review_needed",
    "rejected",
}


def make_run_id(prefix: str) -> str:
    stamp = dt.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    return f"{prefix}_{stamp}"


def fetch_tables(conn: sqlite3.Connection) -> set[str]:
    rows = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
    return {row[0] for row in rows}


def collect_invalid_statuses(conn: sqlite3.Connection, table: str, column: str = "verification_status") -> list[str]:
    sql = f"SELECT DISTINCT {column} FROM {table} WHERE {column} IS NOT NULL"
    values = [row[0] for row in conn.execute(sql).fetchall()]
    return sorted([value for value in values if value not in VERIFICATION_STATUSES])


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate registry foundation DB shape and status constraints.")
    parser.add_argument("--db", required=True, help="SQLite database path.")
    parser.add_argument("--output-dir", default="logs/diagnostics", help="Diagnostics output directory.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    db_path = Path(args.db)
    run_id = make_run_id("validate_registry_db")
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    diagnostics = {
        "run_id": run_id,
        "db_path": str(db_path),
        "generated_at": dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "errors": [],
        "warnings": [],
    }

    if not db_path.exists():
        diagnostics["errors"].append(f"database does not exist: {db_path}")
    else:
        conn = sqlite3.connect(db_path)
        tables = fetch_tables(conn)
        missing = sorted(REQUIRED_TABLES - tables)
        if missing:
            diagnostics["errors"].append({"missing_required_tables": missing})

        status_tables = ["actors", "actor_accounts", "actor_evidence", "discourse_sources", "public_communities"]
        for table_name in status_tables:
            if table_name in tables:
                invalid = collect_invalid_statuses(conn, table_name)
                if invalid:
                    diagnostics["errors"].append(
                        {"table": table_name, "invalid_verification_status_values": invalid}
                    )

        conn.close()

    output_path = output_dir / f"{run_id}_registry_validation.json"
    output_path.write_text(json.dumps(diagnostics, indent=2), encoding="utf-8")
    print(json.dumps({"run_id": run_id, "diagnostics": str(output_path), "ok": len(diagnostics["errors"]) == 0}, indent=2))
    return 0 if len(diagnostics["errors"]) == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
