#!/usr/bin/env python3
"""Import registry CSV files into DB staging tables (`staging_*`).

This script does not mutate canonical tables. It emits deterministic diagnostics:
- logs/diagnostics/<run_id>_import_diagnostics.json
- logs/diagnostics/<run_id>_import_rejections.csv
- logs/diagnostics/<run_id>_import_summary.json
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import sqlite3
from pathlib import Path
from typing import Any

import yaml

DEFAULT_TABLE_MAP = {
    "actor_targets.csv": "staging_actors",
    "actor_account_targets.csv": "staging_actor_accounts",
    "actor_osint_evidence.csv": "staging_actor_evidence",
    "actor_account_discovery_queue.csv": "staging_discovery_leads",
    "public_communities.csv": "staging_public_communities",
    "discourse_sources.csv": "staging_discourse_sources",
    "verification_log.csv": "staging_verification_log",
}

REQUIRED_FIELDS = {
    "actor_targets.csv": ["target_id", "target_name", "verification_status", "geography"],
    "actor_account_targets.csv": [
        "account_target_id",
        "parent_target_id",
        "target_name",
        "platform",
        "target_url_or_surface",
        "verification_status",
        "evidence_id",
    ],
    "actor_account_discovery_queue.csv": [
        "discovery_id",
        "parent_target_id",
        "platform",
        "verification_status",
    ],
    "actor_osint_evidence.csv": [
        "evidence_id",
        "actor_id",
        "account_target_id",
        "evidence_source_url",
        "evidence_type",
        "verification_status",
    ],
    "public_communities.csv": ["target_id", "target_name", "platform_or_system", "url_or_endpoint", "verification_status"],
    "discourse_sources.csv": ["source_id", "source_name", "platform", "url_or_endpoint", "verification_mode", "verification_status"],
    "verification_log.csv": ["object_table", "object_id", "verification_status"],
}

ENUM_FIELDS = {
    "verification_status": {
        "approved",
        "seeded_unverified",
        "verified_accessible",
        "verified_empty_but_valid",
        "provisional",
        "discovery_needed",
        "blocked_or_auth_required",
        "unreachable",
        "parse_failed",
        "manual_review_needed",
        "rejected",
    },
    "attribution_strength": {"weak", "moderate", "strong", "direct"},
    "verification_mode": {
        "api",
        "rss",
        "html_page",
        "headless_browser",
        "manual_search_uri",
        "not_safely_collectible",
        "http_json",
        "wp_api",
        "social_surface",
        "arcgis_service",
        "arcgis_query",
    },
}

ID_FIELDS = {
    "actor_targets.csv": "target_id",
    "actor_account_targets.csv": "account_target_id",
    "actor_account_discovery_queue.csv": "discovery_id",
    "actor_osint_evidence.csv": "evidence_id",
    "public_communities.csv": "target_id",
    "discourse_sources.csv": "source_id",
}

URL_FIELDS = {
    "actor_account_targets.csv": "target_url_or_surface",
    "actor_osint_evidence.csv": "resolved_url",
    "public_communities.csv": "url_or_endpoint",
    "discourse_sources.csv": "url_or_endpoint",
}



def make_run_id(prefix: str) -> str:
    stamp = dt.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    return f"{prefix}_{stamp}"



def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Import one or more CSV files into staging tables.")
    parser.add_argument("--db", required=True, help="SQLite database path.")
    parser.add_argument("--inputs", nargs="+", required=True, help="CSV input paths.")
    parser.add_argument("--batch-id", default=None, help="Optional import batch ID.")
    parser.add_argument("--output-dir", default="logs/diagnostics", help="Diagnostics output directory.")
    parser.add_argument(
        "--clear-staging-first",
        action="store_true",
        help="Delete existing rows from target staging tables before import.",
    )
    return parser.parse_args()



def csv_rows(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        return (reader.fieldnames or []), rows



def create_staging_table(conn: sqlite3.Connection, staging_table: str, columns: list[str]) -> None:
    escaped_cols = [f'"{col}" TEXT' for col in columns]
    ddl = ", ".join(
        escaped_cols
        + [
            '"_source_file" TEXT NOT NULL',
            '"_source_line" INTEGER NOT NULL',
            '"_batch_id" TEXT NOT NULL',
            '"_imported_at" TEXT NOT NULL',
        ]
    )
    conn.execute(f'CREATE TABLE IF NOT EXISTS "{staging_table}" ({ddl})')



def insert_rows(
    conn: sqlite3.Connection,
    staging_table: str,
    columns: list[str],
    rows: list[dict[str, Any]],
    source_file: str,
    batch_id: str,
) -> int:
    if not rows:
        return 0
    import_time = dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    insert_cols = columns + ["_source_file", "_source_line", "_batch_id", "_imported_at"]
    placeholders = ", ".join(["?"] * len(insert_cols))
    quoted_cols = ", ".join([f'"{c}"' for c in insert_cols])
    sql = f'INSERT INTO "{staging_table}" ({quoted_cols}) VALUES ({placeholders})'
    payload = []
    for row in rows:
        payload.append(
            [row.get(col) for col in columns]
            + [source_file, int(row["_source_line"]), batch_id, import_time]
        )
    conn.executemany(sql, payload)
    return len(payload)



def normalize_locality(geography: str) -> str:
    if not geography:
        return ""
    return geography.split(",")[0].strip().lower()



def load_known_localities() -> set[str]:
    path = Path("registry/seed/municipality_directory_seed.csv")
    if not path.exists():
        return set()
    with path.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    return {str(row.get("locality_name", "")).strip().lower() for row in rows if row.get("locality_name")}



def load_fire_centre_codes() -> set[str]:
    path = Path("registry/seed/bc_fire_centres.yaml")
    if not path.exists():
        return set()
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    return {entry.get("code", "").strip().lower() for entry in data.get("fire_centres", []) if entry.get("code")}



def validate_row(
    file_name: str,
    row: dict[str, str],
    id_sets: dict[str, set[str]],
    known_localities: set[str],
    fire_centre_codes: set[str],
    used_ids: set[str],
    used_urls: set[str],
) -> tuple[bool, list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    for field in REQUIRED_FIELDS.get(file_name, []):
        if not str(row.get(field, "")).strip():
            errors.append(f"missing_required_field:{field}")

    for enum_field, allowed in ENUM_FIELDS.items():
        if enum_field in row:
            value = str(row.get(enum_field, "")).strip()
            if value and value not in allowed:
                errors.append(f"enum_check_failure:{enum_field}={value}")

    id_field = ID_FIELDS.get(file_name)
    if id_field:
        row_id = str(row.get(id_field, "")).strip()
        if row_id:
            if row_id in used_ids:
                errors.append(f"duplicate_id:{row_id}")
            used_ids.add(row_id)

    url_field = URL_FIELDS.get(file_name)
    if url_field:
        url = str(row.get(url_field, "")).strip().lower()
        if url:
            url_key = f"{file_name}:{url}"
            if url_key in used_urls:
                errors.append(f"duplicate_url_or_account:{url}")
            used_urls.add(url_key)

    if file_name == "actor_account_targets.csv":
        parent = str(row.get("parent_target_id", "")).strip()
        if parent and parent not in id_sets["actor_targets"]:
            errors.append(f"fk_reference_failure:parent_target_id={parent}")
        ev = str(row.get("evidence_id", "")).strip()
        if ev and ev not in id_sets["actor_osint_evidence"]:
            warnings.append(f"fk_reference_unresolved:evidence_id={ev}")

    if file_name == "actor_account_discovery_queue.csv":
        parent = str(row.get("parent_target_id", "")).strip()
        if parent and parent not in id_sets["actor_targets"]:
            errors.append(f"fk_reference_failure:parent_target_id={parent}")

    if file_name == "actor_osint_evidence.csv":
        actor = str(row.get("actor_id", "")).strip()
        account = str(row.get("account_target_id", "")).strip()
        if actor and actor not in id_sets["actor_targets"]:
            errors.append(f"fk_reference_failure:actor_id={actor}")
        if account and account not in id_sets["actor_account_targets"]:
            warnings.append(f"fk_reference_unresolved:account_target_id={account}")

    if file_name in {"actor_targets.csv", "public_communities.csv"}:
        geography = str(row.get("geography", "")).strip()
        locality = normalize_locality(geography)
        if locality and locality not in {"provincewide_or_multi_scale", "coastal region", "northwest region", "southeast region"}:
            if locality not in known_localities:
                warnings.append(f"invalid_municipality_reference:{geography}")
        tags = str(row.get("tags", "")).lower()
        if "fire_centre:" in tags:
            fc = tags.split("fire_centre:", 1)[1].split(";")[0].strip()
            if fc and fc not in fire_centre_codes:
                warnings.append(f"invalid_fire_centre_reference:{fc}")

    if file_name == "verification_log.csv":
        object_table = str(row.get("object_table", "")).strip()
        object_id = str(row.get("object_id", "")).strip()
        if object_table in {"actor_targets", "actor_account_targets", "actor_osint_evidence"} and object_id:
            table_map = {
                "actor_targets": "actor_targets",
                "actor_account_targets": "actor_account_targets",
                "actor_osint_evidence": "actor_osint_evidence",
            }
            if object_id not in id_sets[table_map[object_table]]:
                warnings.append(f"fk_reference_failure:{object_table}.{object_id}")

    if any(issue.startswith("missing_required_field:") for issue in errors):
        errors.append("cannot_safely_map_to_db_contract")

    return len(errors) == 0, errors, warnings



def ensure_migrations(conn: sqlite3.Connection) -> None:
    migrations = [
        Path("storage/db/migrations/001_init.sql"),
        Path("storage/db/migrations/002_discourse_environment.sql"),
        Path("storage/db/migrations/003_registry_foundation.sql"),
    ]
    for migration in migrations:
        if migration.exists():
            conn.executescript(migration.read_text(encoding="utf-8"))



def main() -> int:
    args = parse_args()
    run_id = make_run_id("import_staging")
    batch_id = args.batch_id or run_id
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    db_path = Path(args.db)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    ensure_migrations(conn)

    diagnostics = {
        "run_id": run_id,
        "batch_id": batch_id,
        "db_path": str(db_path),
        "generated_at": dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "tables": [],
    }
    summary = {"run_id": run_id, "batch_id": batch_id, "totals": {"imported": 0, "rejected": 0}, "tables": []}
    rejections: list[dict[str, str]] = []
    known_localities = load_known_localities()
    fire_centre_codes = load_fire_centre_codes()

    id_sets: dict[str, set[str]] = {
        "actor_targets": set(),
        "actor_account_targets": set(),
        "actor_osint_evidence": set(),
    }
    for seed_file, key in [
        ("actor_targets.csv", "actor_targets"),
        ("actor_account_targets.csv", "actor_account_targets"),
        ("actor_osint_evidence.csv", "actor_osint_evidence"),
    ]:
        p = Path("registry/master") / seed_file
        if p.exists():
            _, seed_rows = csv_rows(p)
            field = ID_FIELDS[seed_file]
            id_sets[key] = {str(row.get(field, "")).strip() for row in seed_rows if str(row.get(field, "")).strip()}

    for input_path in args.inputs:
        path = Path(input_path)
        file_name = path.name
        if not path.exists():
            diagnostics["tables"].append({"file": str(path), "status": "missing"})
            continue
        columns, rows = csv_rows(path)
        if not columns:
            diagnostics["tables"].append({"file": str(path), "status": "empty_or_no_header"})
            continue

        staging_table = DEFAULT_TABLE_MAP.get(file_name, f"staging_{path.stem}")
        create_staging_table(conn, staging_table, columns)
        if args.clear_staging_first:
            conn.execute(f'DELETE FROM "{staging_table}"')

        used_ids: set[str] = set()
        used_urls: set[str] = set()
        accepted_rows: list[dict[str, Any]] = []
        table_warnings: list[str] = []

        for index, row in enumerate(rows, start=2):
            enriched = dict(row)
            enriched["_source_line"] = index
            is_ok, errors, warnings = validate_row(
                file_name=file_name,
                row=row,
                id_sets=id_sets,
                known_localities=known_localities,
                fire_centre_codes=fire_centre_codes,
                used_ids=used_ids,
                used_urls=used_urls,
            )
            table_warnings.extend(warnings)
            if is_ok:
                accepted_rows.append(enriched)
            else:
                rejections.append(
                    {
                        "run_id": run_id,
                        "file": file_name,
                        "staging_table": staging_table,
                        "source_line": str(index),
                        "row_id": str(row.get(ID_FIELDS.get(file_name, ""), "")),
                        "reason": ";".join(errors),
                        "details": json.dumps(row, ensure_ascii=False),
                    }
                )

        imported = insert_rows(conn, staging_table, columns, accepted_rows, file_name, batch_id)
        rejected = len(rows) - imported

        summary["totals"]["imported"] += imported
        summary["totals"]["rejected"] += rejected
        summary["tables"].append(
            {
                "file": file_name,
                "staging_table": staging_table,
                "row_count": len(rows),
                "imported": imported,
                "rejected": rejected,
                "status": "ok",
            }
        )

        diagnostics["tables"].append(
            {
                "file": file_name,
                "staging_table": staging_table,
                "row_count": len(rows),
                "imported": imported,
                "rejected": rejected,
                "warnings": sorted(set(table_warnings))[:100],
            }
        )

    conn.commit()
    conn.close()

    diagnostics_path = output_dir / f"{run_id}_import_diagnostics.json"
    rejections_path = output_dir / f"{run_id}_import_rejections.csv"
    summary_path = output_dir / f"{run_id}_import_summary.json"

    diagnostics_path.write_text(json.dumps(diagnostics, indent=2), encoding="utf-8")
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    rejection_fields = ["run_id", "file", "staging_table", "source_line", "row_id", "reason", "details"]
    with rejections_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=rejection_fields)
        writer.writeheader()
        writer.writerows(rejections)

    print(
        json.dumps(
            {
                "run_id": run_id,
                "diagnostics_json": str(diagnostics_path),
                "rejections_csv": str(rejections_path),
                "summary_json": str(summary_path),
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
