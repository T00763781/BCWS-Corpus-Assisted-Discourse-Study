#!/usr/bin/env python3
"""Generate deterministic duplicate diagnostics for registry CSV inputs.

This script is report-only. It does not modify source CSV files.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import re
from difflib import SequenceMatcher
from pathlib import Path
from urllib.parse import urlparse


def utc_now() -> str:
    return dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def make_run_id(prefix: str) -> str:
    stamp = dt.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    return f"{prefix}_{stamp}"


def normalize_name(value: str) -> str:
    lowered = (value or "").strip().lower()
    lowered = re.sub(r"[\W_]+", " ", lowered)
    return re.sub(r"\s+", " ", lowered).strip()


def normalize_url_or_handle(value: str) -> str:
    raw = (value or "").strip().lower()
    if not raw:
        return ""
    if raw.startswith("@"):
        return raw.lstrip("@")
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    netloc = parsed.netloc.replace("www.", "")
    path = parsed.path.rstrip("/")
    return f"{netloc}{path}".strip("/")


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def key_name(row: dict[str, str]) -> str:
    return row.get("target_name") or row.get("source_name") or row.get("name") or ""


def key_url(row: dict[str, str]) -> str:
    return (
        row.get("target_url_or_surface")
        or row.get("url_or_endpoint")
        or row.get("account_url")
        or row.get("candidate_url_or_handle")
        or row.get("resolved_url")
        or ""
    )


def detect_duplicates(rows: list[dict[str, str]], source_name: str) -> tuple[list[dict], list[dict]]:
    exact: list[dict] = []
    likely: list[dict] = []
    seen_exact: dict[tuple[str, str], list[int]] = {}

    for idx, row in enumerate(rows, start=2):
        name_norm = normalize_name(key_name(row))
        url_norm = normalize_url_or_handle(key_url(row))
        if not name_norm and not url_norm:
            continue
        key = (name_norm, url_norm)
        seen_exact.setdefault(key, []).append(idx)

    for key, lines in seen_exact.items():
        if len(lines) > 1:
            exact.append(
                {
                    "source_file": source_name,
                    "duplicate_type": "exact",
                    "name_norm": key[0],
                    "url_or_handle_norm": key[1],
                    "line_numbers": ";".join(str(i) for i in lines),
                    "score": "1.0",
                }
            )

    records: list[tuple[int, str, str]] = []
    for idx, row in enumerate(rows, start=2):
        name_norm = normalize_name(key_name(row))
        url_norm = normalize_url_or_handle(key_url(row))
        if name_norm or url_norm:
            records.append((idx, name_norm, url_norm))

    for i in range(len(records)):
        for j in range(i + 1, len(records)):
            line_a, name_a, url_a = records[i]
            line_b, name_b, url_b = records[j]
            if not name_a or not name_b:
                continue
            if (name_a, url_a) == (name_b, url_b):
                continue
            name_score = SequenceMatcher(a=name_a, b=name_b).ratio()
            same_surface = bool(url_a and url_b and url_a == url_b)
            if name_score >= 0.93 or (name_score >= 0.85 and same_surface):
                likely.append(
                    {
                        "source_file": source_name,
                        "duplicate_type": "likely",
                        "name_norm": f"{name_a} ~ {name_b}",
                        "url_or_handle_norm": f"{url_a} ~ {url_b}",
                        "line_numbers": f"{line_a};{line_b}",
                        "score": f"{name_score:.4f}",
                    }
                )

    return exact, likely


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    fields = [
        "source_file",
        "duplicate_type",
        "name_norm",
        "url_or_handle_norm",
        "line_numbers",
        "score",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate duplicate diagnostics for registry CSV files.")
    parser.add_argument("--inputs", nargs="+", required=True, help="Input CSV paths.")
    parser.add_argument(
        "--output-dir",
        default="logs/diagnostics",
        help="Directory for duplicate report outputs.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    run_id = make_run_id("dedupe")
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    all_rows: list[dict[str, str]] = []
    summary = {"run_id": run_id, "generated_at": utc_now(), "files": [], "exact_count": 0, "likely_count": 0}

    for input_path in args.inputs:
        path = Path(input_path)
        if not path.exists():
            continue
        rows = read_rows(path)
        exact, likely = detect_duplicates(rows, path.as_posix())
        all_rows.extend(exact)
        all_rows.extend(likely)
        summary["files"].append(
            {
                "path": path.as_posix(),
                "row_count": len(rows),
                "exact_duplicates": len(exact),
                "likely_duplicates": len(likely),
            }
        )
        summary["exact_count"] += len(exact)
        summary["likely_count"] += len(likely)

    csv_path = output_dir / f"{run_id}_duplicate_report.csv"
    json_path = output_dir / f"{run_id}_duplicate_summary.json"
    write_csv(csv_path, all_rows)
    json_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(json.dumps({"run_id": run_id, "report_csv": str(csv_path), "summary_json": str(json_path)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
