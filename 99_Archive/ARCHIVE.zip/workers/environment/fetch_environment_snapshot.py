#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, sqlite3, uuid
from pathlib import Path
import requests
from workers.common.provenance.provenance import payload_hash, utc_now_iso
from workers.common.storage.fs import write_json

ROOT = Path(__file__).resolve().parents[2]
MIGRATIONS = [
    ROOT / 'storage/db/migrations/001_init.sql',
    ROOT / 'storage/db/migrations/002_discourse_environment.sql',
]


def ensure_db(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    for migration in MIGRATIONS:
        if migration.exists():
            conn.executescript(migration.read_text(encoding='utf-8'))
    return conn


def choose_rows(csv_path: Path, limit: int):
    with csv_path.open('r', encoding='utf-8', newline='') as f:
        rows = list(csv.DictReader(f))
    picks = [r for r in rows if r.get('url_or_endpoint')][:limit]
    return picks


def run(csv_path: Path, db_path: Path, limit: int) -> str:
    conn = ensure_db(db_path)
    run_id = f'environment_{uuid.uuid4().hex[:12]}'
    started_at = utc_now_iso()
    conn.execute('INSERT INTO ingestion_runs(run_id, lane, source_family, status, started_at, note) VALUES (?, ?, ?, ?, ?, ?)',
                 (run_id, 'environment', 'generic_snapshot', 'running', started_at, f'limit={limit}'))
    conn.commit()
    rows = choose_rows(csv_path, limit)
    session = requests.Session()
    session.headers.update({'User-Agent':'OpenFiresideEnvironmentCollector/0.2 (+public-source research)'})
    raw_root = ROOT / 'storage/raw/environment' / started_at.replace(':','').replace('-','')

    for row in rows:
        url = row['url_or_endpoint']
        source_id = row.get('target_id') or row.get('source_id') or row.get('source_name', 'unknown')
        r = session.get(url, timeout=30)
        ctype = r.headers.get('content-type', '')
        body = r.text[:250000]
        payload = {
            'url': url,
            'fetched_at': utc_now_iso(),
            'status': r.status_code,
            'ok': r.ok,
            'content_type': ctype,
            'body': body,
        }
        out = raw_root / f"{source_id.replace('/','_')}.json"
        write_json(out, payload)
        conn.execute(
            'INSERT OR IGNORE INTO environment_snapshots(source_id, family, collected_at, source_url, payload_hash, raw_path, note) VALUES (?, ?, ?, ?, ?, ?, ?)',
            (source_id, row.get('metric_family', row.get('source_family', 'environment')), utc_now_iso(), url, payload_hash(payload), str(out), row.get('notes', ''))
        )
        conn.commit()

    conn.execute('UPDATE ingestion_runs SET status=?, finished_at=? WHERE run_id=?', ('ok', utc_now_iso(), run_id))
    conn.commit()
    conn.close()
    return run_id


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='Collect environment source snapshots into raw storage and SQLite')
    ap.add_argument('--csv', required=True)
    ap.add_argument('--db', required=True)
    ap.add_argument('--limit', type=int, default=5)
    args = ap.parse_args()
    rid = run(Path(args.csv), Path(args.db), args.limit)
    print(json.dumps({'run_id': rid, 'csv': args.csv, 'db': args.db, 'limit': args.limit}))
