# Fire Indices

This family is not yet implemented as a dedicated collector.
Use `workers/environment/fetch_environment_snapshot.py` for generic proof capture until this family earns its own worker.
