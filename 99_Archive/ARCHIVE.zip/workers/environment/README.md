# Environment Workers

This area holds source-proof and snapshot helpers for environment families.
The current implementation is generic and intentionally conservative.
