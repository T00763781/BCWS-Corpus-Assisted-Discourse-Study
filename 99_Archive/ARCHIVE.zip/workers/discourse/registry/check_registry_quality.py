#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
STATUS_DICTIONARY = ROOT / 'registry/dictionaries/status_values.yaml'
RESOLVED_DISCOVERY_SURFACE_TYPES = {'discovery_query', 'mentions_query'}
DISCOVERY_QUEUE_ALLOWED_STATUSES = {'discovery_needed', 'provisional', 'manual_review_needed'}
ATTRIBUTION_STRENGTH_VALUES = {'weak', 'moderate', 'strong', 'direct'}
PLATFORM_ROOTS = {
    'https://x.com/',
    'https://www.facebook.com/',
    'https://www.instagram.com/',
    'https://www.tiktok.com/',
    'https://telegram.org/',
    'https://news.google.com/',
    'https://www.linkedin.com/',
    'https://www.youtube.com/',
}


def load_valid_statuses():
    if not STATUS_DICTIONARY.exists():
        return set()
    statuses = set()
    in_values = False
    for line in STATUS_DICTIONARY.read_text(encoding='utf-8').splitlines():
        if line.strip() == 'values:':
            in_values = True
            continue
        if not in_values:
            continue
        if not line.startswith('  '):
            break
        stripped = line.strip()
        if stripped.endswith(':') and not stripped.startswith('description:'):
            statuses.add(stripped[:-1])
    return statuses


def read_rows(path: Path):
    with path.open('r', encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def _normalized_url(url: str) -> str:
    if not url:
        return ''
    normalized = url.strip()
    if normalized.endswith('/'):
        return normalized
    return f'{normalized}/'


def _is_http_url(url: str) -> bool:
    return url.startswith('http://') or url.startswith('https://')


def _common_checks(rows, valid_status):
    issues = []
    expected_states = {'seeded_unverified': 0, 'discovery_needed': 0}
    ids = set()
    statuses = {}

    for idx, row in enumerate(rows, start=2):
        tid = (
            row.get('target_id')
            or row.get('account_target_id')
            or row.get('source_id')
            or row.get('discovery_id')
            or row.get('evidence_id')
            or ''
        )
        if tid:
            if tid in ids:
                issues.append({'line': idx, 'type': 'duplicate_id', 'value': tid})
            ids.add(tid)

        status = row.get('verification_status', '')
        if status:
            statuses[status] = statuses.get(status, 0) + 1
            if status == 'seeded_unverified':
                expected_states['seeded_unverified'] += 1
            if status == 'discovery_needed':
                expected_states['discovery_needed'] += 1
            if status not in valid_status:
                issues.append({'line': idx, 'type': 'invalid_status', 'value': status})

        if 'discovery' in status and not (row.get('discovery_query') or row.get('notes') or row.get('candidate_url_or_handle')):
            issues.append({'line': idx, 'type': 'discovery_without_query_or_note'})

        tags = row.get('tags', '')
        if tags and ' ' in tags and ';' not in tags:
            issues.append({'line': idx, 'type': 'tag_format_suspect', 'value': tags})

        if not row.get('target_name') and not row.get('source_name') and not row.get('evidence_id'):
            issues.append({'line': idx, 'type': 'missing_name'})

    return issues, expected_states, statuses


def _summarize_actor_account_targets(path: Path, rows, valid_status):
    issues, expected_states, statuses = _common_checks(rows, valid_status)

    for idx, row in enumerate(rows, start=2):
        url_value = (row.get('target_url_or_surface') or '').strip()
        surface_type = (row.get('surface_type') or '').strip().lower()
        mode = (row.get('verification_mode') or '').strip().lower()
        status = (row.get('verification_status') or '').strip().lower()
        evidence_id = (row.get('evidence_id') or '').strip()
        attribution_strength = (row.get('attribution_strength') or '').strip().lower()

        if not url_value:
            issues.append({'line': idx, 'type': 'missing_resolved_url'})
        elif not _is_http_url(url_value):
            issues.append({'line': idx, 'type': 'invalid_resolved_url', 'value': url_value})
        elif _normalized_url(url_value) in PLATFORM_ROOTS:
            issues.append({'line': idx, 'type': 'platform_root_not_allowed_in_resolved', 'value': url_value})

        if surface_type in RESOLVED_DISCOVERY_SURFACE_TYPES:
            issues.append({'line': idx, 'type': 'discovery_surface_in_resolved', 'surface_type': surface_type})
        if mode == 'manual_search_uri':
            issues.append({'line': idx, 'type': 'manual_search_mode_not_allowed_in_resolved'})
        if status == 'discovery_needed':
            issues.append({'line': idx, 'type': 'discovery_status_not_allowed_in_resolved'})
        if row.get('discovery_query'):
            issues.append({'line': idx, 'type': 'discovery_query_not_allowed_in_resolved'})
        if not evidence_id:
            issues.append({'line': idx, 'type': 'missing_evidence_link'})
        if attribution_strength and attribution_strength not in ATTRIBUTION_STRENGTH_VALUES:
            issues.append({'line': idx, 'type': 'invalid_attribution_strength', 'value': attribution_strength})

    return {
        'path': str(path),
        'rows': len(rows),
        'status_counts': statuses,
        'expected_state_counts': expected_states,
        'issue_count': len(issues),
        'issues': issues[:200],
    }


def _summarize_discovery_queue(path: Path, rows, valid_status):
    issues, expected_states, statuses = _common_checks(rows, valid_status)

    for idx, row in enumerate(rows, start=2):
        discovery_id = (row.get('discovery_id') or '').strip()
        discovery_query = (row.get('discovery_query') or '').strip()
        candidate = (row.get('candidate_url_or_handle') or '').strip()
        status = (row.get('verification_status') or '').strip().lower()

        if not discovery_id:
            issues.append({'line': idx, 'type': 'missing_discovery_id'})
        if not discovery_query and not candidate:
            issues.append({'line': idx, 'type': 'missing_discovery_lead'})
        if status and status in valid_status and status not in DISCOVERY_QUEUE_ALLOWED_STATUSES:
            issues.append({'line': idx, 'type': 'unexpected_discovery_queue_status', 'value': status})
        if candidate and _normalized_url(candidate) in PLATFORM_ROOTS:
            issues.append({'line': idx, 'type': 'platform_root_candidate', 'value': candidate})

    return {
        'path': str(path),
        'rows': len(rows),
        'status_counts': statuses,
        'expected_state_counts': expected_states,
        'issue_count': len(issues),
        'issues': issues[:200],
    }


def _summarize_evidence(path: Path, rows, valid_status):
    issues, expected_states, statuses = _common_checks(rows, valid_status)
    required_fields = [
        'evidence_id',
        'actor_id',
        'platform',
        'resolved_url',
        'evidence_source_url',
        'evidence_type',
        'attribution_strength',
        'verification_status',
        'collected_from',
    ]

    for idx, row in enumerate(rows, start=2):
        for field in required_fields:
            if not (row.get(field) or '').strip():
                issues.append({'line': idx, 'type': 'missing_required_field', 'field': field})

        resolved_url = (row.get('resolved_url') or '').strip()
        evidence_source_url = (row.get('evidence_source_url') or '').strip()
        attribution_strength = (row.get('attribution_strength') or '').strip().lower()

        if resolved_url and not _is_http_url(resolved_url):
            issues.append({'line': idx, 'type': 'invalid_resolved_url', 'value': resolved_url})
        if evidence_source_url and not _is_http_url(evidence_source_url):
            issues.append({'line': idx, 'type': 'invalid_evidence_source_url', 'value': evidence_source_url})
        if attribution_strength and attribution_strength not in ATTRIBUTION_STRENGTH_VALUES:
            issues.append({'line': idx, 'type': 'invalid_attribution_strength', 'value': attribution_strength})

    return {
        'path': str(path),
        'rows': len(rows),
        'status_counts': statuses,
        'expected_state_counts': expected_states,
        'issue_count': len(issues),
        'issues': issues[:200],
    }


def _summarize_generic(path: Path, rows, valid_status):
    issues, expected_states, statuses = _common_checks(rows, valid_status)

    for idx, row in enumerate(rows, start=2):
        mode = row.get('verification_mode', '')
        url_value = row.get('url_or_endpoint') or row.get('target_url_or_surface') or ''
        discovery_query = row.get('discovery_query') or ''
        if mode == 'manual_search_uri' and discovery_query:
            continue
        if not url_value and not discovery_query:
            issues.append({'line': idx, 'type': 'missing_url', 'mode': mode})

    return {
        'path': str(path),
        'rows': len(rows),
        'status_counts': statuses,
        'expected_state_counts': expected_states,
        'issue_count': len(issues),
        'issues': issues[:200],
    }


def summarize(path: Path):
    rows = read_rows(path)
    valid_status = load_valid_statuses()
    file_name = path.name.lower()

    if file_name == 'actor_account_targets.csv':
        return _summarize_actor_account_targets(path, rows, valid_status)
    if file_name == 'actor_account_discovery_queue.csv':
        return _summarize_discovery_queue(path, rows, valid_status)
    if file_name == 'actor_osint_evidence.csv':
        return _summarize_evidence(path, rows, valid_status)
    return _summarize_generic(path, rows, valid_status)


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='Check quality of Open Fireside registry CSVs')
    ap.add_argument('paths', nargs='+')
    args = ap.parse_args()
    out = [summarize(Path(p)) for p in args.paths]
    print(json.dumps(out, indent=2))
