# discourse/registry

This zone contains discourse-lane QA and registry-support helpers.
It is currently more mature than the discourse collection subfolders.
Use it to validate registry quality before broad collection work begins.
