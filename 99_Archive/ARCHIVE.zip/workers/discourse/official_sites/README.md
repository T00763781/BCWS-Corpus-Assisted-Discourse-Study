# Official Sites / Public Pages

This folder contains the initial discourse collector for public official sites, blogs, and newsrooms.
It is intentionally narrow: official/public pages first, not general social scraping.
