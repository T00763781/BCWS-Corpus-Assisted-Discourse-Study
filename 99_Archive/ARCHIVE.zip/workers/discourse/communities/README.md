# Communities

This folder is a planned or early-stage discourse collection zone.
Do not treat it as production-ready.
Any new implementation here should first reference `docs/lane-notes/discourse.md` and the active gate.
