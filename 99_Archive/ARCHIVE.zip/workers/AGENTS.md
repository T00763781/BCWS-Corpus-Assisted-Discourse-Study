# Workers AGENTS

## Scope
This instruction file applies to the `workers/` tree.

## Rules
- write raw evidence before or alongside normalized state whenever feasible
- preserve source URL, retrieved time, and collection method
- do not invent source stability or canonicality
- use `workers/common/` helpers before adding duplicate utilities
- add or extend tests when changing worker behavior
- keep per-lane workers isolated rather than creating one giant collector
