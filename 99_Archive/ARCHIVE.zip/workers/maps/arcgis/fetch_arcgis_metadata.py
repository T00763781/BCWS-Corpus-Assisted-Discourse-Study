#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
import requests


def main():
    ap = argparse.ArgumentParser(description='Fetch ArcGIS metadata endpoint and save as JSON')
    ap.add_argument('url')
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    r = requests.get(args.url, timeout=30, headers={'User-Agent':'OpenFiresideArcGISHelper/0.1'})
    payload = {
        'url': args.url,
        'status': r.status_code,
        'ok': r.ok,
        'content_type': r.headers.get('content-type', ''),
        'body': r.text[:250000],
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2), encoding='utf-8')
    print(json.dumps({'out': str(out), 'status': r.status_code}))


if __name__ == '__main__':
    main()
