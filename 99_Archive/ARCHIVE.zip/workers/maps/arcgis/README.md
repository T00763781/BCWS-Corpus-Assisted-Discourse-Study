# ArcGIS helpers

This folder holds proof-oriented helpers for ArcGIS service and layer metadata.
It is not yet a full synchronization layer.
