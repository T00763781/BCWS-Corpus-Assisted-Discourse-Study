# Layer metadata

This folder is reserved for later map-layer catalog normalization.
Use the ArcGIS helper and registry first.
