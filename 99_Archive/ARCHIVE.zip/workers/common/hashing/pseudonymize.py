from __future__ import annotations
import hashlib


def stable_pseudonym(value: str, salt: str) -> str:
    raw = f"{salt}::{value.strip().lower()}".encode('utf-8')
    digest = hashlib.sha256(raw).hexdigest()[:16]
    return f"anon_{digest}"
