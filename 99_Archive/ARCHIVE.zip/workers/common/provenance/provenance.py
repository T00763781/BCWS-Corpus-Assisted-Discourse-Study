from __future__ import annotations
import datetime as dt
import hashlib
import json


def utc_now_iso() -> str:
    return dt.datetime.utcnow().replace(microsecond=0).isoformat() + 'Z'


def payload_hash(payload) -> str:
    normalized = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
    return hashlib.sha256(normalized.encode('utf-8')).hexdigest()
