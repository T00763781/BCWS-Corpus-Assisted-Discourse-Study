#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sqlite3, uuid
from pathlib import Path
import requests, yaml

from workers.common.provenance.provenance import payload_hash, utc_now_iso
from workers.common.storage.fs import write_json
from workers.common.logging.run_logger import log_event

ROOT = Path(__file__).resolve().parents[3]
MIGRATIONS = [
    ROOT / 'storage/db/migrations/001_init.sql',
    ROOT / 'storage/db/migrations/002_discourse_environment.sql',
]
LOG_PATH = ROOT / 'storage/raw/incidents/bcws/run_log.jsonl'


def ensure_db(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    for migration in MIGRATIONS:
        if migration.exists():
            conn.executescript(migration.read_text(encoding='utf-8'))
    return conn


def fetch_json(url: str, session: requests.Session):
    r = session.get(url, timeout=30)
    r.raise_for_status()
    return r.json()


def unwrap(payload):
    body = payload.get('body') if isinstance(payload, dict) else None
    if isinstance(body, str):
        try:
            return json.loads(body)
        except Exception:
            return {'raw_body': body}
    if body is None:
        return payload
    return body


def store_raw(base_dir: Path, name: str, payload):
    path = base_dir / name
    write_json(path, payload)
    return path


def store_incident(conn, incident_number, fire_year, collected_at, source_url, body, raw_path):
    conn.execute(
        """INSERT OR IGNORE INTO incident_versions
        (incident_number, fire_year, collected_at, source_url, payload_hash, stage_of_control,
         incident_name, incident_location, discovered_at, last_updated_ts, raw_path)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            incident_number,
            fire_year,
            collected_at,
            source_url,
            payload_hash(body),
            body.get('stageOfControlCode'),
            body.get('incidentName'),
            body.get('incidentLocation'),
            body.get('discoveryDate'),
            body.get('lastUpdatedTimestamp'),
            str(raw_path),
        )
    )


def store_attachment_snapshot(conn, incident_number, fire_year, collected_at, source_url, body, raw_path):
    conn.execute(
        """INSERT OR IGNORE INTO incident_attachments
        (incident_number, fire_year, collected_at, source_url, payload_hash, raw_path)
        VALUES (?, ?, ?, ?, ?, ?)""",
        (incident_number, fire_year, collected_at, source_url, payload_hash(body), str(raw_path))
    )


def store_external_uri_snapshot(conn, incident_number, fire_year, collected_at, source_url, body, raw_path):
    conn.execute(
        """INSERT OR IGNORE INTO incident_external_uris
        (incident_number, fire_year, collected_at, source_url, payload_hash, raw_path)
        VALUES (?, ?, ?, ?, ?, ?)""",
        (incident_number, fire_year, collected_at, source_url, payload_hash(body), str(raw_path))
    )


def run(limit: int, db_path: Path, year_hint: int | None = None) -> str:
    cfg = yaml.safe_load((Path(__file__).with_name('config.yaml')).read_text(encoding='utf-8'))
    session = requests.Session()
    session.headers.update({'User-Agent': cfg['user_agent']})
    run_id = f'bcws_{uuid.uuid4().hex[:12]}'
    started_at = utc_now_iso()
    conn = ensure_db(db_path)
    conn.execute(
        'INSERT INTO ingestion_runs(run_id, lane, source_family, status, started_at, note) VALUES (?, ?, ?, ?, ?, ?)',
        (run_id, 'incidents', 'bcws', 'running', started_at, f'limit={limit}')
    )
    conn.commit()

    base_dir = ROOT / 'storage/raw/incidents/bcws' / started_at.replace(':', '').replace('-', '')
    list_payload = fetch_json(cfg['list_endpoint'], session)
    list_path = store_raw(base_dir, 'list.json', list_payload)
    parsed_list = unwrap(list_payload)
    collection = parsed_list.get('collection', []) if isinstance(parsed_list, dict) else []
    collection = collection[:limit]

    for item in collection:
        incident_number = item.get('incidentNumberLabel') or item.get('incident_number')
        fire_year = int(item.get('fireYear') or year_hint or 2025)
        if not incident_number:
            continue
        collected_at = utc_now_iso()

        detail_url = cfg['incident_detail_template'].format(incident_number=incident_number, fire_year=fire_year)
        detail_payload = fetch_json(detail_url, session)
        detail_body = unwrap(detail_payload)
        detail_path = store_raw(base_dir, f'{incident_number}_detail.json', detail_payload)
        store_incident(conn, incident_number, fire_year, collected_at, detail_url, detail_body, detail_path)

        attach_url = cfg['attachment_template'].format(incident_number=incident_number)
        try:
            attach_payload = fetch_json(attach_url, session)
            attach_body = unwrap(attach_payload)
            attach_path = store_raw(base_dir, f'{incident_number}_attachments.json', attach_payload)
            store_attachment_snapshot(conn, incident_number, fire_year, collected_at, attach_url, attach_body, attach_path)
        except Exception as e:
            log_event(LOG_PATH, {'run_id': run_id, 'event': 'attachment_fetch_failed', 'incident_number': incident_number, 'error': str(e)})

        external_url = cfg['external_uri_template'].format(incident_number=incident_number)
        try:
            external_payload = fetch_json(external_url, session)
            external_body = unwrap(external_payload)
            external_path = store_raw(base_dir, f'{incident_number}_external_uri.json', external_payload)
            store_external_uri_snapshot(conn, incident_number, fire_year, collected_at, external_url, external_body, external_path)
        except Exception as e:
            log_event(LOG_PATH, {'run_id': run_id, 'event': 'external_uri_fetch_failed', 'incident_number': incident_number, 'error': str(e)})

        conn.commit()

    conn.execute('UPDATE ingestion_runs SET status=?, finished_at=? WHERE run_id=?', ('ok', utc_now_iso(), run_id))
    conn.commit()
    conn.close()
    log_event(LOG_PATH, {'run_id': run_id, 'event': 'run_complete', 'started_at': started_at, 'limit': limit, 'raw_root': str(base_dir), 'list_path': str(list_path)})
    return run_id


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='Collect BCWS incident detail, attachments, and external URIs into raw storage and SQLite history')
    ap.add_argument('--db', required=True, help='Path to SQLite database')
    ap.add_argument('--limit', type=int, default=10)
    ap.add_argument('--year-hint', type=int, default=None)
    args = ap.parse_args()
    run_id = run(args.limit, Path(args.db), args.year_hint)
    print(json.dumps({'run_id': run_id, 'db': args.db, 'limit': args.limit}))
