# BCWS incident historian

This worker is the most mature implementation in the repo.
It is responsible for:
- collecting the BCWS public incident list,
- collecting incident detail records,
- collecting attachment metadata,
- collecting incident-linked external URIs,
- writing raw JSON to disk,
- and appending history rows to SQLite.

It should never clear and replace incident history.
