# Repo Map

## Control plane
- `AGENTS.md` — root operating law
- `docs/autorun/` — lane state, gates, and current sprint
- `docs/` — methodology, audiences, targeting rules, truth matrix, runbook

## Canonical data planning
- `registry/master/` — canonical target/source registries
- `registry/schemas/` — CSV and DB contracts
- `registry/dictionaries/` — controlled values used by the registries

## Recon evidence
- `recon/raw/` — raw recon artifacts copied from the current BCWS scan set
- `recon/parsed/` — derived seed tables; useful for reference but not canonical over `registry/master/`

## Workers
- `workers/incidents/bcws/` — most mature implemented collector
- `workers/discourse/official_sites/` — initial discourse collector for public official/blog/news pages
- `workers/discourse/registry/` — registry quality checking
- `workers/environment/` — environment snapshot helpers and future family-specific workers
- `workers/maps/` — ArcGIS/map metadata helpers
- `workers/common/` — hashing, logging, provenance, file storage helpers

## App
- `app/OpenFireside.Desktop/` — WinUI shell direction, still largely stub
- `app/OpenFireside.Contracts/` — small shared types
- `app/OpenFireside.Data/` — path and data helper layer
- `app/OpenFireside.ReadModels/` — lane/read-model starter types

## Utilities
- `tools/verify_targets.py`
- `tools/build_review_pack.py`
- `tools/run_lane.py`
- `tools/db_inspect.py`
- `tools/validate_repo_state.py`
