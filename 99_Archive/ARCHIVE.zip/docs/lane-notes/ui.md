# Lane Note — Ui

## Goal
Focus on lane-by-lane inspection surfaces only after fetch and save are proven.

## Canonical files
See `docs/repo-truth-matrix.md` and edit only the canonical files named for this lane.

## Current live status
Refer to `docs/autorun/lanes.yaml` for the current live status and active gate.

## Required stop output
Produce a review pack under `reviews/ui/<gate>/` before asking for approval.
