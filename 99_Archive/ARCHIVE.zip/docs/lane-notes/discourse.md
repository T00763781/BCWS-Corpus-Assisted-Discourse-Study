# Lane Note — Discourse

## Goal
Focus on registry truth, official-site proof capture, and identity-handling clarity.

## Canonical files
See `docs/repo-truth-matrix.md` and edit only the canonical files named for this lane.

## Current live status
Refer to `docs/autorun/lanes.yaml` for the current live status and active gate.

## Required stop output
Produce a review pack under `reviews/discourse/<gate>/` before asking for approval.
