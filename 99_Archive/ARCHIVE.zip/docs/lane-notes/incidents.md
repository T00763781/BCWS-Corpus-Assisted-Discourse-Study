# Lane Note — Incidents

## Goal
Focus on BCWS-only append/amend history, attachments, and external URI preservation.

## Canonical files
See `docs/repo-truth-matrix.md` and edit only the canonical files named for this lane.

## Current live status
Refer to `docs/autorun/lanes.yaml` for the current live status and active gate.

## Required stop output
Produce a review pack under `reviews/incidents/<gate>/` before asking for approval.
