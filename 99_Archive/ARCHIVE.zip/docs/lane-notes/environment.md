# Lane Note — Environment

## Goal
Focus on source proof, stable snapshotting, and separating map layers from tabular/state feeds.

## Canonical files
See `docs/repo-truth-matrix.md` and edit only the canonical files named for this lane.

## Current live status
Refer to `docs/autorun/lanes.yaml` for the current live status and active gate.

## Required stop output
Produce a review pack under `reviews/environment/<gate>/` before asking for approval.
