# Repo Truth Matrix

This file is the authoritative statement of what is real, what is partial, and what is scaffold in this repo.
Codex should trust this file when deciding where to work.

| Path | Status | Rank | Purpose | What is real | What is missing | Guidance |
|---|---|---:|---|---|---|---|
| `AGENTS.md` | live | A+ | root control plane | mission, lane order, gate rules, truth map, validation commands | none material | read first |
| `docs/` | live | A | methodology and workflow doctrine | methodology, audiences, review standard, targeting rules, gate protocol, lane notes, recon summaries | examples can still deepen | canonical narrative source |
| `registry/master/` | live | A | canonical registry CSVs | seeded rows, verification columns, actor/account/community/source targets | still needs ongoing expansion | preferred edit zone |
| `registry/schemas/` | partial-live | A- | contracts for CSV and DB shapes | baseline schema and contract files exist | still needs per-table examples | update when enums or columns change |
| `registry/dictionaries/` | partial-live | A- | controlled vocabularies | baseline dictionaries exist | can deepen with descriptions | update together with registry/status changes |
| `recon/raw/` | live | A | raw evidence from starter recon | copied source files and sample payloads | none material for current starter set | never overwrite originals casually |
| `recon/parsed/` | partial-live | B+ | derived seed tables | useful comparison tables | not canonical over registry/master | treat as reference, not source of truth |
| `workers/incidents/bcws/` | partial-live | A- | BCWS incident capture | real collector, config, README | needs diffing and broader tests | safest place for active collector work |
| `workers/discourse/registry/` | partial-live | B+ | registry QA | real checker script | can expand rule coverage | good discourse lane utility |
| `workers/discourse/official_sites/` | partial-live | B | first discourse collector | generic public-page collector exists | not a full social/community collector | use for official/blog/news proof only |
| `workers/environment/` | partial-live | B- | environment helpers | generic snapshot collector exists | family-specific collectors still missing | keep scope narrow |
| `workers/maps/arcgis/` | partial-live | B- | map metadata helper | metadata fetch helper exists | no full layer sync yet | use for endpoint proof only |
| `workers/common/` | live | A- | shared helpers | hashing, logging, provenance, file storage | more tests can be added | safe to reuse |
| `tools/` | live | A- | repo utilities | verifier, review pack builder, lane runner, db inspector, validation tool | more ergonomics possible | primary operator tool zone |
| `storage/db/migrations/` | partial-live | A- | DB contracts | incident + discourse/environment starter migrations | additional normalized tables will grow later | canonical DB contract zone |
| `app/OpenFireside.Contracts/` | wired-no-data | B- | shared types | minimal types are present | needs growth with real UI/data integration | safe for small contract additions |
| `app/OpenFireside.Data/` | wired-no-data | C+ | data helper layer | db path resolver and helpers | no active query layer | do not overbuild yet |
| `app/OpenFireside.ReadModels/` | wired-no-data | C+ | starter read models | lane/read-model skeletons | not yet linked to real data | keep minimal |
| `app/OpenFireside.Desktop/` | stub | C | WinUI shell direction | meaningful shell placeholder and scoped AGENTS | not wired to live data | do not treat as mature operator tool |
| `tests/workers/` | partial-live | B- | worker tests | multiple Python tests exist | coverage still incomplete | keep growing with new scripts |
| `reviews/templates/` | partial-live | B | gate pack shape | concrete template and manifest | more filled examples can still be added | use at every gate |
| `dist/` | stub | C- | packaging output areas | structure only | no operator-grade packaging yet | not a current build priority |
