# Methodology

## Purpose
Open Fireside exists to build a defensible longitudinal evidence base for the wildfire information environment.
That means it should help Earl understand:
- what is happening in incidents,
- what is happening in the environment,
- who the relevant actors are,
- what discourse is circulating,
- how narratives, rumours, misinformation, campaign uptake, and trust dynamics evolve over time.

## Non-negotiable principles
1. **Public-source only**
   Use public-domain and publicly accessible sources only during the private research phase.
2. **Evidence first**
   Preserve source URL, retrieval time, publication time where available, payload or raw file path, and collection method.
3. **Raw before interpretation**
   Never store interpretation alone.
4. **Incident-aware but not incident-bound**
   Discourse may link to incidents, topics, campaigns, narratives, communities, or remain broader than any one incident.
5. **Provenance and reversibility**
   The project should allow later re-checking of claims against preserved evidence.
6. **Local-first privacy controls**
   Sensitive linkage and obfuscation logic should happen locally.
7. **Truthful confidence labelling**
   Verification status should never be overstated.

## Audience defensibility standard
Assume the project may be inspected by:
- government researchers,
- crisis and risk communicators,
- academic supervisors,
- policy analysts,
- journalists,
- skeptical external reviewers.

The repo, data model, and outputs should therefore make it easy to answer:
- where did this come from?
- when was it fetched?
- how do you know it is public?
- what is named and what is obfuscated?
- what is raw evidence and what is derived interpretation?
- what is verified versus provisional?

## Identity handling
### Named public targets
The following may remain named:
- public officials,
- official institutional spokespeople,
- ministries and public agencies,
- named public organizations,
- official accounts,
- clearly public communities and forums.

### Public contact information
Publicly available contact information may be retained for public-role targets (public officials, institutions, municipalities/regional districts, ministries/agencies, DMOs, official programs).
Private-citizen identifiable contact information should not be retained in registry outputs.

### Private individuals
Private individuals who do not hold office should be obfuscated at ingestion using a stable project hash.
That allows pattern analysis without unnecessary exposure of identity.

### Downstream outputs
In final deliverables:
- private-individual discourse should normally be paraphrased,
- names and handles should remain withheld,
- insights should usually be aggregated unless there is a strong public-interest reason tied to already public institutional roles.

## Temporal scope
The active collection and backfill emphasis for this repo is the 2025–2026 wildfire year, while preserving architecture and contracts suitable for multi-year accumulation.

## Insight posture
The system should support insights such as:
- who is shaping public understanding,
- which publics are amplifying or resisting official guidance,
- where campaign uptake appears strong or weak,
- where information gaps or trust ruptures appear,
- how incident, environment, and discourse interact over time.

## Anti-drift rule
If a proposed feature makes the system feel more like surveillance, people tracking, or covert monitoring than public-source research, stop and redesign it.

## Registry attribution contract note
Discourse actor-account registry work uses strict resolved-vs-discovery separation:
- resolved direct URLs in `actor_account_targets.csv`,
- unresolved hypotheses in `actor_account_discovery_queue.csv`,
- attribution evidence path in `actor_osint_evidence.csv`.
