# Operating Order

## Active lane
`discourse`

## Active gate
`D-G1`

## Current objective
Harden the discourse target registry for the 2025–2026 wildfire year so it is credible enough to support initial official-site and public-source discourse collection.

## Allowed work right now
- improve discourse registries
- verify and downgrade rows truthfully
- improve discourse collection method notes
- prove official-site/news/blog capture
- create the D-G1 review pack

## Forbidden work right now
- broad UI work
- environment family expansion beyond source-proof helpers
- redesigning the repo into a different architecture
- claiming discourse social/community capture is production-ready

## Stop condition
Stop when:
- D-G1 review pack exists,
- registry quality checks pass,
- official-site proof capture exists,
- lane status is set to `ready_for_user`.
