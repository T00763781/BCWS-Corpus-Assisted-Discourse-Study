# Current Sprint

## Scope
Only the discourse lane is in active sprint scope.

## Expected changed files
- `registry/master/actor_targets.csv`
- `registry/master/actor_account_targets.csv`
- `registry/master/public_communities.csv`
- `registry/master/discourse_sources.csv`
- `registry/master/verification_log.csv`
- `reviews/discourse/D-G1/*`
- optionally discourse worker/helper files if they improve official-site proof

## Expected outputs
- cleaner target universe
- stronger verification notes
- truthful row states
- official-site capture proof
- D-G1 review pack
