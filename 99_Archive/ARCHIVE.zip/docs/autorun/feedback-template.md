# Feedback Template

Decision: approve / revise / block

What is wrong:
1.
2.
3.

Must fix before proceed:
-

Can wait:
-

Promote to canonical? yes / no
