# Open Fireside — Product Requirements Document (PRD) v1

## 1. Product identity
- **Platform name:** Open Fireside
- **Research initiative:** Open Fireside Project
- **Positioning:** Independent research platform for aggregating publicly accessible wildfire incident information, environmental context, maps, and digital discourse for longitudinal analysis.
- **Primary operator:** Independent researcher / communications practitioner working full-time while completing an interdisciplinary studies capstone.
- **Data posture:** Public-domain and publicly accessible sources only during the private research phase. No publishing or intervention features. Collection, convergence, preservation, and analysis only.

## 2. Problem statement
Wildfire communication work currently requires too many disconnected surfaces: wildfire incident pages, geospatial viewers, evacuation resources, weather products, blogs, news, and public discourse platforms. This fragmentation slows daily situational awareness and weakens long-term research because environmental conditions and discourse records are not preserved in a unified, incident-aware database.

Open Fireside solves this by converging public wildfire, environmental, mapping, and discourse data into a single research platform that supports:
1. **Summer operations support:** fast awareness of incidents, alerts, restrictions, weather, and discourse conditions.
2. **Winter research and strategy:** longitudinal analysis of messaging, misinformation, narrative shifts, and communication patterns across seasons.

## 3. Product vision
Build a modular research platform that preserves the relationship between:
- wildfire incidents,
- environmental conditions,
- official information,
- public discourse,
- narratives, rumours, misinformation, and campaign uptake,
across days, incidents, topics, campaigns, and years.

## 4. Core product principles
1. **Public-source only:** prioritize publicly accessible APIs, feeds, pages, layers, and posts.
2. **Evidence first:** store source, timestamp, context, and derivation; never store interpretation alone.
3. **Incident-aware but not incident-bound:** incidents are a top-level object, but discourse can also be topic-, campaign-, narrative-, or event-centered.
4. **Map-native:** geospatial context is foundational.
5. **Modular ingestion:** every source should be independently configurable and replaceable.
6. **Private first, open later:** private repo and corpus during degree program; open-source release after research maturation.
7. **Collection, not publishing:** the platform surfaces and analyzes information; it does not post outward.

## 5. Primary users and jobs-to-be-done
### Primary user
Independent researcher / wildfire communications practitioner.

### Summer jobs
- Monitor provincial fire activity and restrictions.
- Watch evacuations and public safety context.
- Track incident-level developments.
- Associate public discourse with incidents, topics, and narratives.
- Preserve daily context for later research.

### Winter jobs
- Analyze campaign uptake (e.g., FireSmart).
- Compare discourse year over year.
- Examine misinformation / disinformation patterns.
- Study communication gaps, trust dynamics, and narrative evolution.
- Build evidence-informed communication and engagement strategies.

## 6. Core analytical objects
Open Fireside must support these top-level objects:

### 6.1 Incidents
Wildfire-specific events with canonical BCWS-derived records.

### 6.2 Environment
Weather, fire danger, lightning, smoke, air quality, restrictions, evacuations, and related geospatial context.

### 6.3 Discourse items
Posts, articles, comments, videos, captions, transcripts, forum threads, and related public communications.

### 6.4 Topics
Cross-incident themes such as FireSmart, evacuation awareness, fire bans, smoke, or preparedness.

### 6.5 Narratives
Recurring interpretive patterns and claims, including rumours, false alerts, misinformation, and conspiracy themes.

### 6.6 Campaigns / programs
Proactive communication efforts such as FireSmart or seasonal preparedness messaging.

### 6.7 Events
Moments that can trigger discourse spikes, such as evacuation orders, wildfire-of-note designation, or major press updates.

## 7. App surfaces
## 7.1 Home
Purpose: customizable situational overview.
Capabilities:
- pinned incidents
- pinned discourse topics / narrative watches
- provincial headline stats
- active evacuation orders / alerts
- recent notices
- quick links to saved searches
- personalized modules

## 7.2 Fire Activity and Weather
Purpose: provincial environmental and operational surface.
Capabilities:
- wildfire activity metrics
- current year and historical year selection
- local state tracking over time
- refresh + auto-refresh
- recent notices / wildfire-of-note summary
- category 1/2/3 and forest use restrictions
- weather and related environmental context

## 7.3 Map
Purpose: single geospatial plane with layered sources.
Capabilities:
- one map canvas
- selectable layers (fires, perimeters, evacuations, bans, weather, lightning, smoke, AQ, roads, communities, etc.)
- layer toggles and filters
- pop-out support
- canonical map composition from discovered ArcGIS and related endpoints

## 7.4 Incidents
Purpose: canonical incident surface.
Capabilities:
- 0.9:1 mirror of BCWS list concepts (wildfires, evacuations, area restrictions, bans)
- incident list, filters, search, sorting
- incident page with:
  - Details (verbatim / canonical)
  - Response (verbatim / canonical)
  - Gallery (verbatim / canonical)
  - Maps (verbatim / canonical)
  - Discourse (new; linked research surface)

## 7.5 Discourse
Purpose: cross-platform analytical surface.
Capabilities:
- platform-sorted views
- topic views
- narrative views
- incident-linked discourse
- campaign-linked discourse
- time series and cross-source clustering
- saved watches and analyst notes
- initially stubbed until ingestion helpers mature

## 7.6 Search
Pinned in global navigation.
Capabilities:
- search incidents, discourse items, topics, narratives, sources, places, and dates.

## 7.7 Settings
Purpose: control modular ingestion and configuration.
Capabilities:
- source registry
- ingestor enable/disable
- credentials for source accounts / APIs
- schedules
- storage locations
- diagnostics / troubleshooting
- theme selection

## 8. Functional requirements
1. The platform shall ingest and surface canonical wildfire incident data from public BCWS-related sources.
2. The platform shall ingest and surface public environmental and mapping data from public endpoints and layers.
3. The platform shall maintain a local historical state record for selected provincial metrics.
4. The platform shall support year-based views for current and previous years where source data allows.
5. The platform shall allow map layers from multiple public sources to be composited in a single interface.
6. The platform shall allow discourse records to link to incidents, topics, campaigns, narratives, events, or remain unlinked.
7. The platform shall preserve source provenance for all collected records.
8. The platform shall provide modular source controls in Settings.
9. The platform shall support pop-out windows for major app surfaces.
10. The platform shall remain private-repo compatible during the research phase.

## 9. Non-functional requirements
- Windows-first local operation.
- Readable dark theme by default.
- Modular codebase and source adapters.
- Graceful failure on source outages.
- Basic diagnostics visible to operator.
- No required cloud dependency for core use.
- Export-friendly data model for future research analysis.

## 10. Data requirements
For each stored record, preserve where possible:
- source name
- source URL / endpoint
- retrieval timestamp
- publication timestamp
- content type
- canonical identifier
- linked incident/topic/narrative/campaign/event IDs
- geospatial attributes
- raw payload or reversible normalized representation
- analyst notes / derived fields (separate from raw)

## 11. Success criteria
### Phase 1 success
- canonical source registry established
- Fire Activity and Weather surface populated from public endpoints
- Map surface supports core wildfire and restriction layers
- Incident list and incident pages populated canonically
- discourse tabs stubbed and ready for ingestion pipeline integration

### Phase 2 success
- discourse ingestion for selected public sources
- cross-linking between incidents and discourse
- narrative and topic watch capability
- longitudinal local database accumulating season-over-season evidence

## 12. Out of scope for now
- outbound publishing
- private account monitoring without lawful/public basis
- hidden or non-public data acquisition
- final open-source packaging during corpus-building years
