# Open Fireside Project Starter Pack

This pack contains three files for a fresh ChatGPT project or architecture reset:

- `open_fireside_prd_v1.md`
- `open_fireside_build_plan_v1.yaml`
- `open_fireside_project_manager_metaprompt_v1.txt`

## Recommended use
1. Start a fresh project/thread for **Open Fireside**.
2. Upload these files plus `out-high-level.zip`.
3. In the new project, ask the assistant to:
   - inspect/extract the recon archive,
   - derive a source registry,
   - build a canonical endpoint/layer matrix,
   - define the core data model,
   - recommend the next implementation steps.

## Intended assistant role
Project manager / technical strategist with the user acting as:
- local machine relay,
- researcher,
- product owner,
- tester / client for feedback.
