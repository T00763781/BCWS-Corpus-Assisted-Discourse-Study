# Research Audiences and Outputs

## Primary operator audience
Earl uses Open Fireside to reduce cognitive load, preserve context across wildfire seasons, and generate stronger research and communications judgment.

## Second-order audiences
Although the system is private during development, its outputs may eventually be seen by:
- government researchers,
- crisis and risk communicators,
- public safety and emergency management analysts,
- academics,
- journalists,
- skeptical peers or funders.

## What the system should help generate
### For Earl
- daily awareness snapshots
- incident change histories
- discourse pattern summaries
- actor maps and source watchlists
- campaign uptake notes
- friction-point and trust-gap observations

### For second-order audiences
- methodologically clear research memos
- evidence bundles with provenance
- high-level narrative and misinformation analysis
- longitudinal comparisons across seasons
- briefing-ready but source-grounded summaries

## Quality standard for insights
Every insight should be traceable to one or more of:
- raw evidence,
- normalized records,
- explicit linkage logic,
- documented interpretation rules.

## What to avoid
- overclaiming causality
- implying hidden access
- presenting inferred sentiment or motivation as fact
- exposing private individuals unnecessarily
- confusing one-off anecdotes with stable patterns
