# Targeting Rules

## Goal
Build a broad but defensible target universe for the wildfire information environment.

## Prioritization order
1. named public institutions and official sources
2. named public officials and official communicators
3. official accounts and websites for those targets
4. clearly public communities and public discourse venues
5. public news/blog/bulletin sources
6. discovery rows for unresolved but high-value public targets

## Acceptable target classes
- public officials
- ministries and public agencies
- local governments
- First Nations governments and public offices
- utilities and transport operators
- tourism and DMO organizations with wildfire-relevant communications
- official blogs, bulletins, and newsrooms
- clearly public communities such as subreddits, forums, or public Telegram channels where wildfire discourse occurs

## Unacceptable target behaviour
Do not add targets that depend on:
- private access,
- hidden scraping,
- non-public groups,
- speculative identity matching,
- directory-mining of non-public-role individuals merely because a name exists.

## Account resolution rule
Never invent handles.
Use:
- canonical websites,
- explicit linked accounts,
- clearly official branded public pages,
- or discovery rows marked `discovery_needed`.

## Resolved vs discovery contract
- `registry/master/actor_account_targets.csv` is resolved-only and must contain direct public URLs.
- `registry/master/actor_account_discovery_queue.csv` is discovery-only and must contain unresolved leads/hypotheses.
- Platform-root URLs are not valid resolved account rows.
- Resolved account rows must link to evidence in `registry/master/actor_osint_evidence.csv`.
- Discovery queue rows are expected to carry `discovery_query` and/or a candidate handle/URL lead.

## OSINT attribution minimum
For each actor/org/public individual:
1. identify official/public anchor source
2. identify direct public surface URL
3. record evidence path
4. classify as resolved or discovery-needed

Do not mark a platform as resolved unless a direct public URL and public attribution evidence exist.

## Geography rule
For local actors, do not use province-only geography when locality is known.
Use locality-grade representation such as:
- `Kamloops, British Columbia`
- `Prince George, British Columbia`
- `Spokane, Washington`

Preferred contract fields for future rows:
- `locality`
- `province_state`
- `country`
- `regional_group`
- `border_relevance`

## Public-individual and contact handling
Public individuals (ministers, mayors, councillors/chairs where relevant, fire chiefs, emergency managers, official communicators, trusted public actors) may be named.

Publicly available contact information may be stored for:
- public individuals
- public institutions and organizations
- municipalities/regional districts
- ministries/agencies
- DMOs and official programs

Private citizens' identifiable contact information must not be stored in registry outputs.

## Status semantics
- `verified_accessible`: reachable and parse-valid for the stated method
- `verified_empty_but_valid`: reachable and valid but currently empty
- `provisional`: plausible but not yet strong enough to trust fully
- `discovery_needed`: target matters but direct surface not yet resolved
- `blocked_or_auth_required`: reachable family but not safely or publicly collectible now
- `unreachable`: failed reachability at time of test
- `parse_failed`: reachable but response shape or content currently unusable
- `manual_review_needed`: requires manual inspection or browser-based validation
- `rejected`: explicitly not a fit for the project

## Example of a good row
A named ministry website with an explicit wildfire or emergency bulletin page and a clear public basis.

## Example of an acceptable discovery row
A municipality named in the actor registry with website verified, but Facebook handle unresolved and marked `discovery_needed` with a discovery query and notes.

## Example of a bad row
A speculative personal account with no clear public-role basis, no official link, and no documented relevance.
