# Evidence Review Standard

Use this file when deciding whether a lane or output is good enough to present to Earl or defend to skeptical reviewers.

## Required evidence attributes
Every important record family should preserve:
- source URL or endpoint,
- retrieved timestamp,
- publication timestamp where available,
- raw payload path or binary path,
- content type,
- verification status,
- collection method,
- notes on ambiguity if needed.

## Review questions
1. Can a reviewer tell where this came from?
2. Can a reviewer distinguish raw evidence from interpretation?
3. Can a reviewer see what was obfuscated and why?
4. Can a reviewer tell what is verified versus provisional?
5. Could a later researcher reproduce or challenge the result?

## Gate expectation
A gate should not be approved if the answer to any of the questions above is no for the core records being shown.
