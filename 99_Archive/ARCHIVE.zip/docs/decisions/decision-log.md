# Decision log

- 2026-03-10: Adopt discourse -> incidents -> environment -> UI lane order.
- 2026-03-10: Treat the monorepo as development control plane and actual tool workspace.
- 2026-03-10: Keep private-individual obfuscation at ingestion, not only at export.

- 2026-03-10: Upgraded Codex handoff package with stronger repo truth map, deeper methodology, broader skill/prompt detail, and additional proof-oriented collectors.
