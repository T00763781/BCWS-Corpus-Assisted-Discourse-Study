# Gates and Feedback Protocol

## Purpose
Codex should not free-run through the repo.
Every major step ends at a gate with a review pack and a human decision.

## Gate states
- `blocked`
- `in_progress`
- `ready_for_user`
- `approved`
- `done`

## Minimum proof required at a gate
1. source proof
2. storage proof
3. diagnostics proof
4. surface proof if a UI element exists for that lane

## Review pack structure
Each pack under `reviews/<lane>/<gate-id>/` must contain:
- `summary.md`
- `decision_request.md`
- `changed_files.txt`
- `diagnostics/`
- `sample_raw/`
- `sample_db_queries/`
- `screenshots/` if applicable
- `manifest.json`
- optional `feedback.md` after review

## Feedback template
Use this structure:
- Decision: approve / revise / block
- What is wrong: 1–3 concrete defects
- Must fix before proceed
- Can wait
- Promote to canonical? yes / no

## Example
Decision: revise
What is wrong:
1. discovery rows are mixed with verified rows in the same filter view
2. private-individual identity handling is not obvious in the sample outputs
3. one source was marked verified without parse evidence
Must fix before proceed:
- separate status filters
- add obfuscation evidence in review pack
- downgrade the unproven source row
Can wait:
- LinkedIn expansion
Promote to canonical: no
