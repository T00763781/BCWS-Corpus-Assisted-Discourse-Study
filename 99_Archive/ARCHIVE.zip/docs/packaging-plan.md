# Packaging Plan

## Development package
This repo is a development and Codex handoff package.
It includes doctrine, registry seeds, recon evidence, workers, tests, and stubs.

## What belongs in a later operator package
- desktop application artifact
- approved worker bundle
- approved registry seeds
- local DB migrations
- operator runbook
- methodology summary

## What should not ship in an operator package
- exploratory review packs
- pycache or compiled intermediates
- dead experiments
- contradictory draft docs
- stale recon copies no longer needed for method review

## Current package status
- dev-grade handoff: yes
- operator-grade release: no
