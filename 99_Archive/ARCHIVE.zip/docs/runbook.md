# Local Runbook

Assume PowerShell on the Windows machine unless noted otherwise.

## Setup
```powershell
python -m venv .venv
. .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## Baseline validation
```powershell
python toolsalidate_repo_state.py
python toolserify_targets.py registry\master\incident_sources.csv registry\master\environment_sources.csv registry\master\map_layers.csv registry\masterctor_targets.csv registry\masterctor_account_targets.csv registry\master\public_communities.csv registry\master\discourse_sources.csv
python workers\discourseegistry\check_registry_quality.py registry\master\*.csv
```

## Incident lane proof
```powershell
python workers\incidentscws\collect_bcws.py --db storage\db\local\open_fireside.sqlite --limit 5
python tools\db_inspect.py storage\db\local\open_fireside.sqlite --query "SELECT * FROM ingestion_runs ORDER BY started_at DESC LIMIT 5"
```

## Discourse official-site proof
```powershell
python workers\discourse\official_sites\collect_official_site.py --csv registry\master\discourse_sources.csv --db storage\db\local\open_fireside.sqlite --limit 3
```

## Environment snapshot proof
```powershell
python workers\environmentetch_environment_snapshot.py --csv registry\master\environment_sources.csv --db storage\db\local\open_fireside.sqlite --limit 5
```

## Build review pack
```powershell
python toolsuild_review_pack.py discourse D-G1 --summary reviews\discourse\D-G1\summary.md
```

## Files to return for human review
- the updated registry CSVs you changed
- the relevant review-pack folder
- any DB query exports used in the review pack
- screenshots if a surface was involved
