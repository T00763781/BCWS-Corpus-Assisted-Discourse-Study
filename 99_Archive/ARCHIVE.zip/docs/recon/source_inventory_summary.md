# Source Inventory Summary

## Current observed BCWS recon state
The copied recon bundle shows:
- 778 request events
- 753 response events
- 361 unique URLs
- 87 API candidates
- 9 ArcGIS service roots
- 245 BCWS source URLs
- 10 recorded errors

## Source families observed
### Incidents
- public incident list queries
- incident detail records
- incident stage feature feeds
- incident attachments
- incident-linked external URIs

### Environment / restrictions / map context
- situation report
- statistics
- evacuation order and alert service patterns
- area restriction service and query patterns
- fire perimeters service patterns
- fire centre boundary service patterns
- world topo basemap

### Discourse / related content
- BCWS blog WordPress API
- incident-linked external video references
- public news/blog/community seeds in registry files

## Use
Treat this as the high-level orientation summary, not the canonical endpoint contract.
