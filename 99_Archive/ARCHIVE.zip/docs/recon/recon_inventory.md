# Recon Inventory

## High-value raw files
- `recon/raw/summary.json`
- `recon/raw/api_endpoints.txt`
- `recon/raw/arcgis_services.txt`
- `recon/raw/bcws_sources.txt`
- `recon/raw/https_wildfiresituation-api.nrs.gov.bc.ca_publicPublishedIncident_pageNumber_0_pageRowCount_9999_orderBy_lastUpdatedTimestamp_20.json`
- `recon/raw/https_wildfiresituation-api.nrs.gov.bc.ca_publicSituationReport_pageNumber_0_pageRowCount_10_published_TRUE.json`
- `recon/raw/https_wildfiresituation-api.nrs.gov.bc.ca_statistics_fireYear_2025_fireCentre_BC.json`
- `recon/raw/https_wildfiresituation-api.nrs.gov.bc.ca_publicPublishedIncident_G70422_fireYear_2025.json`
- `recon/raw/https_wildfiresituation-api.nrs.gov.bc.ca_publicPublishedIncident_G90413_fireYear_2025.json`
- `recon/raw/https_wildfiresituation-api.nrs.gov.bc.ca_publicPublishedIncidentAttachment_G70422_attachments.json`
- `recon/raw/https_wildfiresituation-api.nrs.gov.bc.ca_publicPublishedIncidentAttachment_G90413_attachments.json`

## Raw evidence purpose
These files are preserved so Codex and the human operator can:
- inspect what the public site actually requested,
- compare planned collectors to observed endpoint behavior,
- justify source choices with evidence,
- and avoid designing from guesswork.
