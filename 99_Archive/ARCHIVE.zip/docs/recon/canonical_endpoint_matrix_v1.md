# Canonical Endpoint Matrix v1

## Strong BCWS incident spine candidates
| Family | Pattern | Status | Notes |
|---|---|---|---|
| incident list | `publicPublishedIncident?...` | strong | supports pagination, stage filters, sort, bbox / radius patterns |
| incident detail | `publicPublishedIncident/<incident>?fireYear=<year>` | strong | canonical incident detail candidate |
| attachments | `publicPublishedIncidentAttachment/<incident>/attachments` | strong | returns image/document metadata and byte URLs |
| external URIs | `publicExternalUri?sourceObjectUniqueId=<incident>` | situational | can be empty or populated depending on incident |
| stage features | `publicPublishedIncident/features?stageOfControl=...` | mixed | `UNDR_CNTRL` observed populated; several others returned null in current capture |
| statistics | `statistics?fireYear=<year>&fireCentre=BC` | strong | usable provincial metrics |
| situation report | `publicSituationReport?...published=TRUE` | strong | usable statewide situational context |

## ArcGIS / map candidates
| Family | Pattern | Status | Notes |
|---|---|---|---|
| World Topo basemap | `server.arcgisonline.com/...World_Topo_Map...` | usable | successful metadata response observed |
| area restrictions root | `services6...Area_Restrictions.../?f=pjson` | broken root | returned `Invalid URL` in current capture |
| evacuation root | `services6...Evacuation_Orders_and_Alerts.../?f=pjson` | broken root | returned `Invalid URL` in current capture |
| fire perimeters root | `services6...BCWS_FirePerimeters_PublicView.../?f=pjson` | broken root | returned `Invalid URL` in current capture |
| tile boundary roots | `tiles*.arcgis.com/...BCWS_FireCenterBdys2...` | unstable in capture | several failed to fetch from the capture context |
| observed query paths | `services6.../query?...` | more promising | actual query URLs observed in captured request list are more valuable than broken roots |

## Discourse-adjacent candidates
| Family | Pattern | Status | Notes |
|---|---|---|---|
| BCWS blog posts | `blog.gov.bc.ca/bcwildfire/wp-json/wp/v2/posts?...` | usable | can support official blog capture |
| BCWS blog tags | `blog.gov.bc.ca/bcwildfire/wp-json/wp/v2/tags?...` | usable | supports app/content filtering |
| incident-linked external video | `publicExternalUri...` | situational | observed YouTube link for G70422 |
