# BCWS Observed Incident Patterns

## What the current raw captures show
- Incident detail for G90413 and G70422 returns rich JSON including identifiers, stage of control, timestamps, coordinates, and HTML overview text.
- Attachment endpoints return multiple records and image byte URLs.
- External URI results vary by incident: G90413 returned empty in the capture while G70422 returned a public YouTube video link.
- Stage feature feeds are not uniformly populated across statuses.

## Design implications
- preserve incident detail as the canonical incident history object
- preserve attachments as their own historical evidence object
- preserve external URIs as optional linked evidence rather than assuming each incident has them
- treat feature feeds as supplemental map-ready views, not the sole incident truth source
