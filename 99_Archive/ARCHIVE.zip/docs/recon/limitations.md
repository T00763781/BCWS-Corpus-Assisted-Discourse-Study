# Recon Limitations

## Known limitations in the current capture
1. Several ArcGIS metadata roots return `Invalid URL` rather than useful service metadata.
2. Several tile-service roots failed to fetch in the capture context.
3. Some stage-of-control feature feeds returned `features: null`, so empty results should not be confused with collector failure.
4. External URI coverage is incident-dependent.
5. The current discourse registry is a seed universe, not a complete resolved account universe.

## Practical consequence
Codex should use the recon to ground design decisions, but should not treat every observed URL as equally stable or collector-ready.
