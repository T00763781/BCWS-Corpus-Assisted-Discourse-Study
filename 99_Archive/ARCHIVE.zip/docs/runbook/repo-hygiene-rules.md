# Repo Hygiene Runbook

## Purpose
This runbook documents the deterministic hygiene rules that every Codex agent must follow in Open Fireside. It is referenced by `.codex/skills/open-fireside-repo-hygiene/SKILL.md` and should be updated whenever canonical paths, logging practices, or duplicate-handling guidance change.

## Canonical path checklist
| Family | Canonical Path | Notes |
| --- | --- | --- |
| Registry master tables | `registry/master/actor_*`, `registry/master/public_communities.csv`, `registry/master/discourse_sources.csv`, `registry/master/verification_log.csv` | Always update here. Do not replicate in `open_fireside_universe_seed/seed_snapshot/` or `_repo_audit_*`. |
| Registry ops/control plane | `registry/ops/` | `universe_registry_orchestration.yaml` is the multi-agent control file; do not write clones elsewhere. |
| Registry seed inputs | `registry/seed/` | If you unpack `seed.zip`, copy the needed CSVs into `registry/seed/` before editing. Keep `open_fireside_universe_seed/` read-only. |
| Review packs | `reviews/<lane>/<gate>/` | Every gate's `summary.md`, `decision_request.md`, `changed_files.txt`, `manifest.json`, `diagnostics/`, `sample_raw/` is canonical for that gate. |
| Workers | `workers/...` | Worker scripts and tests should stay inside `workers/` (with patrol for incidents/environment limitations). |
| Docs | `docs/...` | Any runbooks, methodology, or targeting rules belong under `docs/`. |
| Tools | `tools/...` | Utility helpers, validation scripts. |
| Tests | `tests/...` | Concrete test suites go here. |
| Audit outputs | `_repo_audit_*` | Treat as generated diagnostics, not canonical. |
| Packaged seeds | `seed.zip` | The zipped seed at repo root is the authoritative package; duplicates are archival only. |

## Duplicate seed handling
- `open_fireside_universe_seed/` and `seed/open_fireside_universe_seed/` contain nested copies of the seed. Use them only as read-only references; copy data into `registry/seed/` before editing.
- `seed-1.zip` and other zipped duplicates should be renamed (e.g., `seed-1.zip.orig`) and moved to `_repo_audit_<timestamp>/` if they are no longer needed. Do not write new data into them.
- If a seed folder appears to compete with a canonical folder, pause and log the conflict via the hygiene skill and mention the recommendation in the review pack cleanup note.

## Logging and diagnostics
- Create `logs/repo-hygiene/` if missing.  
  - Run log: `logs/repo-hygiene/run.log` (append-only, light entry describing what directories were touched, what agent/scope, date/time, and whether duplicates were encountered).  
  - Diagnostics: `logs/repo-hygiene/diagnostics/<timestamp>.json` or `*.csv`.  
- Scratch outputs: `tmp/repo-hygiene/` (gitignored; never committed).  
- Review pack artifacts: keep any evidence inside `reviews/<lane>/<gate>/sample_raw/` or `diagnostics/`.  
- Forbidden commits: raw HTTP dumps, browser cookies, hashed seeds outside canonical location, zipped duplicates, and logs containing secrets.

## Investigation vs canonical outputs
- Generated snapshots: `_repo_audit_*/*` (files.csv, tree.txt, row counts) are evidence of hygiene checks and remain read-only logs.  
- Review pack outputs: `reviews/<lane>/<gate>/*` are the only place to store final summaries, manifest, and diagnostics.  
- Imported seed material: Only edit `registry/seed/*` and `seed.zip` when copying or refreshing seed data; the `open_fireside_universe_seed/` directories are reference clones and must stay untouched.  
- Archives: When duplicates are noted (e.g., zipped seed copies), mention them as archival artifacts and avoid editing both copies; non-destructive rename/quarantine is recommended.

## Multi-agent reference
- Always consult `agents/agent_contract.yaml` + `registry/ops/universe_registry_orchestration.yaml` before editing canonical registry tables. They define which agent owns each packet and what the QA merge agent should do.  
- Document any cross-agent confusions in `reviews/<lane>/<gate>/diagnostics/conflicts.md` and let the QA agent perform the final merge.  
- If you hit an unresolved multi-agent conflict, stop and escalate; the `open-fireside-repo-hygiene` skill will highlight this scenario.

## Cleanup recommendations
- Prefer marking duplicates and recommending quarantine instead of deleting.  
- When renaming duplicates, record the action in `reviews/<lane>/<gate>/diagnostics/cleanup.md`.  
- Always describe hygiene recommendations in the review summary so future agents know why duplicates exist.
