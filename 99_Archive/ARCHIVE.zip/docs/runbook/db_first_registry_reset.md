# DB-First Registry Reset

## Decision
Open Fireside registry operations now use a DB-first control model.

## Canonical write target
- Canonical writes go to DB tables created via `storage/db/migrations/003_registry_foundation.sql`.
- `registry/master/*.csv` should be treated as exported snapshots from DB state, not primary operational write targets.

## Script-first mechanics
Mechanical registry work should be deterministic and script-driven:
- dedupe reports
- registry validation
- CSV import staging
- DB export snapshots
- municipality completion scoring

Scripts for these operations live under `tools/admin/`.

## Human/Codex role boundary
- Script-first for repeatable mechanics.
- Codex/agents reserved for ambiguous judgments, architecture choices, and policy-level decisions.

## Scope guardrails for this reset step
- No wave expansion.
- No ingestion pipeline expansion.
- No public app/UI work.
- No destructive cleanup of historical artifacts.
