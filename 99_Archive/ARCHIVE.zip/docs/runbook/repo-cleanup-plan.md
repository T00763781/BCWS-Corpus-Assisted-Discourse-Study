# Open Fireside Repo Cleanup Plan

## Purpose
Capture the deterministic, non-destructive cleanup steps that make the repo safe per `.codex/skills/open-fireside-repo-hygiene/SKILL.md`. This plan is about path hygiene only—registry/master and registry/ops stay untouched for now.

## Canonical path decisions
- Packaged seed artifact: `seed.zip` at the repo root is the sole canonical package.  
- Seed import staging: `registry/imports/seed/` is the canonical unpack and staging area before any data migrates into `registry/seed/`.  
- Registry seed inputs: `registry/seed/*` (including `registry/seed/fire_centre_directories/`) remain the writable seed tables; never write to reference-only copies.  
- Registry masters: `registry/master/*` continue to hold the canonical actor/account/community/source tables (not changed in this cleanup).  
- Registry ops/control plane: `registry/ops/universe_registry_orchestration.yaml` and `codex_boot_note.md` are canonical, untouched write targets.  
- Logs: plan for `logs/repo-hygiene/run.log` (append-only).  
- Diagnostics: `logs/repo-hygiene/diagnostics/` for structured diagnostics and `_repo_audit_*` folders for generated audit outputs.  
- Temporary scratch: `tmp/repo-hygiene/` (gitignored).  
- Review-pack evidence: `reviews/discourse/D-G2/` remains the only location for review artifacts, diagnostics, and sample_raw.

## Duplicate/reference inventory
| Path | Classification | Notes |
| --- | --- | --- |
| `seed.zip` | Canonical packaged seed | Primary package used for future imports. |
| `registry/imports/seed/` | Canonical import staging | All new seed data should land here first. |
| `registry/seed/` | Canonical seed inputs | Only directory to be edited for seed records. |
| `open_fireside_universe_seed/` | Reference-only duplicate | Keep read-only and document as archival in the cleanup notes. |
| `seed/open_fireside_universe_seed/` | Reference-only duplicate | Same treatment as above. |
| `seed-1.zip` | Quarantine candidate | Plan to move under `_repo_audit_<timestamp>/seed-1.zip.orig` later. |
| `_repo_audit_2026-03-11_013719/` | Generated audit output | Diagnostic/reference data; leave untouched. |

## Recommended non-destructive cleanup actions
1. Document `open_fireside_universe_seed/` and `seed/open_fireside_universe_seed/` as reference-only copies in this plan and in `docs/runbook/repo-hygiene-rules.md`; leave them read-only.  
2. Later, move/rename `seed-1.zip` into `_repo_audit_<timestamp>/` and add a README explaining it is an archived duplicate (no action yet).  
3. Use `registry/imports/seed/` as the canonical staging area for future seed unpack jobs; copy needed CSVs into `registry/seed/`.  
4. Mark `_repo_audit_2026-03-11_013719/` as generated diagnostics and keep it untouched.  
5. Prepare to populate `logs/repo-hygiene/` and `tmp/repo-hygiene/` once cleanup executes (folder creation recorded in future actions).

## Multi-agent protections until cleanup
- Agents continue to respect the ownership assigned in `agents/agent_contract.yaml` and `registry/ops/universe_registry_orchestration.yaml`.  
- No writes occur under `open_fireside_universe_seed/`, `seed/open_fireside_universe_seed/`, `_repo_audit_*`, or `seed-1.zip` until cleanup is executed.  
- Conflicts must be logged to `reviews/discourse/D-G2/diagnostics/conflicts.md` and escalated to the `qa_merge_agent`.  
- Seed imports are staged under `registry/imports/seed/` and only after verification copied into `registry/seed/`.  
- Logs stay under `logs/repo-hygiene/`; review evidence remains in `reviews/discourse/D-G2/`.

## Do not execute yet
- No file moves.  
- No renames.  
- No deletions.  
- No edits to `registry/master/*`.  
- No changes to `registry/ops/*`.  
- Wait for approval of this plan before touching any canonical or duplicate paths described above.

## Future execution checklist
1. Pre-check: confirm duplicates and canonical paths, note them here.  
2. Quarantine/rename duplicates (e.g., move `seed-1.zip` to `_repo_audit_<timestamp>/`).  
3. Create `logs/repo-hygiene/` and `tmp/repo-hygiene/` with README placeholders.  
4. Mark reference-only folders with README explaining their archival nature.  
5. Verify canonical paths before unblocking future work.  
6. Stop and record completion in `reviews/discourse/D-G2/diagnostics/cleanup.md`.

## Risks if skipped
- Without quarantine, future agents might copy from `seed-1.zip` or open seed mirrors and create conflicting registry data.  
- Multi-agent work could target different seeds, making merges impossible.  
- Missing log/diagnostic discipline makes tracking hygiene incidents impossible before the next registry wave.
