# Open Fireside — AGENTS.md

## Mission
Open Fireside is a private, local-first research platform for the wildfire information environment.
Treat it as an evidence system for incidents, environment, discourse, actors, topics, narratives, campaigns, events, sources, and maps/layers.
Do not frame the project as surveillance, people-tracking, covert collection, or threat monitoring of citizens.
Prefer language such as public discourse research, wildfire information environment, communication context, narrative diffusion, rumours, misinformation, campaign uptake, and engagement patterns.

## Product identity
- Open Fireside = platform
- Open Fireside Project = research initiative

## Who this repo serves
This repo exists to help Earl build a research system that produces:
- summer situational awareness across incidents, restrictions, evacuations, weather, smoke, and discourse,
- winter longitudinal analysis of communication, trust, misinformation, narratives, campaign uptake, and response gaps,
- outputs that remain methodologically defensible if viewed by government researchers, crisis and risk communicators, academics, journalists, or other second-order audiences.

## Project standard
Optimize for unimpeachable method, not just technical throughput.
When there is a choice between moving faster and preserving provenance, precision, defensibility, reversibility, or privacy safeguards, prefer the latter unless the active lane document says otherwise.

## Mandatory read order
Read these files in order before editing anything substantial:
1. `README.md`
2. `docs/autorun/operating-order.md`
3. `docs/autorun/lanes.yaml`
4. `docs/repo-truth-matrix.md`
5. `docs/methodology.md`
6. `docs/research-audiences-and-outputs.md`
7. `docs/evidence-review-standard.md`
8. `docs/targeting-rules.md`
9. `docs/gates-and-feedback-protocol.md`
10. the active lane note in `docs/lane-notes/`

## Build order
1. discourse / actors
2. incidents (BCWS public web app and discoverable public API patterns only)
3. environment
4. per-lane MVP UI after fetch + save are proven

Do not jump to broad UI work before the active lane passes its gate.

## Repo truth map
Treat these folders as the real working core:
- `registry/master/`
- `registry/schemas/`
- `registry/dictionaries/`
- `docs/`
- `recon/raw/`
- `recon/parsed/`
- `workers/incidents/bcws/`
- `workers/common/`
- `tools/`
- `storage/db/migrations/`

Treat these folders as partial-live expansion zones:
- `workers/discourse/`
- `workers/environment/`
- `workers/maps/`
- `app/OpenFireside.Contracts/`
- `app/OpenFireside.Data/`
- `app/OpenFireside.ReadModels/`

Treat these folders as scaffold or design zones:
- `app/OpenFireside.Desktop/Views/`
- `app/OpenFireside.Desktop/ViewModels/`
- `app/OpenFireside.Desktop/Services/`
- `app/OpenFireside.Tests/`
- `dist/`

Always verify status in `docs/repo-truth-matrix.md` before treating a folder as mature.

## Primary working files by lane
### Discourse
- `registry/master/actor_targets.csv`
- `registry/master/actor_account_targets.csv`
- `registry/master/public_communities.csv`
- `registry/master/discourse_sources.csv`
- `workers/discourse/registry/check_registry_quality.py`
- `workers/discourse/official_sites/collect_official_site.py`
- `tools/verify_targets.py`

### Incidents
- `registry/master/incident_sources.csv`
- `workers/incidents/bcws/collect_bcws.py`
- `workers/incidents/bcws/config.yaml`
- `storage/db/migrations/001_init.sql`
- `storage/db/migrations/002_discourse_environment.sql`

### Environment
- `registry/master/environment_sources.csv`
- `registry/master/map_layers.csv`
- `workers/environment/fetch_environment_snapshot.py`
- `workers/maps/arcgis/fetch_arcgis_metadata.py`

### Review / control plane
- `docs/autorun/lanes.yaml`
- `docs/autorun/stop-gates.yaml`
- `docs/decisions/decision-log.md`
- `reviews/`

## Hard rules
- Publicly accessible sources only.
- Preserve raw evidence, source URL, retrieval timestamp, publication timestamp where possible, and collection method.
- Store raw before normalized records whenever feasible.
- Separate raw, normalized, and derived data.
- Named public officials, institutions, official accounts, named public organizations, and clearly public communities may remain named.
- Private individuals who do not hold office must be obfuscated at ingestion using the project pseudonymization helper and identity handling rules.
- Final deliverables should paraphrase private-individual discourse and aggregate where appropriate.
- Never invent account handles, source canonicality, or successful ingestion claims.
- Never infer that an endpoint is stable just because it responded once.
- When uncertain, mark a row `provisional`, `discovery_needed`, or `blocked_or_auth_required`, not `verified_accessible`.
- Never edit both `registry/master/` and `recon/parsed/` unless `registry/master/` remains canonical.

## Required staging labels
Use these labels exactly when describing a module, screen, or workflow:
- `live`
- `partial-live`
- `wired-no-data`
- `stub`
- `mock`

Do not present stub or mock work as live.

## What the project is expected to generate
The project should eventually support outputs such as:
- incident-aware awareness snapshots,
- change histories for official BCWS incident pages,
- discourse trend and narrative summaries,
- campaign uptake indicators,
- misinformation / rumour pattern analysis,
- geospatial context views,
- evidence bundles that can support methodological review by skeptical external audiences,
- internal research memos that help Earl think clearly and reduce cognitive load,
- second-order briefings that a government researcher, crisis communicator, or external reviewer could inspect without finding obvious methodological weaknesses.

## Required stop-gate behaviour
At each gate, stop and write a review pack under `reviews/<lane>/<gate-id>/`.
Each review pack must contain:
- `summary.md`
- `decision_request.md`
- `changed_files.txt`
- `diagnostics/`
- `sample_raw/`
- `sample_db_queries/`
- `screenshots/` if a surface exists
- `manifest.json`

Do not proceed past a gate until `docs/autorun/lanes.yaml` marks the gate approved.

## Validation commands
Run the relevant validation commands before stopping:
- `python tools/verify_targets.py <csv ...>`
- `python workers/discourse/registry/check_registry_quality.py registry/master/*.csv`
- `python workers/discourse/official_sites/collect_official_site.py --csv registry/master/discourse_sources.csv --limit 3`
- `python workers/incidents/bcws/collect_bcws.py --db storage/db/local/open_fireside.sqlite --limit 5`
- `python workers/environment/fetch_environment_snapshot.py --csv registry/master/environment_sources.csv --db storage/db/local/open_fireside.sqlite --limit 5`
- `python tools/db_inspect.py storage/db/local/open_fireside.sqlite --query "SELECT * FROM ingestion_runs ORDER BY started_at DESC LIMIT 5"`
- `python tools/validate_repo_state.py`
- `python -m pytest tests/workers -q`
- `python -m compileall workers tools`

## Skills
Use repo-local skills from `.codex/skills/` when the task matches the workflow.
Each skill names:
- what files to read,
- what files are allowed to change,
- what outputs are expected,
- what checks must run before stopping.

## If repo reality and repo plan conflict
Trust, in order:
1. `docs/repo-truth-matrix.md`
2. the active lane note
3. implemented code and migrations
4. then planning docs

When a folder is thin, say so plainly and either improve it or avoid it.
