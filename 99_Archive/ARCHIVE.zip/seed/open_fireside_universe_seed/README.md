This path mirrors the universe seed for archival reference only. Keep it read-only; do not perform edits here. Copy needed CSVs into `registry/imports/seed/` if you are refreshing canonicals.
