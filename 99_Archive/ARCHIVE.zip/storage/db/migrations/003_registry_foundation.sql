PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS fire_centres (
  fire_centre_id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL UNIQUE,
  jurisdiction TEXT NOT NULL DEFAULT 'British Columbia',
  official_reference_url TEXT,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE IF NOT EXISTS municipalities (
  municipality_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  locality_type TEXT NOT NULL CHECK (
    locality_type IN ('municipality', 'regional_district', 'first_nation', 'community', 'other')
  ),
  province_state TEXT NOT NULL,
  country TEXT NOT NULL,
  fire_centre_id TEXT,
  regional_district_or_host TEXT,
  border_relevance TEXT CHECK (
    border_relevance IN ('inside_bc', 'bordering_bc', 'outside_bc', 'unknown')
  ),
  seed_status TEXT CHECK (
    seed_status IN ('present', 'missing', 'provisional', 'retired')
  ),
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  FOREIGN KEY (fire_centre_id) REFERENCES fire_centres (fire_centre_id),
  UNIQUE (name, province_state, country)
);

CREATE TABLE IF NOT EXISTS actors (
  actor_id TEXT PRIMARY KEY,
  municipality_id TEXT,
  fire_centre_id TEXT,
  target_name TEXT NOT NULL,
  target_type TEXT,
  actor_class TEXT,
  org_class TEXT,
  role_title TEXT,
  canonical_source_url TEXT,
  verification_status TEXT NOT NULL CHECK (
    verification_status IN (
      'approved',
      'seeded_unverified',
      'verified_accessible',
      'verified_empty_but_valid',
      'provisional',
      'discovery_needed',
      'blocked_or_auth_required',
      'unreachable',
      'parse_failed',
      'manual_review_needed',
      'rejected'
    )
  ),
  identity_rule TEXT,
  obfuscation_rule TEXT,
  is_public_official INTEGER NOT NULL DEFAULT 0 CHECK (is_public_official IN (0, 1)),
  ingestion_scope TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  FOREIGN KEY (municipality_id) REFERENCES municipalities (municipality_id),
  FOREIGN KEY (fire_centre_id) REFERENCES fire_centres (fire_centre_id),
  UNIQUE (target_name, target_type, municipality_id)
);

CREATE TABLE IF NOT EXISTS actor_accounts (
  account_id TEXT PRIMARY KEY,
  actor_id TEXT NOT NULL,
  platform TEXT NOT NULL,
  surface_type TEXT NOT NULL,
  account_url TEXT NOT NULL,
  normalized_handle TEXT,
  verification_status TEXT NOT NULL CHECK (
    verification_status IN (
      'approved',
      'seeded_unverified',
      'verified_accessible',
      'verified_empty_but_valid',
      'provisional',
      'discovery_needed',
      'blocked_or_auth_required',
      'unreachable',
      'parse_failed',
      'manual_review_needed',
      'rejected'
    )
  ),
  attribution_strength TEXT CHECK (
    attribution_strength IN ('weak', 'moderate', 'strong', 'direct')
  ),
  ingestion_scope TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  FOREIGN KEY (actor_id) REFERENCES actors (actor_id),
  UNIQUE (platform, account_url)
);

CREATE TABLE IF NOT EXISTS actor_evidence (
  evidence_id TEXT PRIMARY KEY,
  actor_id TEXT NOT NULL,
  account_id TEXT,
  platform TEXT,
  resolved_url TEXT,
  evidence_source_url TEXT NOT NULL,
  evidence_type TEXT NOT NULL,
  attribution_strength TEXT CHECK (
    attribution_strength IN ('weak', 'moderate', 'strong', 'direct')
  ),
  verification_status TEXT NOT NULL CHECK (
    verification_status IN (
      'approved',
      'seeded_unverified',
      'verified_accessible',
      'verified_empty_but_valid',
      'provisional',
      'discovery_needed',
      'blocked_or_auth_required',
      'unreachable',
      'parse_failed',
      'manual_review_needed',
      'rejected'
    )
  ),
  collected_from TEXT,
  collected_at TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  FOREIGN KEY (actor_id) REFERENCES actors (actor_id),
  FOREIGN KEY (account_id) REFERENCES actor_accounts (account_id),
  UNIQUE (actor_id, account_id, evidence_source_url)
);

CREATE TABLE IF NOT EXISTS discovery_leads (
  discovery_id TEXT PRIMARY KEY,
  actor_id TEXT,
  platform TEXT NOT NULL,
  candidate_surface_type TEXT,
  candidate_url_or_handle TEXT,
  discovery_query TEXT,
  priority TEXT CHECK (priority IN ('low', 'medium', 'high', 'critical')),
  verification_status TEXT NOT NULL CHECK (
    verification_status IN ('discovery_needed', 'provisional', 'manual_review_needed', 'rejected')
  ),
  last_reviewed_utc TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  FOREIGN KEY (actor_id) REFERENCES actors (actor_id),
  UNIQUE (actor_id, platform, candidate_url_or_handle, discovery_query)
);

CREATE TABLE IF NOT EXISTS discourse_sources (
  source_id TEXT PRIMARY KEY,
  actor_id TEXT,
  account_id TEXT,
  source_name TEXT NOT NULL,
  source_kind TEXT NOT NULL,
  platform TEXT,
  url_or_endpoint TEXT NOT NULL,
  verification_mode TEXT NOT NULL CHECK (
    verification_mode IN (
      'api',
      'rss',
      'html_page',
      'headless_browser',
      'manual_search_uri',
      'not_safely_collectible',
      'http_json',
      'wp_api',
      'social_surface',
      'arcgis_service',
      'arcgis_query'
    )
  ),
  verification_status TEXT NOT NULL CHECK (
    verification_status IN (
      'approved',
      'seeded_unverified',
      'verified_accessible',
      'verified_empty_but_valid',
      'provisional',
      'discovery_needed',
      'blocked_or_auth_required',
      'unreachable',
      'parse_failed',
      'manual_review_needed',
      'rejected'
    )
  ),
  identity_handling TEXT,
  tags TEXT,
  ingestion_scope TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  FOREIGN KEY (actor_id) REFERENCES actors (actor_id),
  FOREIGN KEY (account_id) REFERENCES actor_accounts (account_id),
  UNIQUE (platform, url_or_endpoint)
);

CREATE TABLE IF NOT EXISTS public_communities (
  community_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  platform TEXT NOT NULL,
  url_or_endpoint TEXT NOT NULL,
  municipality_id TEXT,
  fire_centre_id TEXT,
  verification_status TEXT NOT NULL CHECK (
    verification_status IN (
      'approved',
      'seeded_unverified',
      'verified_accessible',
      'verified_empty_but_valid',
      'provisional',
      'discovery_needed',
      'blocked_or_auth_required',
      'unreachable',
      'parse_failed',
      'manual_review_needed',
      'rejected'
    )
  ),
  public_basis TEXT,
  identity_rule TEXT,
  obfuscation_rule TEXT,
  tags TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  FOREIGN KEY (municipality_id) REFERENCES municipalities (municipality_id),
  FOREIGN KEY (fire_centre_id) REFERENCES fire_centres (fire_centre_id),
  UNIQUE (platform, url_or_endpoint)
);

CREATE TABLE IF NOT EXISTS monitoring_subscriptions (
  subscription_id TEXT PRIMARY KEY,
  subject_type TEXT NOT NULL CHECK (
    subject_type IN (
      'actor',
      'actor_account',
      'discourse_source',
      'public_community',
      'municipality',
      'fire_centre'
    )
  ),
  actor_id TEXT,
  account_id TEXT,
  source_id TEXT,
  community_id TEXT,
  municipality_id TEXT,
  fire_centre_id TEXT,
  cadence_minutes INTEGER NOT NULL CHECK (cadence_minutes > 0),
  collection_method TEXT NOT NULL,
  is_enabled INTEGER NOT NULL DEFAULT 1 CHECK (is_enabled IN (0, 1)),
  last_run_at TEXT,
  last_status TEXT NOT NULL DEFAULT 'never_run' CHECK (
    last_status IN ('never_run', 'running', 'ok', 'failed', 'paused')
  ),
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  FOREIGN KEY (actor_id) REFERENCES actors (actor_id),
  FOREIGN KEY (account_id) REFERENCES actor_accounts (account_id),
  FOREIGN KEY (source_id) REFERENCES discourse_sources (source_id),
  FOREIGN KEY (community_id) REFERENCES public_communities (community_id),
  FOREIGN KEY (municipality_id) REFERENCES municipalities (municipality_id),
  FOREIGN KEY (fire_centre_id) REFERENCES fire_centres (fire_centre_id)
);

CREATE TABLE IF NOT EXISTS ingest_runs (
  run_id TEXT PRIMARY KEY,
  run_kind TEXT NOT NULL CHECK (
    run_kind IN ('import', 'export', 'validate', 'dedupe', 'score', 'admin', 'ingest')
  ),
  status TEXT NOT NULL CHECK (
    status IN ('running', 'ok', 'failed', 'cancelled')
  ),
  started_at TEXT NOT NULL,
  finished_at TEXT,
  initiated_by TEXT,
  note TEXT
);

CREATE TABLE IF NOT EXISTS raw_captures (
  capture_id TEXT PRIMARY KEY,
  run_id TEXT,
  source_table TEXT NOT NULL,
  source_id TEXT,
  source_url TEXT,
  content_type TEXT,
  payload_hash TEXT NOT NULL,
  raw_path TEXT NOT NULL,
  retrieved_at TEXT NOT NULL,
  published_at TEXT,
  collection_method TEXT,
  http_status INTEGER,
  note TEXT,
  FOREIGN KEY (run_id) REFERENCES ingest_runs (run_id),
  UNIQUE (payload_hash, raw_path)
);

CREATE INDEX IF NOT EXISTS idx_municipalities_fire_centre ON municipalities (fire_centre_id);
CREATE INDEX IF NOT EXISTS idx_actors_fire_centre ON actors (fire_centre_id);
CREATE INDEX IF NOT EXISTS idx_actors_municipality ON actors (municipality_id);
CREATE INDEX IF NOT EXISTS idx_actor_accounts_actor ON actor_accounts (actor_id);
CREATE INDEX IF NOT EXISTS idx_actor_evidence_actor ON actor_evidence (actor_id);
CREATE INDEX IF NOT EXISTS idx_discovery_leads_actor ON discovery_leads (actor_id);
CREATE INDEX IF NOT EXISTS idx_discourse_sources_actor ON discourse_sources (actor_id);
CREATE INDEX IF NOT EXISTS idx_public_communities_municipality ON public_communities (municipality_id);
CREATE INDEX IF NOT EXISTS idx_monitoring_subscriptions_enabled ON monitoring_subscriptions (is_enabled);
CREATE INDEX IF NOT EXISTS idx_raw_captures_run ON raw_captures (run_id);
