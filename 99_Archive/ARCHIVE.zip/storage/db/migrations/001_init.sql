CREATE TABLE IF NOT EXISTS ingestion_runs (
  run_id TEXT PRIMARY KEY,
  lane TEXT NOT NULL,
  source_family TEXT NOT NULL,
  status TEXT NOT NULL,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  note TEXT
);

CREATE TABLE IF NOT EXISTS incident_versions (
  version_id INTEGER PRIMARY KEY AUTOINCREMENT,
  incident_number TEXT NOT NULL,
  fire_year INTEGER,
  collected_at TEXT NOT NULL,
  source_url TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  stage_of_control TEXT,
  incident_name TEXT,
  incident_location TEXT,
  discovered_at TEXT,
  last_updated_ts INTEGER,
  raw_path TEXT NOT NULL,
  UNIQUE(incident_number, fire_year, payload_hash)
);

CREATE TABLE IF NOT EXISTS incident_attachments (
  attachment_id INTEGER PRIMARY KEY AUTOINCREMENT,
  incident_number TEXT NOT NULL,
  fire_year INTEGER,
  collected_at TEXT NOT NULL,
  source_url TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  raw_path TEXT NOT NULL,
  UNIQUE(incident_number, fire_year, payload_hash)
);

CREATE TABLE IF NOT EXISTS incident_external_uris (
  external_id INTEGER PRIMARY KEY AUTOINCREMENT,
  incident_number TEXT NOT NULL,
  fire_year INTEGER,
  collected_at TEXT NOT NULL,
  source_url TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  raw_path TEXT NOT NULL,
  UNIQUE(incident_number, fire_year, payload_hash)
);

CREATE TABLE IF NOT EXISTS source_snapshots (
  snapshot_id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id TEXT,
  domain TEXT,
  collected_at TEXT NOT NULL,
  source_url TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  raw_path TEXT NOT NULL,
  note TEXT
);
