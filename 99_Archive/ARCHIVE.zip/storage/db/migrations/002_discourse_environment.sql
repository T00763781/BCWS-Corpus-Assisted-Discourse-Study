CREATE TABLE IF NOT EXISTS discourse_items_raw (
  discourse_raw_id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id TEXT,
  collected_at TEXT NOT NULL,
  source_url TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  content_type TEXT,
  raw_path TEXT NOT NULL,
  identity_rule TEXT,
  note TEXT,
  UNIQUE(source_url, payload_hash)
);

CREATE TABLE IF NOT EXISTS discourse_items_normalized (
  discourse_item_id INTEGER PRIMARY KEY AUTOINCREMENT,
  discourse_raw_id INTEGER NOT NULL,
  platform TEXT,
  published_at TEXT,
  title TEXT,
  body_excerpt TEXT,
  author_label TEXT,
  author_is_obfuscated INTEGER DEFAULT 0,
  incident_number TEXT,
  topic_key TEXT,
  narrative_key TEXT,
  FOREIGN KEY(discourse_raw_id) REFERENCES discourse_items_raw(discourse_raw_id)
);

CREATE TABLE IF NOT EXISTS environment_snapshots (
  environment_snapshot_id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id TEXT,
  family TEXT,
  collected_at TEXT NOT NULL,
  source_url TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  raw_path TEXT NOT NULL,
  note TEXT,
  UNIQUE(source_url, payload_hash)
);
