﻿# Open Fireside Repo Snapshot

- Root: G:\04_Dev-Tools\01_Tools\01_OpenFireside
- Generated: 2026-03-11 02:13:13

## Top-level items

- [DIR ] .codex | Created: 03/10/2026 14:17:56 | Modified: 03/10/2026 14:17:56
- [FILE] .editorconfig | Created: 03/10/2026 19:30:24 | Modified: 03/10/2026 19:30:24
- [FILE] .gitignore | Created: 03/10/2026 19:53:32 | Modified: 03/10/2026 19:53:32
- [DIR ] _repo_audit_2026-03-11_013719 | Created: 03/11/2026 01:37:19 | Modified: 03/11/2026 02:04:10
- [DIR ] _repo_audit_2026-03-11_021313 | Created: 03/11/2026 02:13:13 | Modified: 03/11/2026 02:13:13
- [DIR ] agents | Created: 03/11/2026 01:18:19 | Modified: 03/11/2026 01:18:19
- [FILE] AGENTS.md | Created: 03/10/2026 19:53:32 | Modified: 03/10/2026 19:53:32
- [DIR ] app | Created: 03/10/2026 14:17:56 | Modified: 03/10/2026 14:17:56
- [DIR ] dist | Created: 03/10/2026 14:17:56 | Modified: 03/10/2026 14:17:56
- [DIR ] docs | Created: 03/10/2026 14:17:56 | Modified: 03/11/2026 01:43:33
- [DIR ] logs | Created: 03/11/2026 02:03:16 | Modified: 03/11/2026 02:03:16
- [DIR ] open_fireside_universe_seed | Created: 03/11/2026 00:15:08 | Modified: 03/11/2026 01:05:17
- [FILE] README.md | Created: 03/10/2026 19:53:32 | Modified: 03/10/2026 19:53:32
- [DIR ] recon | Created: 03/10/2026 14:17:56 | Modified: 03/10/2026 14:17:57
- [DIR ] registry | Created: 03/10/2026 14:17:57 | Modified: 03/11/2026 01:18:34
- [FILE] requirements.txt | Created: 03/10/2026 19:53:32 | Modified: 03/10/2026 19:53:32
- [DIR ] reviews | Created: 03/10/2026 14:17:57 | Modified: 03/10/2026 14:17:57
- [DIR ] scripts | Created: 03/10/2026 14:17:57 | Modified: 03/10/2026 14:17:57
- [DIR ] seed | Created: 03/11/2026 01:11:52 | Modified: 03/11/2026 01:12:25
- [FILE] seed.zip | Created: 03/11/2026 01:12:20 | Modified: 03/11/2026 00:19:28
- [DIR ] storage | Created: 03/10/2026 14:17:57 | Modified: 03/10/2026 14:17:57
- [DIR ] tests | Created: 03/10/2026 14:17:57 | Modified: 03/10/2026 14:17:57
- [DIR ] tmp | Created: 03/11/2026 02:03:20 | Modified: 03/11/2026 02:03:20
- [DIR ] tools | Created: 03/10/2026 14:17:57 | Modified: 03/10/2026 14:17:57
- [DIR ] workers | Created: 03/10/2026 14:17:57 | Modified: 03/10/2026 14:17:58

## Output files

- tree.txt
- files_with_times.csv
- top_level.csv
- repo_snapshot.md
