# Open Fireside development monorepo — Codex-ready handoff

This repo is the private development control plane and tool workspace for **Open Fireside**.
It is designed to be truthful enough for Codex to operate inside without inventing the project’s shape, methodology, audience, or purpose.

## What this package is for
- give Codex a truthful repo map,
- seed the registry with the current recon evidence,
- codify methodology, privacy, and defensibility expectations,
- provide real collector and storage starting points,
- force lane-by-lane review rather than unconstrained build drift,
- preserve enough project context that downstream outputs remain credible to skeptical external audiences.

## Primary development story
Open Fireside is not a publishing tool.
It is a private, local-first research platform for collecting, preserving, linking, and analyzing publicly accessible wildfire information across three main lanes:
- discourse / actors,
- incidents,
- environment.

The desktop UI comes later and only grows once a lane can already fetch and save real data.

## What is live right now
- seeded registry files under `registry/master/`
- recon evidence under `recon/raw/`
- derived seed tables under `recon/parsed/`
- BCWS incident collector with append/amend SQLite history writing
- source verifier that updates CSVs in place
- discourse registry quality checker
- official-site discourse collector for initial HTML/RSS/JSON capture
- environment snapshot collector for tabular/state sources
- ArcGIS metadata fetch helper
- review-pack builder with manifest generation
- identity obfuscation helper for private individuals in public discourse
- gate, lane, methodology, insight, and repo-truth docs for Codex
- registry schemas and dictionaries
- minimal C# contracts / read-model scaffolding for the future desktop app

## What is partial-live
- discourse registry and official-site ingestion tooling
- environment / map source contracts and fetch helpers
- WinUI shell skeleton and domain contracts

## What is still scaffold or stub
- WinUI 3 desktop shell is not yet wired to live data
- social/community discourse collectors are not yet production-grade
- environment family-specific collectors are not yet split into dedicated workers
- packaging scripts are dev-grade and intended for internal iteration, not public release

## Canonical repo areas
- canonical registry: `registry/master/`
- canonical methodology and lane doctrine: `docs/`
- canonical raw recon evidence: `recon/raw/`
- canonical seed derivations: `recon/parsed/`
- canonical DB contracts: `storage/db/migrations/`
- most mature worker lane: `workers/incidents/bcws/`

## First local steps
1. Read `AGENTS.md`.
2. Read `docs/autorun/operating-order.md`, `docs/autorun/lanes.yaml`, and `docs/repo-truth-matrix.md`.
3. Create a virtual environment and install `requirements.txt`.
4. Run `python tools/verify_targets.py registry/master/incident_sources.csv registry/master/environment_sources.csv registry/master/map_layers.csv registry/master/actor_targets.csv registry/master/actor_account_targets.csv registry/master/public_communities.csv registry/master/discourse_sources.csv`.
5. Run `python workers/discourse/registry/check_registry_quality.py registry/master/*.csv`.
6. Run `python workers/incidents/bcws/collect_bcws.py --db storage/db/local/open_fireside.sqlite --limit 5`.
7. Run `python workers/discourse/official_sites/collect_official_site.py --csv registry/master/discourse_sources.csv --limit 3 --db storage/db/local/open_fireside.sqlite`.
8. Run `python workers/environment/fetch_environment_snapshot.py --csv registry/master/environment_sources.csv --db storage/db/local/open_fireside.sqlite --limit 5`.
9. Run `python tools/db_inspect.py storage/db/local/open_fireside.sqlite --query "SELECT * FROM ingestion_runs ORDER BY started_at DESC LIMIT 10"`.
10. Build a review pack with `python tools/build_review_pack.py discourse D-G1 --summary reviews/discourse/D-G1/summary.md` once the registry review is ready.

## Development truthfulness
Use the staging labels exactly:
- live
- partial-live
- wired-no-data
- stub
- mock

Do not present a stub as live.

## Notable recon facts seeded into this repo
The current BCWS recon captured 778 request events, 753 response events, 361 unique URLs, 87 API candidates, 9 ArcGIS services, and 245 BCWS sources. The repo reflects those observations in the seed registry and recon summaries.
