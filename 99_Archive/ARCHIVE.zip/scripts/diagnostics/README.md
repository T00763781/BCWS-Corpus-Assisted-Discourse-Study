# Diagnostics

This area is present for future work. Treat it truthfully according to `docs/repo-truth-matrix.md`.
