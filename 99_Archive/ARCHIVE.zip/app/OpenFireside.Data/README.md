# OpenFireside.Data

Status: `wired-no-data`

This project should eventually hold query and path helpers for the desktop shell.
At present it only contains minimal helpers and should not be overbuilt.
