namespace OpenFireside.Data;

public static class DbPathResolver
{
    public static string DefaultLocalDbPath => "storage/db/local/open_fireside.sqlite";
    public static string DefaultRegistryRoot => "registry/master";
}
