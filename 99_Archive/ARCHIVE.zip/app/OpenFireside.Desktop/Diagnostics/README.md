# Diagnostics

Diagnostics should be visible early and should never be faked.
