# Open Fireside Desktop — AGENTS.md

This app folder is still a stub / wired-no-data shell.
Do not treat it as a mature operator surface.

## Current expectation
Use this space only for:
- preserving WinUI direction,
- creating truthful lane status surfaces,
- adding diagnostics and settings placeholders,
- wiring real data only after lane proofs exist.

## Never do
- imply the UI is live when it is not
- bury diagnostics or source status
- add decorative dashboard components without evidence value
