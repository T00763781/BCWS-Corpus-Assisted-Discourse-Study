using Microsoft.UI.Xaml;

namespace OpenFireside.Desktop;

public sealed partial class MainWindow : Window
{
    public MainWindow()
    {
        this.InitializeComponent();
    }
}
