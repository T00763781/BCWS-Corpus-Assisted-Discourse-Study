# OpenFireside.Desktop

Status: `stub`

This is a truthful shell for the future WinUI desktop app.
It exists to preserve platform direction and make room for lane-aware inspection surfaces later.
Do not treat it as an active operator interface yet.
