# OpenFireside.Contracts

Status: `wired-no-data`

This project holds small shared types that the future desktop shell, data layer, and read models can all use.
