namespace OpenFireside.Contracts;

public sealed class SourceRecord
{
    public string TargetId { get; init; } = string.Empty;
    public string Domain { get; init; } = string.Empty;
    public string TargetName { get; init; } = string.Empty;
    public string VerificationStatus { get; init; } = string.Empty;
    public string UrlOrEndpoint { get; init; } = string.Empty;
    public string Notes { get; init; } = string.Empty;
}
