namespace OpenFireside.Contracts;
public enum StagingStatus
{
    Live,
    PartialLive,
    WiredNoData,
    Stub,
    Mock
}
