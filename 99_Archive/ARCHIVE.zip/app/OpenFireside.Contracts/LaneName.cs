namespace OpenFireside.Contracts;
public enum LaneName
{
    Discourse,
    Incidents,
    Environment,
    Ui
}
