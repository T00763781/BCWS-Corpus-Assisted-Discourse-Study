# OpenFireside.Tests

Status: `stub`

Desktop test coverage should grow only after the shell is linked to real read models.
