# OpenFireside.ReadModels

Status: `wired-no-data`

This project holds starter read models that should later reflect real lane status and source state.
