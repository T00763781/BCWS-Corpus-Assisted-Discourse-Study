using OpenFireside.Contracts;

namespace OpenFireside.ReadModels;

public sealed class LaneStatusReadModel
{
    public LaneName Lane { get; init; }
    public StagingStatus StagingStatus { get; init; }
    public string ActiveGate { get; init; } = string.Empty;
    public string Notes { get; init; } = string.Empty;
    public bool HumanApprovalRequired { get; init; }
}
