# Codex boot note

Use:
- agents/agent_contract.yaml
- registry/ops/universe_registry_orchestration.yaml

as the control plane.

The intended execution pattern is:
1. one agent per fire centre
2. provincewide support agents
3. fire-centre expansion before pipeline proof
4. resolved direct URLs only in actor_account_targets.csv
5. unresolved leads only in actor_account_discovery_queue.csv
6. evidence rows in actor_osint_evidence.csv