import json
from pathlib import Path
import unittest

BASE = Path(__file__).resolve().parents[2]
FIXTURE = json.loads((BASE / 'fixtures/minimal/minimal_fixture.json').read_text())

class FixtureIntegrityTest(unittest.TestCase):
    def test_required_objects_exist(self):
        for key in ['fire_centre','locality','source_surface','actor','actor_account','incident','event_cluster','protected_private_entity','protected_private_account','discourse_thread','discourse_item','entity_link','redaction_policy']:
            self.assertIn(key, FIXTURE)

    def test_ids_are_distinct_across_public_and_protected_entities(self):
        self.assertNotEqual(FIXTURE['actor']['actor_id'], FIXTURE['protected_private_entity']['protected_entity_id'])
        self.assertNotEqual(FIXTURE['actor_account']['actor_account_id'], FIXTURE['protected_private_account']['protected_account_id'])

    def test_fixture_links_backbone_to_gui_lenses(self):
        self.assertEqual(FIXTURE['incident']['fire_centre_id'], FIXTURE['fire_centre']['fire_centre_id'])
        self.assertEqual(FIXTURE['actor_account']['actor_id'], FIXTURE['actor']['actor_id'])
        self.assertEqual(FIXTURE['discourse_item']['actor_account_id'], FIXTURE['actor_account']['actor_account_id'])

if __name__ == '__main__':
    unittest.main()
