from __future__ import annotations

import json
from pathlib import Path
import unittest

from ingest.adapters.account_adapter import AccountAdapter
from ingest.adapters.actor_adapter import ActorAdapter
from ingest.adapters.discourse_evidence_adapter import DiscourseEvidenceAdapter
from ingest.adapters.incident_event_adapter import IncidentEventAdapter
from ingest.adapters.protected_continuity_adapter import ProtectedContinuityAdapter

BASE = Path(__file__).resolve().parents[2]
CONTRACTS = BASE / 'schema' / 'contracts'


def required_fields(contract_name: str) -> set[str]:
    contract = json.loads((CONTRACTS / contract_name).read_text())
    return set(contract['required'])


class AdapterParityTest(unittest.TestCase):
    def test_actor_adapter_required_keys(self):
        payload = ActorAdapter().normalize({
            'canonical_actor_name': 'Town of Example',
            'actor_type': 'AGENCY',
            'provenance_note': 'verified official municipal website',
        })
        self.assertTrue(required_fields('normalized_actor_record.schema.json').issubset(payload.keys()))

    def test_account_adapter_required_keys(self):
        payload = AccountAdapter().normalize({
            'actor_id': '11111111-1111-1111-1111-111111111111',
            'platform': 'WEBSITE',
            'account_handle': 'example.gov.bc.ca',
        })
        self.assertTrue(required_fields('normalized_account_record.schema.json').issubset(payload.keys()))

    def test_discourse_adapter_required_keys(self):
        payload = DiscourseEvidenceAdapter().normalize({
            'source_surface_id': '22222222-2222-2222-2222-222222222222',
            'external_item_id': 'post-1',
            'content_text': 'Example content',
            'privacy_classification': 'PUBLIC',
            'actor_account_id': '33333333-3333-3333-3333-333333333333',
        })
        self.assertTrue(required_fields('normalized_discourse_record.schema.json').issubset(payload.keys()))

    def test_incident_adapter_required_keys(self):
        payload = IncidentEventAdapter().normalize_incident({
            'incident_number': 'N10123',
            'incident_name': 'Example Fire',
            'fire_centre_id': '44444444-4444-4444-4444-444444444444',
            'incident_start_date': '2025-07-01',
            'provenance_note': 'official incident source',
        })
        self.assertTrue(required_fields('normalized_incident_record.schema.json').issubset(payload.keys()))

    def test_protected_adapter_required_keys(self):
        payload = ProtectedContinuityAdapter().normalize({
            'continuity_public_id': 'pc-001',
            'restricted_display_name': 'Protected Contact A',
            'provenance_note': 'verified protected continuity record',
        })
        self.assertTrue(required_fields('normalized_protected_continuity_record.schema.json').issubset(payload.keys()))

if __name__ == '__main__':
    unittest.main()
