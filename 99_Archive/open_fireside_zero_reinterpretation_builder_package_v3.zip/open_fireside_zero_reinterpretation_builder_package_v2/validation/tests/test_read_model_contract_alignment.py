from pathlib import Path
import json
import unittest

BASE = Path(__file__).resolve().parents[2]
SQL = (BASE / 'schema/sql/050_read_model_views.sql').read_text()
INCIDENT_DOC = (BASE / 'app/read_models/incident_detail_contract.md').read_text()
LOCALITY_DOC = (BASE / 'app/read_models/locality_comparison_contract.md').read_text()
INCIDENT_SCHEMA = json.loads((BASE / 'schema/contracts/read_model_incident_detail.schema.json').read_text())
LOCALITY_SCHEMA = json.loads((BASE / 'schema/contracts/read_model_locality_comparison.schema.json').read_text())

class ReadModelAlignmentTest(unittest.TestCase):
    def test_incident_contract_is_not_pointer_stub(self):
        self.assertGreater(len(INCIDENT_DOC), 300)
        self.assertIn('incident_detail_view', INCIDENT_DOC)

    def test_locality_contract_is_not_pointer_stub(self):
        self.assertGreater(len(LOCALITY_DOC), 300)
        self.assertIn('locality_comparison_view', LOCALITY_DOC)

    def test_sql_mentions_required_incident_fields(self):
        for token in ['incident_detail_view', 'fire_centre', 'localities', 'public_actors', 'discourse_item_count', 'validation_flags']:
            self.assertIn(token, SQL)
        for field in INCIDENT_SCHEMA['required']:
            self.assertIn(field, {'incident_id','canonical_incident_number','canonical_incident_name','fire_centre','localities','public_actors','discourse_item_count','validation_flags'})

    def test_sql_mentions_required_locality_fields(self):
        for token in ['locality_comparison_view', 'verification_status', 'verified_public_actor_count', 'verified_public_account_count']:
            self.assertIn(token, SQL)
        for field in LOCALITY_SCHEMA['required']:
            self.assertIn(field, {'locality_id','canonical_locality_name','fire_centre','structural_coverage_status','evidence_coverage_status','linked_incident_count','verified_public_actor_count','verified_public_account_count','verification_status'})

if __name__ == '__main__':
    unittest.main()
