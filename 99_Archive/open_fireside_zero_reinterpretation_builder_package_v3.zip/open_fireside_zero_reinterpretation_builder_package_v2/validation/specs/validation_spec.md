# Validation Specification

Validation is run in four layers:
1. reference integrity and scope locking
2. fixture and ontology boundary integrity
3. adapter/read-model parity
4. phasing and governance integrity

A package is not considered build-ready unless all Python validations pass and SQL assertions pass when a database is supplied.
