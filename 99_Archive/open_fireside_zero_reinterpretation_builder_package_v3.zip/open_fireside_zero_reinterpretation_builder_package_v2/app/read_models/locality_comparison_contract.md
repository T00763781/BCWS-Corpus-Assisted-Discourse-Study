# Locality Comparison Read Model Contract

## Purpose
Provide the canonical locality-centric comparison surface used to compare structural coverage, evidence coverage, incident linkage, and actor/account verification progress across municipalities/localities.

## Backing objects
- SQL view: `locality_comparison_view`
- Contract: `schema/contracts/read_model_locality_comparison.schema.json`

## Output semantics
Each row represents one canonical Phase A locality and contains:
- locality identity and fire-centre identity
- structural coverage status
- evidence coverage status
- linked incident count
- verified public actor count
- verified public account count
- last verification status marker for OSINT readiness

## Governance rules
- the view is public-role oriented and must not leak protected private identities
- locality comparison is intended to reveal backlog and verification coverage, not to infer sensitive individuals
