# Incident Detail Read Model Contract

## Purpose
Provide the canonical incident-centric read model that powers the incident detail GUI tab. The tab is a synthesis surface, not a source of truth; every field must trace back to core tables.

## Backing object
- SQL view: `incident_detail_view`
- Contract: `schema/contracts/read_model_incident_detail.schema.json`

## Output semantics
Each row represents one incident and contains:
- incident identity fields
- nested fire-centre object
- nested event-cluster object when linked
- ordered locality summary array
- ordered public actor summary array
- discourse item count
- validation flags array

## Population rules
- `fire_centre` comes from `incidents.fire_centre_id -> fire_centres`
- `event_cluster` comes from `incident_event_cluster_links`; if multiple clusters exist, select the highest-confidence link then the lexical cluster name as tiebreaker
- `localities` are aggregated from `incident_locality_links -> localities`, ordered by locality name
- `public_actors` are actors linked through public actor accounts that authored discourse items attached to the incident's source surfaces
- `validation_flags` is derived from missing or weak supporting evidence, not from analyst commentary

## Privacy rules
- protected private entities and accounts must never appear in this view
- discourse counts may reflect protected discourse indirectly, but no protected identifiers may surface
