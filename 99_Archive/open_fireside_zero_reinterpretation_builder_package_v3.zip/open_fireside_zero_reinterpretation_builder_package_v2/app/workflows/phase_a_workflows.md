# Phase A Historical Workflows

Phase A covers the historical reconstruction window **2025-04-01 through 2026-03-31**. Real-time automation, continuous polling, and live trigger processing are **deferred** until Phase B.

## Workflow 1 — Bootstrap canonical environment
### Preconditions
- PostgreSQL 16+ database exists
- SQL files under `schema/sql/` have been applied in order
- builder has access to the reference CSVs bundled with the package

### Steps
1. Load reference datasets
2. Run reference integrity validation
3. Load minimal ontology fixture set
4. Run package validations

### Output
A stable canonical backbone with reference populations, seed ontology rows, and passing package checks.

## Workflow 2 — OSINT verification queue build
### Goal
Transform canonical municipalities/localities and selected external communities into queued verification targets for public actors and public actor accounts.

### Steps
1. Start from the canonical reference populations only
2. Derive expected public-role targets by locality type and governance context
3. Verify the presence of official municipal/agency websites and official social accounts
4. Record verification evidence and provenance notes
5. Emit normalized actor and actor-account records for ingestion

### Required outputs
- verified public actor records
- verified actor account records
- provenance notes tied to source surfaces
- locality verification status updates for the GUI comparison view

## Workflow 3 — Historical ingestion replay
### Scope
- incidents
- event clusters
- public actors and public actor accounts
- protected continuity entities and protected accounts
- discourse evidence
- linkage outputs

### Validation gates
- no public/protected ontology collapse
- all normalized records satisfy their JSON contracts
- all linkage records include confidence and provenance

## Workflow 4 — Read-model materialization and export review
1. Refresh read-model views
2. Review locality comparison coverage
3. Review incident detail coverage
4. Apply governance-aware export policy before any export job is released
