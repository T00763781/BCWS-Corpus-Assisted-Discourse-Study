CREATE TABLE discourse_threads (
    discourse_thread_id uuid PRIMARY KEY,
    source_surface_id uuid NOT NULL REFERENCES source_surfaces(source_surface_id),
    platform account_platform NOT NULL,
    external_thread_id text NOT NULL,
    thread_url text,
    created_at_source timestamptz,
    ingested_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (platform, external_thread_id)
);

CREATE TABLE discourse_items (
    discourse_item_id uuid PRIMARY KEY,
    discourse_thread_id uuid REFERENCES discourse_threads(discourse_thread_id) ON DELETE CASCADE,
    discourse_item_type discourse_item_type NOT NULL,
    source_surface_id uuid NOT NULL REFERENCES source_surfaces(source_surface_id),
    actor_account_id uuid REFERENCES actor_accounts(actor_account_id),
    protected_account_id uuid REFERENCES protected_private_accounts(protected_account_id),
    external_item_id text NOT NULL,
    content_text text NOT NULL,
    content_language text NOT NULL DEFAULT 'en',
    created_at_source timestamptz,
    ingested_at timestamptz NOT NULL DEFAULT now(),
    privacy_classification privacy_classification NOT NULL DEFAULT 'PUBLIC',
    CHECK ((actor_account_id IS NOT NULL) <> (protected_account_id IS NOT NULL)),
    UNIQUE (source_surface_id, external_item_id)
);

CREATE TABLE discourse_media (
    discourse_media_id uuid PRIMARY KEY,
    discourse_item_id uuid NOT NULL REFERENCES discourse_items(discourse_item_id) ON DELETE CASCADE,
    media_url text NOT NULL,
    media_type text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE discourse_classifications (
    discourse_classification_id uuid PRIMARY KEY,
    discourse_item_id uuid NOT NULL REFERENCES discourse_items(discourse_item_id) ON DELETE CASCADE,
    classification_label text NOT NULL,
    classification_value text NOT NULL,
    classifier_name text NOT NULL,
    confidence numeric(4,3),
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (confidence IS NULL OR (confidence >= 0.000 AND confidence <= 1.000))
);

CREATE TABLE entity_links (
    entity_link_id uuid PRIMARY KEY,
    source_entity_type link_target_type NOT NULL,
    source_entity_id uuid NOT NULL,
    target_entity_type link_target_type NOT NULL,
    target_entity_id uuid NOT NULL,
    link_confidence numeric(4,3) NOT NULL,
    provenance_note text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (link_confidence >= 0.000 AND link_confidence <= 1.000)
);
