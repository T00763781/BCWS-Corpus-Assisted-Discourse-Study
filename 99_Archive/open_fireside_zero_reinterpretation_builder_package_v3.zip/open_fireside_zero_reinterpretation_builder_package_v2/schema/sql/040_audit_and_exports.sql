CREATE TABLE validation_runs (
    validation_run_id uuid PRIMARY KEY,
    run_started_at timestamptz NOT NULL,
    run_finished_at timestamptz,
    run_status text NOT NULL,
    summary_json jsonb NOT NULL
);

CREATE TABLE analysis_runs (
    analysis_run_id uuid PRIMARY KEY,
    run_name text NOT NULL,
    run_started_at timestamptz NOT NULL,
    run_finished_at timestamptz,
    parameters_json jsonb NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE redaction_policies (
    redaction_policy_id uuid PRIMARY KEY,
    policy_name text NOT NULL UNIQUE,
    suppress_protected_handles boolean NOT NULL,
    suppress_small_n boolean NOT NULL,
    small_n_threshold integer NOT NULL,
    policy_json jsonb NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CHECK (small_n_threshold >= 1)
);

CREATE TABLE export_jobs (
    export_job_id uuid PRIMARY KEY,
    redaction_policy_id uuid NOT NULL REFERENCES redaction_policies(redaction_policy_id),
    export_name text NOT NULL,
    export_scope text NOT NULL,
    export_status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    exported_at timestamptz
);

CREATE TABLE export_audit_events (
    export_audit_event_id uuid PRIMARY KEY,
    export_job_id uuid NOT NULL REFERENCES export_jobs(export_job_id) ON DELETE CASCADE,
    event_type text NOT NULL,
    event_detail jsonb NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
