CREATE OR REPLACE VIEW incident_detail_view AS
SELECT
    i.incident_id,
    i.canonical_incident_number,
    i.canonical_incident_name,
    i.incident_start_date,
    i.incident_end_date,
    i.stage_of_control,
    i.cause_category,
    jsonb_build_object(
        'fire_centre_id', fc.fire_centre_id,
        'fire_centre_name', fc.fire_centre_name
    ) AS fire_centre,
    (
        SELECT jsonb_build_object(
            'event_cluster_id', ec.event_cluster_id,
            'canonical_event_cluster_name', ec.canonical_event_cluster_name
        )
        FROM incident_event_cluster_links iecl
        JOIN event_clusters ec ON ec.event_cluster_id = iecl.event_cluster_id
        WHERE iecl.incident_id = i.incident_id
        ORDER BY iecl.link_confidence DESC, ec.canonical_event_cluster_name ASC
        LIMIT 1
    ) AS event_cluster,
    COALESCE((
        SELECT jsonb_agg(jsonb_build_object(
            'locality_id', l.locality_id,
            'canonical_locality_name', l.canonical_locality_name,
            'structural_coverage_status', l.structural_coverage_status,
            'evidence_coverage_status', l.evidence_coverage_status
        ) ORDER BY l.canonical_locality_name)
        FROM incident_locality_links ill
        JOIN localities l ON l.locality_id = ill.locality_id
        WHERE ill.incident_id = i.incident_id
    ), '[]'::jsonb) AS localities,
    COALESCE((
        SELECT jsonb_agg(DISTINCT jsonb_build_object(
            'actor_id', a.actor_id,
            'canonical_actor_name', a.canonical_actor_name
        ))
        FROM discourse_items di
        JOIN actor_accounts aa ON aa.actor_account_id = di.actor_account_id
        JOIN actors a ON a.actor_id = aa.actor_id
        WHERE di.source_surface_id = i.source_surface_id
    ), '[]'::jsonb) AS public_actors,
    COALESCE((SELECT count(*) FROM discourse_items di WHERE di.source_surface_id = i.source_surface_id), 0) AS discourse_item_count,
    ARRAY[
        CASE WHEN i.source_surface_id IS NULL THEN 'MISSING_SOURCE_SURFACE' END,
        CASE WHEN NOT EXISTS (SELECT 1 FROM incident_locality_links ill WHERE ill.incident_id = i.incident_id) THEN 'NO_LOCALITY_LINK' END
    ]::text[] AS validation_flags
FROM incidents i
JOIN fire_centres fc ON fc.fire_centre_id = i.fire_centre_id;

CREATE OR REPLACE VIEW locality_comparison_view AS
SELECT
    l.locality_id,
    l.canonical_locality_name,
    jsonb_build_object(
        'fire_centre_id', fc.fire_centre_id,
        'fire_centre_name', fc.fire_centre_name
    ) AS fire_centre,
    l.structural_coverage_status,
    l.evidence_coverage_status,
    COUNT(DISTINCT ill.incident_id) AS linked_incident_count,
    COUNT(DISTINCT a.actor_id) AS verified_public_actor_count,
    COUNT(DISTINCT aa.actor_account_id) AS verified_public_account_count,
    CASE
        WHEN COUNT(DISTINCT aa.actor_account_id) > 0 THEN 'VERIFIED_ACCOUNT_PRESENT'
        WHEN COUNT(DISTINCT a.actor_id) > 0 THEN 'VERIFIED_ACTOR_PRESENT'
        ELSE 'NOT_VERIFIED'
    END AS verification_status
FROM localities l
JOIN fire_centres fc ON fc.fire_centre_id = l.fire_centre_id
LEFT JOIN incident_locality_links ill ON ill.locality_id = l.locality_id
LEFT JOIN actors a ON a.canonical_actor_name = l.canonical_locality_name
LEFT JOIN actor_accounts aa ON aa.actor_id = a.actor_id AND aa.is_verified = true
GROUP BY l.locality_id, fc.fire_centre_id, fc.fire_centre_name;
