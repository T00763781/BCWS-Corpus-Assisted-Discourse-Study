# Entity Dictionary

Public actors are distinct from protected private continuity entities. Actor accounts are distinct from protected private accounts. Structural coverage is distinct from evidence coverage.

This dictionary is field-level for the runtime tables and the reference/validation tables that control scope.

## fire_centres
- `fire_centre_id` uuid, PK, non-null, deterministic runtime identifier
- `fire_centre_code` text, unique, non-null, compact regional code
- `fire_centre_name` text, unique, non-null, canonical display name
- `province_code` text, non-null, expected `BC`
- `geometry_wkt` text, nullable, optional geometry placeholder
- `centroid_lat`/`centroid_lon` numeric, nullable pair, must be both null or both populated

## localities
- `locality_id` uuid, PK
- `canonical_locality_name` text, non-null, canonical place name
- `municipality_name` text, nullable, mirrors canonical name for municipalities
- `province_code` text, non-null
- `country_code` text, non-null
- `fire_centre_id` uuid, FK to `fire_centres`, nullable during pre-overlay staging but expected by runtime completeness workflows
- `structural_coverage_status` coverage_status, non-null
- `evidence_coverage_status` coverage_status, non-null
- `geometry_wkt` text, nullable
- `centroid_lat`/`centroid_lon` numeric, nullable

## source_surfaces
- `source_surface_id` uuid, PK
- `canonical_source_name` text, unique, non-null
- `source_surface_type` source_surface_type, non-null
- `base_url` text, non-null
- `provenance_rule` text, non-null
- `privacy_classification` privacy_classification, non-null, default `PUBLIC`

## actors
- `actor_id` uuid, PK
- `canonical_actor_name` text, unique, non-null
- `actor_type` actor_type, non-null
- `is_public_role` boolean, non-null
- `source_surface_id` uuid, FK to `source_surfaces`, nullable
- `provenance_note` text, non-null

## actor_accounts
- `actor_account_id` uuid, PK
- `actor_id` uuid, FK to `actors`, non-null
- `platform` account_platform, non-null
- `account_handle` text, non-null
- `account_url` text, nullable
- `is_verified` boolean, non-null
- `source_surface_id` uuid, FK to `source_surfaces`, nullable

## incidents
- `incident_id` uuid, PK
- `canonical_incident_number` text, unique, non-null
- `canonical_incident_name` text, non-null
- `fire_centre_id` uuid, FK to `fire_centres`, non-null
- `incident_start_date` date, non-null
- `incident_end_date` date, nullable, must be >= start date
- `stage_of_control` text, nullable
- `cause_category` text, nullable
- `centroid_lat`/`centroid_lon` numeric, nullable
- `geometry_wkt` text, nullable
- `source_surface_id` uuid, FK, nullable
- `provenance_note` text, non-null

## event_clusters
- `event_cluster_id` uuid, PK
- `canonical_event_cluster_name` text, unique, non-null
- `event_start_date` date, non-null
- `event_end_date` date, nullable
- `cross_jurisdiction_flag` boolean, non-null
- `provenance_note` text, non-null

## incident_event_cluster_links
- composite PK (`incident_id`, `event_cluster_id`)
- `link_confidence` numeric(4,3), non-null, 0..1
- `provenance_note` text, non-null

## incident_locality_links
- composite PK (`incident_id`, `locality_id`)
- `link_confidence` numeric(4,3), non-null, 0..1
- `provenance_note` text, non-null

## protected_private_entities
- `protected_entity_id` uuid, PK
- `continuity_public_id` text, unique, non-null
- `restricted_display_name` text, non-null
- `identity_hash` text, unique, non-null
- `privacy_classification` privacy_classification, non-null, fixed to `PROTECTED_PRIVATE`
- `provenance_note` text, non-null

## protected_private_accounts
- `protected_account_id` uuid, PK
- `protected_entity_id` uuid, FK, non-null
- `platform` account_platform, non-null
- `restricted_account_handle` text, non-null
- `handle_hash` text, unique, non-null
- `source_surface_id` uuid, FK, nullable

## protected_context_links
- `protected_context_link_id` uuid, PK
- exactly one of `protected_entity_id` or `protected_account_id` must be present
- `target_type` link_target_type, non-null
- `target_id` uuid, non-null
- `link_confidence` numeric(4,3), non-null
- `provenance_note` text, non-null

## discourse_threads
- `discourse_thread_id` uuid, PK
- `source_surface_id` uuid, FK, non-null
- `platform` account_platform, non-null
- `external_thread_id` text, non-null
- `thread_url` text, nullable
- `created_at_source` timestamptz, nullable
- `ingested_at` timestamptz, non-null

## discourse_items
- `discourse_item_id` uuid, PK
- `discourse_thread_id` uuid, FK, nullable
- `discourse_item_type` discourse_item_type, non-null
- `source_surface_id` uuid, FK, non-null
- exactly one of `actor_account_id` or `protected_account_id` must be present when authored attribution is known
- `external_item_id` text, non-null
- `content_text` text, non-null
- `content_language` text, non-null
- `created_at_source` timestamptz, nullable
- `privacy_classification` privacy_classification, non-null

## discourse_media
- `discourse_media_id` uuid, PK
- `discourse_item_id` uuid, FK, non-null
- `media_url` text, non-null
- `media_type` text, non-null

## discourse_classifications
- `discourse_classification_id` uuid, PK
- `discourse_item_id` uuid, FK, non-null
- `classification_label` text, non-null
- `classification_value` text, non-null
- `classifier_name` text, non-null
- `confidence` numeric(4,3), nullable

## entity_links
- `entity_link_id` uuid, PK
- `source_entity_type` link_target_type, non-null
- `source_entity_id` uuid, non-null
- `target_entity_type` link_target_type, non-null
- `target_entity_id` uuid, non-null
- `link_confidence` numeric(4,3), non-null
- `provenance_note` text, non-null

## validation_runs
- `validation_run_id` uuid, PK
- `run_started_at` timestamptz, non-null
- `run_finished_at` timestamptz, nullable
- `run_status` text, non-null
- `summary_json` jsonb, non-null

## analysis_runs
- `analysis_run_id` uuid, PK
- `run_name` text, non-null
- `run_started_at` timestamptz, non-null
- `run_finished_at` timestamptz, nullable
- `parameters_json` jsonb, non-null

## redaction_policies
- `redaction_policy_id` uuid, PK
- `policy_name` text, unique, non-null
- `suppress_protected_handles` boolean, non-null
- `suppress_small_n` boolean, non-null
- `small_n_threshold` integer, non-null, >= 1
- `policy_json` jsonb, non-null

## export_jobs
- `export_job_id` uuid, PK
- `redaction_policy_id` uuid, FK, non-null
- `export_name` text, non-null
- `export_scope` text, non-null
- `export_status` text, non-null

## reference_fire_centres / reference_localities / reference_external_communities / reference_event_clusters / phase_a_target_matrix
These tables mirror the CSV reference layer exactly. They are scope-control tables, not runtime evidence tables. Changes require synchronized edits to CSVs, policy, manifest, and validations.
