# Open Fireside Zero Reinterpretation Builder Package v3

Open Fireside is a historical-first wildfire research system for the 2025-04-01 through 2026-03-31 wildfire calendar year, with real-time operation explicitly deferred to Phase B starting on 2026-04-01. The database is the backbone, but not the whole product: it anchors the multiple GUI lenses and tabs, while the OSINT verification workflow turns canonical reference populations into verified actor and account targets that can be ingested without collapsing the public/protected ontology.

## Canonical implementation choices
- Database: PostgreSQL 16+
- Contract format: JSON Schema Draft 2020-12
- Test runner: Python 3.11 `unittest`
- ID strategy in reference adapters: UUIDv5 deterministic IDs derived from canonical names or stable source identifiers
- Phase A mode: historical reconstruction only
- Phase B mode: real-time acquisition, scheduling, and continuous validation (deferred until Phase A sign-off)

## What this package now contains
- Fixed reference populations for 6 BC fire centres, 161 B.C. municipalities, 13 external communities, and one canonical event-cluster seed
- Canonical SQL schema and read-model views
- Field-level entity dictionary and machine-readable contracts
- Minimal but working reference adapters that emit schema-compatible normalized records
- OSINT verification workflow documents that describe how municipalities are converted into verified actor/account targets before ingestion
- Reference, fixture, contract, ontology, privacy, phasing, adapter-parity, and read-model parity validations
- Bootstrap scripts for loading reference data and running validations

## Backbone principle
The database is the canonical backbone that connects GUI tabs and analytical lenses. It must remain stable across:
- incident detail views
- locality comparison views
- actor/account verification views
- discourse/evidence views
- governance/export views

Adapters and workflows exist to populate that backbone, not replace it.

## Bootstrap order
1. Apply SQL in lexical order under `schema/sql/`
2. Load reference datasets with `ops/bootstrap/load_reference_data.sh`
3. Load minimal ontology fixtures from `fixtures/minimal/minimal_fixture.sql`
4. Run package validations with `ops/bootstrap/run_all_validations.sh`
5. Only then begin Phase A historical ingestion replay and OSINT verification workflows

## Minimum acceptance gates
Phase A sign-off is blocked unless all of the following are true:
- every canonical reference population loads cleanly
- all package validations pass
- the historical window 2025-04-01 through 2026-03-31 is enforced throughout planning and workflow documents
- real-time automation remains explicitly deferred until Phase B on 2026-04-01
- OSINT verification outputs are represented as public actors and actor accounts, not mixed into protected private entities

## Known execution note
The package includes SQL smoke assertions and validation scripts. In this chat environment the Python tests can be run directly; PostgreSQL execution requires a live database provided by the builder.
