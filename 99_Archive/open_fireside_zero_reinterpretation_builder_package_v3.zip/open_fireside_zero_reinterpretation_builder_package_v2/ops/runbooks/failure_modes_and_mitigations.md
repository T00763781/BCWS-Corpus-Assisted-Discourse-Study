# Failure Modes and Mitigations

| Failure mode | Detection signal | Severity | Mitigation |
|---|---|---:|---|
| malformed reference CSV | reference integrity test fails | high | stop bootstrap, fix CSV shape, rerun load |
| policy/category mismatch | reference-policy validation fails | high | align CSV categorical values with `reference_layer_policy.md` |
| adapter/contract drift | adapter parity tests fail | high | update adapter output shape or contract in same change |
| read-model/view drift | read-model parity tests fail | medium | repair SQL view fields and matching contract docs |
| public/protected ontology collapse | ontology or privacy tests fail | critical | block ingest and inspect the offending adapter or export path |
| phase boundary drift | phase tests fail | medium | repair phasing docs before continuing implementation |
