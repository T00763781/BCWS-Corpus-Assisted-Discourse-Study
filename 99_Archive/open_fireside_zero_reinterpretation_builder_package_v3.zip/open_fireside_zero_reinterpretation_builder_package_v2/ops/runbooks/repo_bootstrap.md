# Repo Bootstrap Runbook

## Commands
1. `psql "$OPEN_FIRESIDE_DB_URL" -f schema/sql/001_extensions_and_types.sql`
2. Apply the remaining SQL files in lexical order
3. `ops/bootstrap/load_reference_data.sh`
4. `psql "$OPEN_FIRESIDE_DB_URL" -f fixtures/minimal/minimal_fixture.sql`
5. `ops/bootstrap/run_all_validations.sh`

## Expected result
- canonical reference rows present
- minimal ontology fixture loaded
- Python validations pass
- SQL assertions pass when a database is available
