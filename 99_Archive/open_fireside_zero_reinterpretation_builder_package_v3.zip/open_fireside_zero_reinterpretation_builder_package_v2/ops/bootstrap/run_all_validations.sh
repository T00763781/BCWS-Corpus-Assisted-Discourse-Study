#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT_DIR"

python -m unittest discover -s validation/tests -p 'test_*.py'

if [[ -n "${OPEN_FIRESIDE_DB_URL:-}" ]]; then
  psql "$OPEN_FIRESIDE_DB_URL" -v ON_ERROR_STOP=1 -f validation/tests/test_sql_assertions.sql
  echo "[OK] SQL assertions executed"
else
  echo "[INFO] OPEN_FIRESIDE_DB_URL not set; skipping SQL assertions"
fi
