#!/usr/bin/env bash
set -euo pipefail

: "${OPEN_FIRESIDE_DB_URL:?Set OPEN_FIRESIDE_DB_URL to a PostgreSQL connection string}"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
REF_DIR="$ROOT_DIR/reference"

for file in bc_fire_centres.csv bc_municipalities_or_localities.csv external_communities.csv event_clusters.csv phase_a_target_matrix.csv; do
  test -f "$REF_DIR/$file" || { echo "Missing reference file: $file" >&2; exit 1; }
done

psql "$OPEN_FIRESIDE_DB_URL" -v ON_ERROR_STOP=1 -c "\copy reference_fire_centres FROM '$REF_DIR/bc_fire_centres.csv' CSV HEADER"
psql "$OPEN_FIRESIDE_DB_URL" -v ON_ERROR_STOP=1 -c "\copy reference_localities FROM '$REF_DIR/bc_municipalities_or_localities.csv' CSV HEADER"
psql "$OPEN_FIRESIDE_DB_URL" -v ON_ERROR_STOP=1 -c "\copy reference_external_communities FROM '$REF_DIR/external_communities.csv' CSV HEADER"
psql "$OPEN_FIRESIDE_DB_URL" -v ON_ERROR_STOP=1 -c "\copy reference_event_clusters FROM '$REF_DIR/event_clusters.csv' CSV HEADER"
psql "$OPEN_FIRESIDE_DB_URL" -v ON_ERROR_STOP=1 -c "\copy phase_a_target_matrix FROM '$REF_DIR/phase_a_target_matrix.csv' CSV HEADER"

echo "[OK] loaded canonical reference datasets"
