# Adapter Interfaces

These interfaces are normative. The adapter output must satisfy the matching JSON Schema contract.

## Cross-cutting rules
- every normalized record must include deterministic or source-stable identifiers
- every emitted link must include `link_confidence` and `provenance_note`
- no adapter may emit fields not present in the canonical contract without updating the contract and tests in the same change

## LocalityFireCentreAdapter
- `load_fire_centres() -> list[dict]` returns fire-centre rows suitable for `fire_centres`
- `load_reference_places() -> list[dict]` returns locality/external-community reference rows suitable for locality staging
- `normalize_fire_centre(raw_record: dict) -> dict` must emit `fire_centre_id`, `fire_centre_code`, `fire_centre_name`, `province_code`
- `normalize_locality(raw_record: dict) -> dict` must emit `locality_id`, `canonical_locality_name`, `province_code`, `country_code`, structural/evidence coverage markers, and provenance
- `emit_links(normalized_record: dict) -> list[dict]` returns locality-to-fire-centre linkage records when available

## IncidentEventAdapter
- `normalize_incident(raw_record: dict) -> dict` -> `normalized_incident_record.schema.json`
- `normalize_event_cluster(raw_record: dict) -> dict` -> event cluster runtime table shape
- `emit_links(normalized_record: dict) -> list[dict]` -> incident/event cluster link rows

## ActorAdapter
- `normalize(raw_record: dict) -> dict` -> `normalized_actor_record.schema.json`
- intended input source: verified public-role OSINT output, not raw discourse discoveries

## AccountAdapter
- `normalize(raw_record: dict) -> dict` -> `normalized_account_record.schema.json`
- intended input source: verified official accounts tied to canonical actors

## DiscourseEvidenceAdapter
- `normalize(raw_record: dict) -> dict` -> `normalized_discourse_record.schema.json`
- exactly one of `actor_account_id` or `protected_account_id` must be present in valid downstream data

## ProtectedContinuityAdapter
- `normalize(raw_record: dict) -> dict` -> `normalized_protected_continuity_record.schema.json`
