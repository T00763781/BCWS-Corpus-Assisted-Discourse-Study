from __future__ import annotations

from uuid import UUID, uuid5, NAMESPACE_URL


def deterministic_uuid(*parts: str) -> str:
    token = '::'.join(str(p).strip() for p in parts if p is not None)
    return str(uuid5(NAMESPACE_URL, token))


def canonical_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {'1', 'true', 'yes', 'y'}


def require(raw: dict, key: str):
    if key not in raw or raw[key] in (None, ''):
        raise ValueError(f'missing required field: {key}')
    return raw[key]
