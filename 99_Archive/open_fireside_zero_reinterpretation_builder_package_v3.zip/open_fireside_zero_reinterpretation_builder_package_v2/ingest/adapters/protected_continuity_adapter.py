from __future__ import annotations

import hashlib

from .common import deterministic_uuid, require


class ProtectedContinuityAdapter:
    def normalize(self, raw_record: dict) -> dict:
        continuity_public_id = require(raw_record, 'continuity_public_id')
        restricted_display_name = require(raw_record, 'restricted_display_name')
        identity_material = raw_record.get('identity_hash_material', restricted_display_name)
        return {
            'protected_entity_id': raw_record.get('protected_entity_id') or deterministic_uuid('protected_entity', continuity_public_id),
            'continuity_public_id': continuity_public_id,
            'restricted_display_name': restricted_display_name,
            'identity_hash': raw_record.get('identity_hash') or hashlib.sha256(identity_material.encode('utf-8')).hexdigest(),
            'privacy_classification': 'PROTECTED_PRIVATE',
            'provenance_note': require(raw_record, 'provenance_note'),
        }
