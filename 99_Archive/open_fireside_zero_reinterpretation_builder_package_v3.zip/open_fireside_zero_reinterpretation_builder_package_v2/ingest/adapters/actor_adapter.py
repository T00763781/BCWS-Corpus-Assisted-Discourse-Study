from __future__ import annotations

from .common import deterministic_uuid, require


class ActorAdapter:
    def normalize(self, raw_record: dict) -> dict:
        canonical_actor_name = require(raw_record, 'canonical_actor_name')
        actor_type = require(raw_record, 'actor_type')
        return {
            'actor_id': raw_record.get('actor_id') or deterministic_uuid('actor', canonical_actor_name, actor_type),
            'canonical_actor_name': canonical_actor_name,
            'actor_type': actor_type,
            'is_public_role': bool(raw_record.get('is_public_role', True)),
            'source_surface_id': raw_record.get('source_surface_id'),
            'provenance_note': require(raw_record, 'provenance_note'),
        }
