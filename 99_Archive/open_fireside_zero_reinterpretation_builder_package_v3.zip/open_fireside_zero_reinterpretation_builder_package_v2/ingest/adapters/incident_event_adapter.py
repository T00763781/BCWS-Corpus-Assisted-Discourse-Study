from __future__ import annotations

from .common import deterministic_uuid, require


class IncidentEventAdapter:
    def normalize_incident(self, raw_record: dict) -> dict:
        incident_number = require(raw_record, 'incident_number')
        incident_name = require(raw_record, 'incident_name')
        fire_centre_id = require(raw_record, 'fire_centre_id')
        return {
            'incident_id': raw_record.get('incident_id') or deterministic_uuid('incident', incident_number),
            'canonical_incident_number': incident_number,
            'canonical_incident_name': incident_name,
            'fire_centre_id': fire_centre_id,
            'incident_start_date': require(raw_record, 'incident_start_date'),
            'incident_end_date': raw_record.get('incident_end_date'),
            'stage_of_control': raw_record.get('stage_of_control'),
            'cause_category': raw_record.get('cause_category'),
            'centroid_lat': raw_record.get('centroid_lat'),
            'centroid_lon': raw_record.get('centroid_lon'),
            'geometry_wkt': raw_record.get('geometry_wkt'),
            'source_surface_id': raw_record.get('source_surface_id'),
            'provenance_note': require(raw_record, 'provenance_note'),
        }

    def normalize_event_cluster(self, raw_record: dict) -> dict:
        canonical_name = require(raw_record, 'canonical_event_cluster_name')
        return {
            'event_cluster_id': raw_record.get('event_cluster_id') or deterministic_uuid('event_cluster', canonical_name),
            'canonical_event_cluster_name': canonical_name,
            'event_start_date': require(raw_record, 'event_start_date'),
            'event_end_date': raw_record.get('event_end_date'),
            'cross_jurisdiction_flag': bool(raw_record.get('cross_jurisdiction_flag', False)),
            'provenance_note': require(raw_record, 'provenance_note'),
        }

    def emit_links(self, normalized_record: dict) -> list[dict]:
        links = []
        incident_id = normalized_record.get('incident_id')
        event_cluster_id = normalized_record.get('event_cluster_id')
        if incident_id and event_cluster_id:
            links.append({
                'incident_id': incident_id,
                'event_cluster_id': event_cluster_id,
                'link_confidence': normalized_record.get('link_confidence', 1.0),
                'provenance_note': normalized_record.get('provenance_note', 'derived from deterministic adapter emit_links'),
            })
        return links
