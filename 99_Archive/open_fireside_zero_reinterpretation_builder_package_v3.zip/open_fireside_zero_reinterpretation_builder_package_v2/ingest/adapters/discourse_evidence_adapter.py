from __future__ import annotations

from .common import deterministic_uuid, require


class DiscourseEvidenceAdapter:
    def normalize(self, raw_record: dict) -> dict:
        external_item_id = require(raw_record, 'external_item_id')
        source_surface_id = require(raw_record, 'source_surface_id')
        payload = {
            'discourse_item_id': raw_record.get('discourse_item_id') or deterministic_uuid('discourse_item', source_surface_id, external_item_id),
            'discourse_thread_id': raw_record.get('discourse_thread_id'),
            'source_surface_id': source_surface_id,
            'external_item_id': external_item_id,
            'content_text': require(raw_record, 'content_text'),
            'content_language': raw_record.get('content_language', 'en'),
            'privacy_classification': require(raw_record, 'privacy_classification'),
        }
        if raw_record.get('actor_account_id'):
            payload['actor_account_id'] = raw_record['actor_account_id']
        if raw_record.get('protected_account_id'):
            payload['protected_account_id'] = raw_record['protected_account_id']
        return payload
