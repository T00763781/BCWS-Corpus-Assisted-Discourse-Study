from __future__ import annotations

from .common import deterministic_uuid, canonical_bool, require


class AccountAdapter:
    def normalize(self, raw_record: dict) -> dict:
        actor_id = require(raw_record, 'actor_id')
        platform = require(raw_record, 'platform')
        account_handle = require(raw_record, 'account_handle')
        return {
            'actor_account_id': raw_record.get('actor_account_id') or deterministic_uuid('actor_account', actor_id, platform, account_handle),
            'actor_id': actor_id,
            'platform': platform,
            'account_handle': account_handle,
            'account_url': raw_record.get('account_url'),
            'is_verified': canonical_bool(raw_record.get('is_verified', True)),
            'source_surface_id': raw_record.get('source_surface_id'),
        }
