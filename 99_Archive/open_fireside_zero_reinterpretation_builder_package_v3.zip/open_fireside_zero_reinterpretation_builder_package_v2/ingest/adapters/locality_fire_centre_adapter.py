from __future__ import annotations

import csv
from pathlib import Path

from .common import deterministic_uuid


class LocalityFireCentreAdapter:
    def __init__(self, reference_dir: str | Path | None = None):
        self.reference_dir = Path(reference_dir) if reference_dir else Path(__file__).resolve().parents[2] / 'reference'

    def _load_csv(self, filename: str) -> list[dict]:
        with open(self.reference_dir / filename, encoding='utf-8') as fh:
            return list(csv.DictReader(fh))

    def load_fire_centres(self) -> list[dict]:
        return [self.normalize_fire_centre(r) for r in self._load_csv('bc_fire_centres.csv')]

    def load_reference_places(self) -> list[dict]:
        rows = self._load_csv('bc_municipalities_or_localities.csv') + self._load_csv('external_communities.csv')
        return [self.normalize_locality(r) for r in rows]

    def normalize_fire_centre(self, raw_record: dict) -> dict:
        code = raw_record['canonical_id'].replace('fc_bc_', '').upper()
        return {
            'fire_centre_id': deterministic_uuid('fire_centre', raw_record['canonical_id']),
            'fire_centre_code': code,
            'fire_centre_name': raw_record['canonical_name'],
            'province_code': raw_record['province_state_territory'],
            'geometry_wkt': None,
            'centroid_lat': None,
            'centroid_lon': None,
        }

    def normalize_locality(self, raw_record: dict) -> dict:
        return {
            'locality_id': deterministic_uuid('locality', raw_record['canonical_id']),
            'canonical_locality_name': raw_record['canonical_name'],
            'municipality_name': raw_record['canonical_name'] if raw_record['type'] == 'municipality' else None,
            'province_code': raw_record['province_state_territory'],
            'country_code': raw_record['country'],
            'fire_centre_id': raw_record.get('fire_centre_linkage') or None,
            'structural_coverage_status': 'REFERENCE_ONLY',
            'evidence_coverage_status': 'NOT_STARTED',
            'boundary_classification': raw_record['boundary_classification'],
            'active_in_phase_a': str(raw_record['active_in_phase_a']).lower() == 'true',
            'provenance_note': raw_record['notes_provenance'],
        }

    def emit_links(self, normalized_record: dict) -> list[dict]:
        if normalized_record.get('fire_centre_id'):
            return [{
                'source_entity_type': 'LOCALITY',
                'source_entity_id': normalized_record['locality_id'],
                'target_entity_type': 'FIRE_CENTRE',
                'target_entity_id': normalized_record['fire_centre_id'],
                'link_confidence': 1.0,
                'provenance_note': 'reference-linkage or later overlay resolution',
            }]
        return []
