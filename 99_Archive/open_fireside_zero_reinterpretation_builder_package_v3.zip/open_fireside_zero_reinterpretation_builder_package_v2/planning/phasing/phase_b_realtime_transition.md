# Phase B Realtime Transition

Phase B begins on **2026-04-01** and only after Phase A sign-off.

## What changes in Phase B
- real-time ingestion is enabled
- schedulers and recurring validations are activated
- live source monitoring is allowed
- the reference population remains fixed unless the policy, manifest, and CSVs are revised together

## What does not change
- the database remains the canonical backbone for the GUI
- the public/protected ontology split remains intact
- OSINT verification remains the gate for new public-role actor/account records
