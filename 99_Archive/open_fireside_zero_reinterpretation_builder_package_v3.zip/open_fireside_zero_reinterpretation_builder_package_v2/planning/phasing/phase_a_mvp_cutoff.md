# Phase A MVP Cutoff

Phase A is the historical reconstruction phase for **2025-04-01 through 2026-03-31**.

## Purpose
Create a deterministic historical system that can reconstruct the wildfire-year record before any real-time automation is attempted.

## In scope
- canonical reference populations
- OSINT verification of public actors and public actor accounts derived from the canonical place universe
- ingestion of historical incidents, event clusters, discourse evidence, protected continuity entities, and linkage outputs
- incident detail and locality comparison read models
- governance-aware export controls

## Explicit floors
Phase A cannot sign off unless all of the following are true:
- all 6 canonical fire centres are loaded and validated
- all 161 canonical B.C. municipalities are loaded and validated
- all 13 canonical external communities are loaded and validated
- all target matrix rows marked `required_before_phase_a_signoff = YES` pass
- public actor/account verification has at least one verified official surface for every municipality where such a surface exists and has been documented as absent where it does not
- minimal ontology fixture, reference, phase, privacy, adapter, and read-model parity validations all pass

## Deferred to Phase B
The following are explicitly **deferred**:
- real-time polling
- schedulers and recurring background refresh
- live event triggers
- real-time alerting
- live incident ingestion outside the historical window

No builder may implement those behaviors under the label of Phase A.
