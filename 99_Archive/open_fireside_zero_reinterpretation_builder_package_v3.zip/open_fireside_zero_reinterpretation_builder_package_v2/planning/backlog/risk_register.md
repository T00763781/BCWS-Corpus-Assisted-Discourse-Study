# Risk Register

| Risk | Likelihood | Impact | Trigger | Mitigation |
|---|---|---:|---|---|
| reference scope drift | medium | high | counts change without policy edit | manifest + reference tests |
| OSINT verification inconsistency | high | high | actor/account records lack provenance | use workflow gates and parity tests |
| adapter-contract divergence | medium | high | normalized outputs omit required keys | adapter parity tests |
| read-model underpopulation | medium | medium | GUI lenses lose core fields | read-model parity tests and SQL review |
| premature realtime buildout | medium | medium | scheduler/live polling appears in Phase A | phase-boundary tests and phasing docs |
