# Implementation Checklist

- [ ] apply SQL schema in order
- [ ] load canonical reference populations
- [ ] verify reference integrity tests pass
- [ ] load minimal ontology fixtures
- [ ] verify adapter-contract parity tests pass
- [ ] execute OSINT verification workflow for public actors/accounts
- [ ] ingest historical incident and discourse records for 2025-04-01 through 2026-03-31
- [ ] refresh read-model views
- [ ] confirm governance/export checks pass
- [ ] keep real-time work deferred until Phase B
