# Phase A Target Matrix

This matrix sets the minimum structural and verification floors for Phase A. The CSV is machine-checkable; this document explains the intent.

## Exhaustive reference layers
- fire centres: all 6 rows in `bc_fire_centres.csv`
- municipalities/localities: all 161 rows in `bc_municipalities_or_localities.csv`
- external communities: all 13 rows in `external_communities.csv`

## Exhaustive or gated runtime layers
- incidents: every distinct incident emitted by the canonical incident ingestor for the historical window
- event clusters: every curated event cluster row in the canonical event cluster seed and any builder-approved extensions documented in provenance
- source surfaces: at least one surface for each required ingestion class, plus all surfaces needed to support verified public actor/account records

## Verification floors
- public actors: one verified public actor per municipality when an official governing body exists
- actor accounts: one verified official web surface per municipality, plus one verified social surface when such an official account exists
- protected continuity entities/accounts: only threshold-based minimums are set in Phase A; no synthetic inflation is allowed
- discourse items: enough to support incident and actor traceability for the historical window, with provenance and privacy classification present
