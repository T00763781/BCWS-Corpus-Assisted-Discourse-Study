# Reference Fixture Notes

The reference datasets are canonical package assets, not sample data. They must be loaded before minimal ontology fixtures. The manifest records the expected file counts and is used by validation tests to detect silent changes in scope.
