# Human Operator Brief

## What you supervise
You are supervising three linked layers:
1. canonical reference scope
2. OSINT verification quality for public-role actors and accounts
3. historical ingestion and read-model output quality

## Read first
- `reference/reference_layer_policy.md`
- `reference/phase_a_target_matrix.md`
- `app/workflows/phase_a_workflows.md`
- `docs/workflows/osint_verification_workflow.md`
- `planning/phasing/phase_a_mvp_cutoff.md`

## What to look for
- reference rows load without mutation
- municipality/locality verification produces official actor/account targets rather than ad hoc scraped identities
- discourse and protected continuity remain separated from public-role verification work
- read-model outputs remain consistent with the GUI lens they serve
