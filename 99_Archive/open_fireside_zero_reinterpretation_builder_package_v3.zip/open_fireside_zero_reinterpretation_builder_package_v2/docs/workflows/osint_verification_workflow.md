# OSINT Verification Workflow

## Why this stage exists
The database is the backbone, but it is only useful if canonical places are turned into verified public actors and verified actor accounts before ingestion. This workflow governs that step.

## Input universe
- all 161 canonical B.C. municipalities in `reference/bc_municipalities_or_localities.csv`
- all 6 canonical fire centres in `reference/bc_fire_centres.csv`
- selected external communities only when they support cross-border corridor or logistics context

## Verification targets per municipality
At minimum attempt to verify:
- one official municipal web presence
- one municipal government or emergency-management social presence when it exists
- one locality-to-fire-centre linkage resolution artifact

## Verification criteria
A public actor/account may be emitted only when:
- the account or website is clearly official
- provenance notes identify the confirming source surface
- the actor type and platform map to canonical enums
- the record can be represented without exposing protected private identities

## Required outputs
- normalized actor records
- normalized actor-account records
- source surface records when new official surfaces are discovered
- locality verification status entries for the locality comparison lens

## Failure conditions
Do not emit a public actor/account record when the source appears unofficial, impersonated, stale beyond reason, or unverifiable from the available evidence.
