# Acceptance Criteria

The package is acceptable only when all of the following are true:
- reference data loads without malformed rows or undeclared categorical values
- adapter outputs satisfy the required fields in their JSON contracts
- read-model contracts and SQL views describe the same output shape
- OSINT verification is documented as a pre-ingest stage for public-role actors/accounts
- protected private data never appears in public read models
- Phase A is explicitly limited to 2025-04-01 through 2026-03-31
- real-time work is explicitly deferred until 2026-04-01
- validation scripts and runbooks describe the same bootstrap sequence
