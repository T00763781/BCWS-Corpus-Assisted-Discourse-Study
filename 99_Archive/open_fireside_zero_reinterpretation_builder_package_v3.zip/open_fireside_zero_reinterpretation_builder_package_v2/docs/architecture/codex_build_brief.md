# Codex Build Brief

Build Open Fireside as a deterministic historical-first system. Do not treat this package as a loose architecture memo; treat it as the canonical implementation baseline.

## Frozen decisions
- Phase A window: 2025-04-01 through 2026-03-31
- Phase B start: 2026-04-01
- Database backbone connects all GUI tabs/lenses
- Public actors and public actor accounts are distinct from protected private entities and protected private accounts
- OSINT verification is a first-class pre-ingest stage for public-role actors
- Reference populations are fixed by the CSVs in `reference/`

## Non-negotiable builder obligations
- keep contracts, adapters, views, tests, and dictionary in parity
- never infer new reference-scope populations at runtime
- never bypass provenance notes on normalized records
- never route protected private records into public-role views

## Build order
1. schema
2. reference load
3. fixtures
4. validations
5. OSINT verification pipeline
6. historical ingestion replay
7. read-model refresh and governance-aware export
