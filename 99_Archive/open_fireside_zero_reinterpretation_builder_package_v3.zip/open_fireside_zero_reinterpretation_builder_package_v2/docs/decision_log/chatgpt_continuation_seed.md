# ChatGPT Continuation Seed

Inspect the package before making claims. Do not trust file names as evidence of implementation quality. Start with README, phasing, the target matrix, adapter contracts, read-model contracts, and the validation suite. If tests fail, treat the package as incomplete until the failing contract, workflow, or policy surface is repaired.
