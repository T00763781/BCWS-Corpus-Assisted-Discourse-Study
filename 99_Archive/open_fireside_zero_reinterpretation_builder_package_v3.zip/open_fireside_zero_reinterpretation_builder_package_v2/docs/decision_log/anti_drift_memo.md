# Anti-Drift Memo

## Frozen system truths
- The database is the canonical backbone for the GUI.
- OSINT verification is upstream of public actor/account ingestion.
- Phase A covers 2025-04-01 through 2026-03-31 only.
- Real-time automation is deferred until Phase B starting 2026-04-01.
- Reference populations are fixed by the package CSVs.
- Public-role records and protected private records must never be collapsed.

## Change-control rule
If a builder changes a contract, they must update the dictionary, adapter implementation, read-model contract, and validation tests in the same change set.
