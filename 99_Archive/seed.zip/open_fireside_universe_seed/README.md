# Open Fireside universe seed

This package is a deterministic **seed scaffold** for a fire-centre-aware, multi-agent Open Fireside discourse-universe build.

It includes:
- a machine-readable agent contract
- a shared orchestration YAML
- a locality/municipality seed directory tagged to BCWS fire centres
- role seeds for actors within each locality
- fire-centre directories for per-agent execution
- a snapshot of the current uploaded discourse registry

## Current seed counts

- localities/community/bordering starter rows: 91
- municipality starter rows: 85
- role seed rows: 1183
- known actor links from current snapshot: 14

## Notes

- municipality/locality rows are tagged to one of the six official BCWS fire centres
- regional districts that span multiple fire centres are explicitly marked as `multi` or `mixed_*` in the regional district seed file rather than pretending a single-centre assignment is always exact
- this is a **starter seed**, not a claim that the full British Columbia wildfire discourse universe has already been captured